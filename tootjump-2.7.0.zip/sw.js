/* ============================================================
   TOOT JUMP 2 — offline service worker (web build only).

   Strategy:
   - PRECACHE the shell (html/css/js/manifest/icons/font) on install so
     the game boots offline after the very first visit.
   - Everything else (the 52 meme mp3s, ~4 MB) is cached lazily on
     first play: precaching them would make the install hang on a slow
     connection and blow past storage quotas on some browsers.
   - Navigations are network-first with a cache fallback, so a deployed
     update is picked up immediately instead of being pinned to a stale
     index.html forever.
   - Same-origin static assets are cache-first (they are content-
     versioned via ?v= query strings).
   - The cache name embeds a build id; activating a new worker deletes
     every older cache and claims open clients.
   ============================================================ */
'use strict';

const BUILD = 'tj2-2.7.0.mw0ye9wi';
const SHELL_CACHE = BUILD + '-shell';
const RUNTIME_CACHE = BUILD + '-runtime';

const SHELL = [
	'./',
	'index.html',
	'manifest.webmanifest',
	'css/style.css?v=2.7.0.mw0ye9wi',
	'js/config.js?v=2.7.0.mw0ye9wi',
	'js/storage.js?v=2.7.0.mw0ye9wi',
	'js/characters.js?v=2.7.0.mw0ye9wi',
	'js/audio.js?v=2.7.0.mw0ye9wi',
	'js/input.js?v=2.7.0.mw0ye9wi',
	'js/fx.js?v=2.7.0.mw0ye9wi',
	'js/entities.js?v=2.7.0.mw0ye9wi',
	'js/missions.js?v=2.7.0.mw0ye9wi',
	'js/world.js?v=2.7.0.mw0ye9wi',
	'js/ui.js?v=2.7.0.mw0ye9wi',
	'js/main.js?v=2.7.0.mw0ye9wi',
	'assets/fonts/Baloo2-ExtraBold.ttf',
	'assets/sounds/manifest.json',
	'assets/sprites/characters/manifest.json',
	'assets/icons/icon-192.png',
	'assets/icons/icon-512.png',
	'assets/icons/icon-maskable-512.png',
];

self.addEventListener('install', (event) => {
	event.waitUntil((async () => {
		const cache = await caches.open(SHELL_CACHE);
		// add one-by-one: a single 404 must not fail the whole install
		await Promise.allSettled(SHELL.map(url => cache.add(new Request(url, { cache: 'reload' }))));
		await self.skipWaiting();
	})());
});

self.addEventListener('activate', (event) => {
	event.waitUntil((async () => {
		const names = await caches.keys();
		await Promise.all(
			names.filter(n => n !== SHELL_CACHE && n !== RUNTIME_CACHE)
				.map(n => caches.delete(n))
		);
		if (self.registration.navigationPreload) {
			try { await self.registration.navigationPreload.disable(); } catch (e) { /* ignore */ }
		}
		await self.clients.claim();
	})());
});

self.addEventListener('message', (event) => {
	if (event.data === 'skipWaiting') self.skipWaiting();
});

async function networkFirst(request) {
	const cache = await caches.open(SHELL_CACHE);
	try {
		const fresh = await fetch(request);
		if (fresh && fresh.ok) cache.put(request, fresh.clone());
		return fresh;
	} catch (e) {
		const hit = await cache.match(request, { ignoreSearch: true });
		if (hit) return hit;
		const shell = await cache.match('index.html');
		if (shell) return shell;
		throw e;
	}
}

async function cacheFirst(request) {
	const shell = await caches.open(SHELL_CACHE);
	const shellHit = await shell.match(request);
	if (shellHit) return shellHit;

	const runtime = await caches.open(RUNTIME_CACHE);
	const hit = await runtime.match(request);
	if (hit) return hit;

	const fresh = await fetch(request);
	// only cache complete, successful, same-origin responses
	if (fresh && fresh.ok && fresh.status === 200 && fresh.type === 'basic') {
		runtime.put(request, fresh.clone());
	}
	return fresh;
}

self.addEventListener('fetch', (event) => {
	const req = event.request;
	if (req.method !== 'GET') return;

	let url;
	try { url = new URL(req.url); } catch (e) { return; }
	if (url.origin !== self.location.origin) return;

	if (req.mode === 'navigate') {
		event.respondWith(networkFirst(req));
		return;
	}
	event.respondWith(cacheFirst(req).catch(async () => {
		const cache = await caches.open(SHELL_CACHE);
		const hit = await cache.match(req, { ignoreSearch: true });
		if (hit) return hit;
		return new Response('', { status: 504, statusText: 'offline' });
	}));
});
