'use strict';
/* ============================================================
   CHARACTER ROSTER — meme squad with drop-in PNG placeholders.
   ------------------------------------------------------------
   TO ADD YOUR OWN MEME CHARACTER:
   1. Drop a transparent PNG (~256x256+) named exactly `<id>.png`
      into  assets/sprites/characters/   — it auto-replaces the
      cartoon drawing. No code needed.
   2. To add a brand-new character, copy one entry below, give it
      a unique id, name, price and colors.
   ============================================================ */
const CHARACTERS = [
	{
		id: 'gary', name: 'Gassy Gary', shape: 'blob', price: 0,
		colors: { body: '#ff8a5c', belly: '#ffb08a', accent: '#ff6f61' },
		perk: 'the OG. perfectly balanced toots.',
		perkCode: null, trail: '#b7d95a',
	},
	{
		id: 'skibidi', name: 'Skibidi Steve', shape: 'toilet', price: 250,
		colors: { body: '#4ecdc4', belly: '#a8e6e1', accent: '#2ba8a0' },
		perk: 'revives cost HALF the coins',
		perkCode: 'halfRevive', trail: '#7fe8e0',
	},
	{
		id: 'sigma', name: 'Sigma Sam', shape: 'sigma', price: 400,
		colors: { body: '#8d99b8', belly: '#c3cbe0', accent: '#5d6a8c' },
		perk: 'combo timer +1.5s',
		perkCode: 'longCombo', trail: '#b8c2dd',
	},
	{
		id: 'rizz', name: 'Rizz Rat', shape: 'rat', price: 600,
		colors: { body: '#f7a8c4', belly: '#ffd6e5', accent: '#e077a2' },
		perk: '+15% coins everywhere',
		perkCode: 'richRat', trail: '#ffb7d5',
	},
	{
		id: 'ohio', name: 'Ohio Ollie', shape: 'alien', price: 900,
		colors: { body: '#9be564', belly: '#cdf2a8', accent: '#6bc22e' },
		perk: 'starts every run inside a bubble',
		perkCode: 'startBubble', trail: '#c2f08a',
	},
	{
		id: 'gyatt', name: 'Gyatt Gazelle', shape: 'gazelle', price: 1200,
		colors: { body: '#f2cd5c', belly: '#fae29a', accent: '#d9a92e' },
		perk: 'springs are 8% springier',
		perkCode: 'springy', trail: '#ffe08a',
	},
	{
		id: 'bombardino', name: 'Bombardino Crocodilo', shape: 'croc', price: 1800,
		colors: { body: '#7fbf6a', belly: '#b2dd9f', accent: '#4f8f3d' },
		perk: 'stomp bounces 12% higher',
		perkCode: 'stompy', trail: '#a8e08a',
	},
	{
		id: 'tralalero', name: 'Tralalero Tralala', shape: 'shark', price: 2500,
		colors: { body: '#6fa8dc', belly: '#cfe3f5', accent: '#3d7ab5' },
		perk: 'magnet lasts +4s',
		perkCode: 'longMagnet', trail: '#a8cdf0',
	},
	{
		id: 'chai', name: 'Tapri Chacha', shape: 'blob', price: 800,
		colors: { body: '#b07b4f', belly: '#e8cfa8', accent: '#8a5a32' },
		perk: 'spawns with 1 MEGA TOOT loaded',
		perkCode: 'startBeans', trail: '#d9b48a',
	},
	{
		id: 'babaji', name: 'Gyaani Baba', shape: 'sigma', price: 1500,
		colors: { body: '#e8955c', belly: '#f5cfa8', accent: '#c4703a' },
		perk: 'stays invincible longer after a hit',
		perkCode: 'tough', trail: '#f5b98a',
	},
	{
		id: 'annan', name: 'Auto Annan', shape: 'gazelle', price: 2100,
		colors: { body: '#f2c53c', belly: '#fae29a', accent: '#232a45' },
		perk: '+25% coins everywhere',
		perkCode: 'coinBoost', trail: '#ffe08a',
	},
	{
		id: 'vadapav', name: 'Vada Pav Vijay', shape: 'rat', price: 3000,
		colors: { body: '#e88a4a', belly: '#f8d0a0', accent: '#b55a24' },
		perk: 'a hit does not break your combo',
		perkCode: 'comboKeep', trail: '#f8b070',
	},
];

/* ---------------------------------------------------------- PNG overrides
   Manifest-driven: the old build blind-requested <id>.png for all 8
   characters on every boot, which produced 8 guaranteed 404s in the console
   (and 8 wasted requests) for the default install. tools/gen-manifests.mjs
   writes a manifest listing only the files that exist. */
const CharacterArt = {
	images: {},
	DIR: 'assets/sprites/characters/',
	_loaded: false,

	load() {
		if (this._loaded) return Promise.resolve();
		this._loaded = true;
		return fetch(this.DIR + 'manifest.json', { cache: 'force-cache' })
			.then(r => (r.ok ? r.json() : null))
			.then(man => {
				if (!man || !man.sprites) return;
				const valid = new Set(CHARACTERS.map(c => c.id));
				for (const id of Object.keys(man.sprites)) {
					if (!valid.has(id)) continue;
					this._loadOne(id, this.DIR + man.sprites[id]);
				}
			})
			.catch(() => { /* no manifest — procedural art only, which is fine */ });
	},

	_loadOne(id, url) {
		const img = new Image();
		img.decoding = 'async';
		img.onload = () => {
			if (img.naturalWidth > 0 && img.naturalHeight > 0) this.images[id] = img;
		};
		img.onerror = () => { delete this.images[id]; };
		img.src = url;
	},

	get(id) { return this.images[id] || null; },

	byId(id) { return CHARACTERS.find(c => c.id === id) || CHARACTERS[0]; },
};

/* -------------------------------------------------- procedural cartoon art
   Draws a character at origin, ~84px tall. opts:
   { t, vy, vx, hurt, rocket, blinkSeed, scale }                        */
function drawCharacter(ctx, ch, opts) {
	ch = ch || CHARACTERS[0];
	opts = opts || {};
	const t = opts.t || 0;
	const vy = opts.vy || 0;
	const vx = opts.vx || 0;
	const hurt = !!opts.hurt;
	const C = ch.colors;
	const navy = '#232a45';
	const look = Math.max(-1, Math.min(1, vx / 700));
	const blinkOn = ((t + (opts.blinkSeed || 0)) % 3.4) > 3.25;

	ctx.save();
	if (opts.scale) ctx.scale(opts.scale, opts.scale);

	// PNG override — drop assets/sprites/characters/<id>.png
	const png = CharacterArt.get(ch.id);
	if (png) {
		const s = 84 / Math.max(png.naturalWidth || png.width, png.naturalHeight || png.height);
		const w = (png.naturalWidth || png.width) * s;
		const h = (png.naturalHeight || png.height) * s;
		ctx.drawImage(png, -w / 2, -h / 2, w, h);
		ctx.restore();
		return;
	}

	const body = { rx: 34, ry: 34 };
	if (ch.shape === 'rat')    { body.rx = 30; body.ry = 36; }
	if (ch.shape === 'shark')  { body.rx = 40; body.ry = 30; }
	if (ch.shape === 'croc')   { body.rx = 40; body.ry = 28; }
	if (ch.shape === 'gazelle'){ body.rx = 30; body.ry = 37; }
	if (ch.shape === 'sigma')  { body.rx = 32; body.ry = 35; }
	if (ch.shape === 'alien')  { body.rx = 32; body.ry = 32; }
	if (ch.shape === 'toilet') { body.rx = 33; body.ry = 33; }

	// feet — animated scurry (or sneakers for the shark, obviously)
	const step = Math.sin(t * 10) * 5;
	ctx.strokeStyle = navy;
	ctx.lineCap = 'round';
	ctx.lineWidth = 7;
	if (ch.shape === 'shark') {
		for (const sgn of [-1, 1]) {
			const fx = sgn * 14, fy = body.ry - 5 + (sgn > 0 ? step : -step);
			ctx.fillStyle = '#ffffff';
			ctx.beginPath();
			ctx.roundRect(fx - 12, fy - 2, 24, 14, 6);
			ctx.fill();
			ctx.lineWidth = 3.5;
			ctx.stroke();
			ctx.fillStyle = '#5aa9e6';
			ctx.beginPath();
			ctx.roundRect(fx - 10, fy + 5, 20, 5, 2.5);
			ctx.fill();
			ctx.lineWidth = 7;
		}
	} else if (ch.shape === 'gazelle') {
		for (const sgn of [-1, 1]) {
			const fx = sgn * 13 + (sgn > 0 ? step : -step) * .6;
			ctx.beginPath();
			ctx.moveTo(fx, body.ry - 6);
			ctx.lineTo(fx + sgn * 6, body.ry + 10);
			ctx.stroke();
		}
	} else {
		for (const sgn of [-1, 1]) {
			const ph = sgn > 0 ? step : -step;
			ctx.beginPath();
			ctx.moveTo(sgn * 13, body.ry - 7 + ph);
			ctx.lineTo(sgn * 22, body.ry + 9 + ph);
			ctx.stroke();
		}
	}

	// tail / dorsal fin / wings behind body
	if (ch.shape === 'rat') {
		ctx.strokeStyle = C.accent;
		ctx.lineWidth = 6;
		ctx.beginPath();
		ctx.moveTo(0, body.ry - 4);
		ctx.quadraticCurveTo(-40, body.ry + 6, -34 - Math.sin(t * 6) * 6, body.ry + 26);
		ctx.stroke();
		ctx.strokeStyle = navy;
		ctx.lineWidth = 7;
	}
	if (ch.shape === 'shark') {
		ctx.fillStyle = C.accent;
		ctx.strokeStyle = navy;
		ctx.lineWidth = 4;
		ctx.beginPath();
		ctx.moveTo(-6, -body.ry + 6);
		ctx.quadraticCurveTo(0, -body.ry - 26, 16, -body.ry + 8);
		ctx.closePath();
		ctx.fill();
		ctx.stroke();
	}
	if (ch.shape === 'croc') {
		// little bomb-plane wings
		ctx.fillStyle = '#e8e3d5';
		ctx.strokeStyle = navy;
		ctx.lineWidth = 4;
		for (const sgn of [-1, 1]) {
			ctx.beginPath();
			ctx.ellipse(sgn * 38, 2, 16, 7, sgn * 0.4, 0, Math.PI * 2);
			ctx.fill();
			ctx.stroke();
		}
	}

	// body
	ctx.fillStyle = C.body;
	ctx.strokeStyle = navy;
	ctx.lineWidth = 5;
	ctx.beginPath();
	if (ch.shape === 'croc') ctx.roundRect(-body.rx, -body.ry, body.rx * 2, body.ry * 2, 16);
	else ctx.ellipse(0, 0, body.rx, body.ry, 0, 0, Math.PI * 2);
	ctx.fill();
	ctx.stroke();

	// ears / horns / antenna / toilet lid
	if (ch.shape === 'rat') {
		for (const sgn of [-1, 1]) {
			ctx.fillStyle = C.belly;
			ctx.beginPath();
			ctx.arc(sgn * 24, -body.ry + 2, 13, 0, Math.PI * 2);
			ctx.fill();
			ctx.stroke();
			ctx.fillStyle = C.accent;
			ctx.beginPath();
			ctx.arc(sgn * 24, -body.ry + 2, 6, 0, Math.PI * 2);
			ctx.fill();
		}
	}
	if (ch.shape === 'alien') {
		ctx.beginPath();
		ctx.moveTo(0, -body.ry + 2);
		ctx.lineTo(-5, -body.ry - 16);
		ctx.stroke();
		ctx.fillStyle = C.accent;
		ctx.beginPath();
		ctx.arc(-5, -body.ry - 19, 6, 0, Math.PI * 2);
		ctx.fill();
		ctx.stroke();
	}
	if (ch.shape === 'gazelle') {
		for (const sgn of [-1, 1]) {
			ctx.strokeStyle = '#e8dcc5';
			ctx.lineWidth = 6;
			ctx.beginPath();
			ctx.moveTo(sgn * 14, -body.ry + 2);
			ctx.quadraticCurveTo(sgn * 26, -body.ry - 14, sgn * 16, -body.ry - 26);
			ctx.stroke();
			ctx.strokeStyle = navy;
			ctx.lineWidth = 5;
		}
	}
	if (ch.shape === 'toilet') {
		ctx.fillStyle = '#ffffff';
		ctx.beginPath();
		ctx.ellipse(0, body.ry - 2, body.rx * .95, 13, 0, 0, Math.PI * 2);
		ctx.fill();
		ctx.stroke();
	}
	if (ch.shape === 'croc') {
		// aviator goggles
		ctx.fillStyle = '#c07a3a';
		ctx.beginPath();
		ctx.roundRect(-body.rx + 4, -body.ry - 8, body.rx * 2 - 8, 10, 5);
		ctx.fill();
		ctx.stroke();
	}
	if (ch.shape === 'sigma') {
		// sunglasses. obviously.
		ctx.fillStyle = '#1a1f33';
		ctx.beginPath();
		ctx.roundRect(-24, -18, 20, 12, 4);
		ctx.roundRect(4, -18, 20, 12, 4);
		ctx.fill();
		ctx.beginPath();
		ctx.moveTo(-24, -14);
		ctx.lineTo(-27, -16);
		ctx.moveTo(24, -14);
		ctx.lineTo(27, -16);
		ctx.lineWidth = 3.5;
		ctx.stroke();
		ctx.lineWidth = 5;
	}

	// snout for croc
	if (ch.shape === 'croc') {
		ctx.fillStyle = C.belly;
		ctx.beginPath();
		ctx.roundRect(-16, 6, 32, 16, 8);
		ctx.fill();
		ctx.stroke();
		ctx.fillStyle = '#ffffff';
		for (const sgn of [-1, 1]) {
			ctx.beginPath();
			ctx.moveTo(sgn * 6, 8);
			ctx.lineTo(sgn * 6 + 4, 8);
			ctx.lineTo(sgn * 6 + 2, 13);
			ctx.closePath();
			ctx.fill();
		}
	}

	// belly patch
	if (ch.shape !== 'croc') {
		ctx.fillStyle = C.belly;
		ctx.beginPath();
		ctx.ellipse(0, body.ry * 0.38, body.rx * 0.55, body.ry * 0.42, 0, 0, Math.PI * 2);
		ctx.fill();
	}

	// shine
	ctx.fillStyle = 'rgba(255,255,255,0.55)';
	ctx.beginPath();
	ctx.ellipse(-body.rx * 0.42, -body.ry * 0.5, body.rx * 0.2, body.ry * 0.14, -0.6, 0, Math.PI * 2);
	ctx.fill();

	// face (skip eyes if sigma — he has shades)
	if (ch.shape !== 'sigma') {
		for (const sgn of [-1, 1]) {
			const ex = sgn * 13.5, ey = -8;
			if (blinkOn) {
				ctx.beginPath();
				ctx.moveTo(ex - 7, ey);
				ctx.lineTo(ex + 7, ey);
				ctx.lineWidth = 4.5;
				ctx.stroke();
				ctx.lineWidth = 5;
			} else {
				ctx.fillStyle = '#ffffff';
				ctx.beginPath();
				ctx.arc(ex, ey, 8.5, 0, Math.PI * 2);
				ctx.fill();
				ctx.stroke();
				ctx.fillStyle = navy;
				ctx.beginPath();
				ctx.arc(ex + look * 3.2, ey + 1.6, 3.8, 0, Math.PI * 2);
				ctx.fill();
			}
		}
		// angry brows while hurt
		if (hurt) {
			ctx.lineWidth = 3.5;
			for (const sgn of [-1, 1]) {
				ctx.beginPath();
				ctx.moveTo(sgn * 18, -21);
				ctx.lineTo(sgn * 6, -16);
				ctx.stroke();
			}
			ctx.lineWidth = 5;
		}
	}

	// cheeks
	ctx.fillStyle = 'rgba(255,120,120,0.65)';
	ctx.beginPath();
	ctx.arc(-body.rx * 0.72, 4, 5.2, 0, Math.PI * 2);
	ctx.arc(body.rx * 0.72, 4, 5.2, 0, Math.PI * 2);
	ctx.fill();

	// mouth by mood
	ctx.strokeStyle = navy;
	if (hurt) {
		ctx.beginPath();
		ctx.arc(0, 17, 6.5, Math.PI + 0.4, Math.PI * 2 - 0.4);
		ctx.stroke();
	} else if (vy < -600) {
		ctx.fillStyle = '#7c3a44';
		ctx.beginPath();
		ctx.arc(0, 11, 7, 0, Math.PI * 2);
		ctx.fill();
		ctx.stroke();
	} else {
		ctx.beginPath();
		ctx.arc(0, 7, 10, 0.4, Math.PI - 0.4);
		ctx.stroke();
	}
	ctx.restore();
}
