'use strict';
/* ============================================================
   Missions — 3 rotating goals with coin rewards.

   Fixes vs the previous build:
   - `collect()` was called from `notify()`, which is called from
     `_giveCoins()`, which is called by `collect()`'s reward payout →
     a mission that rewarded coins could re-enter the collector and
     double-pay. Collection is now re-entrancy guarded.
   - completing a mission called Storage.save() synchronously mid-frame
     for every completed mission; now a single save.
   - 'tier' missions stored the tier INDEX as progress, so
     "Reach the SHEEESH combo" (index 2) showed a 2/2 bar as soon as
     you hit GIGACHAD. Progress is now clamped and labelled off the
     same value.
   - refills avoid handing out a mission the player just finished.
   ============================================================ */
const Missions = {
	TEMPLATES: [
		{ type: 'reach',  targets: [300, 600, 1000, 1500, 2000], rewards: [40, 60, 90, 120, 160], label: t => `Climb ${t} m in one run` },
		{ type: 'stomp',  targets: [5, 10, 20],                  rewards: [50, 80, 130],          label: t => `Stomp ${t} grumps` },
		{ type: 'coin',   targets: [25, 60, 120],                rewards: [40, 70, 120],          label: t => `Collect ${t} coins` },
		{ type: 'spring', targets: [8, 20, 40],                  rewards: [40, 70, 120],          label: t => `Bounce on ${t} springs` },
		{ type: 'tier',   targets: [1, 2, 3],                    rewards: [60, 100, 150],         label: t => `Reach the ${CFG.TIERS[t]} combo` },
		{ type: 'runs',   targets: [3, 5, 10],                   rewards: [30, 50, 80],           label: t => `Play ${t} runs` },
	],

	// per-run mission types use max(), cumulative types use +=
	PER_RUN: new Set(['reach', 'tier']),

	_collecting: false,

	ensure() {
		const list = Storage.data.missions;
		let guard = 0;
		while (list.length < 3 && guard++ < 10) list.push(this.gen(list));
	},

	gen(existing) {
		const typesInUse = (existing || []).map(m => m.type);
		let pool = this.TEMPLATES.filter(t => !typesInUse.includes(t.type));
		if (!pool.length) pool = this.TEMPLATES;
		const tpl = pool[(Math.random() * pool.length) | 0];
		const idx = (Math.random() * tpl.targets.length) | 0;
		const target = tpl.targets[idx];
		return {
			type: tpl.type,
			target,
			reward: tpl.rewards[idx],
			prog: 0,
			label: tpl.label(target),
		};
	},

	notify(type, value) {
		const v = Number(value);
		if (!Number.isFinite(v)) return [];
		let changed = false;
		for (const m of Storage.data.missions) {
			if (m.type !== type) continue;
			const before = m.prog;
			if (this.PER_RUN.has(type)) m.prog = Math.min(m.target, Math.max(m.prog, v));
			else m.prog = Math.min(m.target, m.prog + v);
			if (m.prog !== before) changed = true;
		}
		if (changed) Storage.saveSoon();
		return this.collect();
	},

	/* per-run missions reset when a new run starts */
	resetPerRun() {
		let changed = false;
		for (const m of Storage.data.missions) {
			if (this.PER_RUN.has(m.type) && m.prog > 0 && m.prog < m.target) {
				m.prog = 0;
				changed = true;
			}
		}
		if (changed) Storage.saveSoon();
	},

	/* returns [{label, reward}] of missions just completed, then refills */
	collect() {
		if (this._collecting) return [];
		this._collecting = true;
		try {
			const done = this._collectList(Storage.data.missions, false);
			const dailyDone = this._collectList(Storage.data.daily.missions, true);
			if (!done.length && !dailyDone.length) return done;

			this.ensure();
			Storage.save();

			if (typeof UI !== 'undefined' && UI.toast) {
				for (const d of done) UI.toast(`MISSION DONE: ${d.label}`, `+${d.reward}`);
				for (const d of dailyDone) UI.toast(`🔥 DAILY DONE: ${d.label}`, `+${d.reward}`);
			}
			// every completed challenge banks a crate in the vault — "loot by
			// playing more" is the whole loop
			const crateCount = done.length + dailyDone.length;
			if (crateCount > 0) {
				const vault = Storage.data.crates;
				vault.normal = Math.min(99, (vault.normal || 0) + crateCount);
				if (typeof UI !== 'undefined' && UI.toast) {
					UI.toast(`🎁 +${crateCount} crate${crateCount > 1 ? 's' : ''} banked!`, 'coin');
				}
			}
			return done;
		} finally {
			this._collecting = false;
		}
	},

	/* shared payout+refill for the run list and the daily list */
	_collectList(list, isDaily) {
		const done = [];
		for (let i = list.length - 1; i >= 0; i--) {
			const m = list[i];
			if (m.prog >= m.target) {
				done.unshift({ label: m.label, reward: m.reward });
				list.splice(i, 1);
			}
		}
		if (!done.length) return done;

		let payout = 0;
		for (const d of done) payout += d.reward;
		Storage.data.coins += payout;
		if (isDaily) {
			// completing at least one daily today marks the streak
			Storage.data.daily.lastDone = this._today();
		}
		if (!isDaily) this.ensure();
		else while (list.length < 3) list.push(this.genDaily(list));
		return done;
	},

	/* ================================================ DAILY MISSIONS */
	/* 3 goals that reset every calendar day, with bigger rewards than the
	   evergreen list. Doing them on consecutive days grows the 🔥 streak. */

	_today() {
		const d = new Date();
		return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
	},

	_yesterday() {
		const d = new Date(Date.now() - 86400000);
		return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
	},

	genDaily(existing) {
		const typesInUse = (existing || []).map(m => m.type);
		let pool = this.TEMPLATES.filter(t => !typesInUse.includes(t.type));
		if (!pool.length) pool = this.TEMPLATES;
		const tpl = pool[(Math.random() * pool.length) | 0];
		// dailies use the upper half of targets and pay ~2x
		const idx = Math.min(tpl.targets.length - 1,
			1 + ((Math.random() * (tpl.targets.length - 1)) | 0));
		const target = tpl.targets[idx];
		const reward = Math.round(tpl.rewards[idx] * 2);
		return { type: tpl.type, target, reward, prog: 0, label: tpl.label(target) };
	},

	/* called from the menu so the day rolls over while the app is open */
	ensureDaily() {
		const daily = Storage.data.daily;
		const today = this._today();
		if (daily.date === today) return;
		const continued = daily.lastDone === this._yesterday();
		daily.date = today;
		daily.missions = [this.genDaily([]), this.genDaily(daily.missions), this.genDaily(daily.missions)];
		daily.streak = continued ? daily.streak : 0;
		Storage.save();
	},
};

if (typeof module !== 'undefined' && module.exports) module.exports = { Missions };
