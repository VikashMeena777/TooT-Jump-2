'use strict';
/* ============================================================
   HATS — 24 cosmetic hats for the coin shop.

   Every hat draws in a LOCAL coordinate system: the caller has
   already translated so (0,0) is the TOP-CENTRE of the character's
   head and scaled by s (= head radius). A hat therefore spans
   roughly [-1.6s, +1.6s] horizontally and sits between -1.2s and
   +0.4s vertically (negative = up).

   lineWidth is expressed as ~3/s so after the caller's scale(s)
   the outline stays the house-standard 3px navy stroke.

   Preview/QA: define window.__HATS_TEST__ before load, then open
   the page — all 24 hats render into a grid canvas appended to
   document.body. tools/shots.mjs also probes the shop screen.
   ============================================================ */
const NAVY_HAT = '#232a45';

/* helper: consistent outline width under the caller's scale */
function _lw(ctx, s, w) { ctx.lineWidth = (w || 3) / s; }

const HATS = [
	/* ---------------- tier 1: 50-150c ---------------- */
	{
		id: 'none', name: 'No Hat', price: 0,
		draw() { /* the classic no-hat look */ },
	},
	{
		id: 'topi', name: 'Gandhi Topi', price: 50,
		draw(ctx, s) {
			_lw(ctx, s);
			ctx.fillStyle = '#fff9ee';
			ctx.beginPath();
			ctx.moveTo(-1.1, 0.05);
			ctx.lineTo(-0.95, -0.55);
			ctx.lineTo(0.95, -0.55);
			ctx.lineTo(1.1, 0.05);
			ctx.closePath();
			ctx.fill(); ctx.stroke();
			ctx.fillStyle = '#f0e6d2';
			ctx.fillRect(-1.1, -0.14, 2.2, 0.2);
		},
	},
	{
		id: 'party', name: 'Party Cone', price: 60,
		draw(ctx, s) {
			_lw(ctx, s);
			ctx.fillStyle = '#ff6f61';
			ctx.beginPath();
			ctx.moveTo(0, -1.15);
			ctx.lineTo(0.62, 0.05);
			ctx.lineTo(-0.62, 0.05);
			ctx.closePath();
			ctx.fill(); ctx.stroke();
			ctx.fillStyle = '#ffd166';
			ctx.beginPath(); ctx.arc(0, -1.15, 0.14, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
			ctx.fillStyle = '#fff9ee';
			ctx.fillRect(-0.5, -0.42, 1.0, 0.16);
		},
	},
	{
		id: 'banana', name: 'Banana Peel', price: 80,
		draw(ctx, s) {
			_lw(ctx, s);
			ctx.fillStyle = '#ffd94a';
			for (const dir of [-1, 1]) {
				ctx.beginPath();
				ctx.moveTo(dir * 0.2, 0.1);
				ctx.quadraticCurveTo(dir * 1.1, -0.15, dir * 0.85, -0.75);
				ctx.quadraticCurveTo(dir * 0.55, -0.3, dir * 0.05, -0.2);
				ctx.closePath();
				ctx.fill(); ctx.stroke();
			}
		},
	},
	{
		id: 'schoolcap', name: 'School Cap', price: 100,
		draw(ctx, s) {
			_lw(ctx, s);
			ctx.fillStyle = '#3d7ab5';
			ctx.beginPath();
			ctx.arc(0, -0.05, 0.85, Math.PI, 0);
			ctx.closePath();
			ctx.fill(); ctx.stroke();
			ctx.beginPath();          // front visor
			ctx.ellipse(0.62, -0.02, 0.5, 0.16, 0, 0, Math.PI * 2);
			ctx.fill(); ctx.stroke();
		},
	},
	{
		id: 'traffic', name: 'Traffic Cone', price: 150,
		draw(ctx, s) {
			_lw(ctx, s);
			ctx.fillStyle = '#ff7b3d';
			ctx.beginPath();
			ctx.moveTo(0, -1.1);
			ctx.lineTo(0.68, 0.1);
			ctx.lineTo(-0.68, 0.1);
			ctx.closePath();
			ctx.fill(); ctx.stroke();
			ctx.fillStyle = '#fff9ee';
			ctx.fillRect(-0.42, -0.5, 0.84, 0.17);
			ctx.fillRect(-0.56, -0.05, 1.12, 0.17);
		},
	},
	{
		id: 'samosa', name: 'Samosa Crown', price: 130,
		draw(ctx, s) {
			_lw(ctx, s);
			ctx.fillStyle = '#e8a94a';
			for (const dir of [-1, 1]) {
				ctx.beginPath();
				ctx.moveTo(dir * 0.15, 0.05);
				ctx.lineTo(dir * 0.62, -0.55);
				ctx.lineTo(dir * 0.72, 0.05);
				ctx.closePath();
				ctx.fill(); ctx.stroke();
			}
			ctx.beginPath();                    // one on top
			ctx.moveTo(0, -0.15);
			ctx.lineTo(0.2, -0.75);
			ctx.lineTo(0.38, -0.15);
			ctx.closePath();
			ctx.fill(); ctx.stroke();
		},
	},
	/* ---------------- tier 2: 200-500c ---------------- */
	{
		id: 'halo', name: 'Holy Halo', price: 200,
		draw(ctx, s) {
			_lw(ctx, s);
			ctx.strokeStyle = '#ffd166';
			_lw(ctx, s, 4);
			ctx.beginPath();
			ctx.ellipse(0, -0.72, 0.72, 0.2, 0, 0, Math.PI * 2);
			ctx.stroke();
			ctx.strokeStyle = 'rgba(255,209,102,0.45)';
			_lw(ctx, s, 7);
			ctx.beginPath();
			ctx.ellipse(0, -0.72, 0.72, 0.2, 0, 0, Math.PI * 2);
			ctx.stroke();
		},
	},
	{
		id: 'horns', name: 'Devil Horns', price: 220,
		draw(ctx, s) {
			_lw(ctx, s);
			ctx.fillStyle = '#e05548';
			for (const dir of [-1, 1]) {
				ctx.beginPath();
				ctx.moveTo(dir * 0.28, 0.05);
				ctx.quadraticCurveTo(dir * 0.95, -0.3, dir * 0.55, -0.95);
				ctx.quadraticCurveTo(dir * 0.5, -0.4, dir * 0.1, -0.1);
				ctx.closePath();
				ctx.fill(); ctx.stroke();
			}
		},
	},
	{
		id: 'monkey', name: 'Monkey Cap', price: 240,
		draw(ctx, s) {
			_lw(ctx, s);
			ctx.fillStyle = '#4a5578';
			ctx.beginPath();
			ctx.arc(0, -0.15, 0.95, Math.PI, 0);
			ctx.closePath();
			ctx.fill(); ctx.stroke();
			ctx.fillRect(-0.95, -0.16, 1.9, 0.34);   // the strap
			ctx.strokeRect(-0.95, -0.16, 1.9, 0.34);
			ctx.fillStyle = '#8a93b8';               // the ear holes
			ctx.beginPath(); ctx.arc(-0.5, 0.02, 0.09, 0, Math.PI * 2); ctx.fill();
			ctx.beginPath(); ctx.arc(0.5, 0.02, 0.09, 0, Math.PI * 2); ctx.fill();
		},
	},
	{
		id: 'shades', name: 'Head Shades', price: 260,
		draw(ctx, s) {
			_lw(ctx, s);
			ctx.fillStyle = '#1a1f33';
			ctx.beginPath();
			ctx.roundRect(-0.85, -0.42, 0.72, 0.42, 0.08);
			ctx.roundRect(0.13, -0.42, 0.72, 0.42, 0.08);
			ctx.fill(); ctx.stroke();
			ctx.beginPath();
			ctx.moveTo(-0.13, -0.28); ctx.lineTo(0.13, -0.28);
			ctx.stroke();
		},
	},
	{
		id: 'chefhat', name: 'Chef Hat', price: 300,
		draw(ctx, s) {
			_lw(ctx, s);
			ctx.fillStyle = '#ffffff';
			ctx.beginPath();
			ctx.arc(-0.4, -0.5, 0.34, 0, Math.PI * 2);
			ctx.arc(0.4, -0.5, 0.34, 0, Math.PI * 2);
			ctx.arc(0, -0.72, 0.4, 0, Math.PI * 2);
			ctx.fill();
			ctx.beginPath();
			ctx.roundRect(-0.68, -0.62, 1.36, 0.62, 0.1);
			ctx.fill(); ctx.stroke();
			ctx.beginPath();
			ctx.moveTo(-0.68, -0.28); ctx.lineTo(0.68, -0.28);
			ctx.stroke();
		},
	},
	{
		id: 'cricket', name: 'Cricket Helmet', price: 320,
		draw(ctx, s) {
			_lw(ctx, s);
			ctx.fillStyle = '#5aa9e6';
			ctx.beginPath();
			ctx.arc(0, -0.1, 0.92, Math.PI, 0);
			ctx.closePath();
			ctx.fill(); ctx.stroke();
			ctx.fillStyle = '#3d7ab5';               // grille
			_lw(ctx, s, 2.5);
			for (let i = -2; i <= 2; i++) {
				ctx.beginPath();
				ctx.moveTo(i * 0.3, -0.35);
				ctx.lineTo(i * 0.3, -0.02);
				ctx.stroke();
			}
			_lw(ctx, s);
			ctx.beginPath();                          // peak
			ctx.ellipse(0.6, -0.28, 0.42, 0.14, 0.1, 0, Math.PI * 2);
			ctx.fill(); ctx.stroke();
		},
	},
	{
		id: 'garland', name: 'Phool Mala', price: 350,
		draw(ctx, s) {
			_lw(ctx, s);
			const cols = ['#ff6f61', '#ffd166', '#ff9a5c', '#e05aa8', '#59cd90'];
			for (let i = 0; i < 9; i++) {
				const a = Math.PI + (i / 8) * Math.PI;
				ctx.fillStyle = cols[i % cols.length];
				ctx.beginPath();
				ctx.arc(Math.cos(a) * 0.95, -0.05 - Math.sin(a) * 0.32, 0.15, 0, Math.PI * 2);
				ctx.fill(); ctx.stroke();
			}
		},
	},
	{
		id: 'wig', name: 'Judge Wig', price: 420,
		draw(ctx, s) {
			_lw(ctx, s);
			ctx.fillStyle = '#f2f0ea';
			ctx.beginPath();
			ctx.arc(0, -0.25, 0.92, Math.PI, 0);
			ctx.fill(); ctx.stroke();
			for (const dir of [-1, 1]) {              // the side rolls
				for (let i = 0; i < 3; i++) {
					ctx.beginPath();
					ctx.arc(dir * (0.62 + i * 0.13), -0.2 - i * 0.3, 0.16, 0, Math.PI * 2);
					ctx.fill(); ctx.stroke();
				}
			}
		},
	},
	{
		id: 'flower', name: 'Idea Bulb', price: 450,
		draw(ctx, s) {
			_lw(ctx, s);
			ctx.fillStyle = '#ffe9a8';
			ctx.beginPath();
			ctx.arc(0, -0.55, 0.5, 0, Math.PI * 2);
			ctx.fill(); ctx.stroke();
			ctx.fillStyle = '#b9c2cf';
			ctx.fillRect(-0.22, -0.1, 0.44, 0.2);
			ctx.strokeRect(-0.22, -0.1, 0.44, 0.2);
			ctx.strokeStyle = '#ffd166';              // shining rays
			_lw(ctx, s, 2.5);
			for (let i = 0; i < 4; i++) {
				const a = -Math.PI / 2 + (i - 1.5) * 0.5;
				ctx.beginPath();
				ctx.moveTo(Math.cos(a) * 0.62, -0.55 + Math.sin(a) * 0.62);
				ctx.lineTo(Math.cos(a) * 0.85, -0.55 + Math.sin(a) * 0.85);
				ctx.stroke();
			}
		},
	},
	{
		id: 'vadapavhat', name: 'Vada Pav Hat', price: 500,
		draw(ctx, s) {
			_lw(ctx, s);
			ctx.fillStyle = '#f2c063';                // the pav
			ctx.beginPath();
			ctx.ellipse(0, -0.18, 0.85, 0.42, 0, 0, Math.PI * 2);
			ctx.fill(); ctx.stroke();
			ctx.fillStyle = '#c07a3a';                // the vada peeking out
			ctx.beginPath();
			ctx.ellipse(0, -0.42, 0.5, 0.26, 0, Math.PI, 0);
			ctx.fill(); ctx.stroke();
			ctx.fillStyle = '#59cd90';                // mirchi
			ctx.beginPath();
			ctx.ellipse(0.3, -0.5, 0.2, 0.07, -0.4, 0, Math.PI * 2);
			ctx.fill();
		},
	},
	/* ---------------- tier 3: 600-1200c ---------------- */
	{
		id: 'pagdi', name: 'Royal Pagdi', price: 600,
		draw(ctx, s) {
			_lw(ctx, s);
			ctx.fillStyle = '#e05548';
			ctx.beginPath();
			ctx.ellipse(0, -0.3, 1.0, 0.6, 0, Math.PI * 0.95, Math.PI * 2.05);
			ctx.fill(); ctx.stroke();
			ctx.strokeStyle = '#ffd166';
			_lw(ctx, s, 2.5);
			for (const yy of [-0.62, -0.45, -0.28]) {
				ctx.beginPath();
				ctx.moveTo(-0.9, yy + 0.08);
				ctx.quadraticCurveTo(0, yy - 0.16, 0.9, yy + 0.08);
				ctx.stroke();
			}
			_lw(ctx, s);
			ctx.fillStyle = '#ffd166';                // the kalgi
			ctx.beginPath();
			ctx.moveTo(0, -0.92);
			ctx.lineTo(0.22, -1.05);
			ctx.lineTo(0.05, -0.72);
			ctx.closePath();
			ctx.fill(); ctx.stroke();
		},
	},
	{
		id: 'chai', name: 'Chai Glass Hat', price: 750,
		draw(ctx, s) {
			_lw(ctx, s);
			ctx.fillStyle = 'rgba(200,120,60,0.92)';  // cutting chai
			ctx.beginPath();
			ctx.moveTo(-0.55, -0.9);
			ctx.lineTo(0.55, -0.9);
			ctx.lineTo(0.42, -0.05);
			ctx.lineTo(-0.42, -0.05);
			ctx.closePath();
			ctx.fill(); ctx.stroke();
			ctx.strokeStyle = 'rgba(255,255,255,0.7)';// steam
			_lw(ctx, s, 2.5);
			ctx.beginPath();
			ctx.moveTo(-0.15, -1.05);
			ctx.quadraticCurveTo(0.05, -1.2, -0.1, -1.35);
			ctx.stroke();
			_lw(ctx, s);
		},
	},
	{
		id: 'afro', name: 'Rainbow Afro', price: 900,
		draw(ctx, s) {
			const cols = ['#ff6f61', '#ffd166', '#59cd90', '#5aa9e6', '#c4a6ec'];
			const n = 5;
			for (let ring = 0; ring < n; ring++) {
				ctx.fillStyle = cols[ring % cols.length];
				for (let i = 0; i <= ring + 3; i++) {
					const a = Math.PI + (i / (ring + 3)) * Math.PI;
					const rr = 0.35 + ring * 0.19;
					ctx.beginPath();
					ctx.arc(Math.cos(a) * rr, -0.12 + Math.sin(a) * rr, 0.17, 0, Math.PI * 2);
					ctx.fill();
				}
			}
		},
	},
	{
		id: 'biryani', name: 'Biryani Pot', price: 1000,
		draw(ctx, s) {
			_lw(ctx, s);
			ctx.fillStyle = '#c9884a';
			ctx.beginPath();                          // handi body
			ctx.ellipse(0, -0.32, 0.8, 0.52, 0, 0, Math.PI * 2);
			ctx.fill(); ctx.stroke();
			ctx.fillStyle = '#8a5a2b';                // the lid
			ctx.beginPath();
			ctx.ellipse(0, -0.78, 0.62, 0.2, 0, 0, Math.PI * 2);
			ctx.fill(); ctx.stroke();
			ctx.fillStyle = '#59cd90';                // steam sprout
			ctx.beginPath();
			ctx.ellipse(0, -1.0, 0.12, 0.14, 0, 0, Math.PI * 2);
			ctx.fill(); ctx.stroke();
		},
	},
	{
		id: 'rockethelm', name: 'Rocket Helmet', price: 1200,
		draw(ctx, s) {
			_lw(ctx, s);
			ctx.fillStyle = 'rgba(174,216,248,0.35)'; // the bubble dome
			ctx.beginPath();
			ctx.arc(0, -0.28, 0.98, Math.PI, 0);
			ctx.closePath();
			ctx.fill(); ctx.stroke();
			ctx.fillStyle = '#e8e3d5';                // the collar
			ctx.beginPath();
			ctx.roundRect(-0.85, -0.34, 1.7, 0.3, 0.1);
			ctx.fill(); ctx.stroke();
			ctx.fillStyle = 'rgba(255,255,255,0.75)'; // the glint
			ctx.beginPath();
			ctx.ellipse(-0.3, -0.62, 0.16, 0.09, -0.5, 0, Math.PI * 2);
			ctx.fill();
		},
	},
	/* ---------------- legendary: 1500-2500c ---------------- */
	{
		id: 'goldcrown', name: 'Gold Crown', price: 1500,
		draw(ctx, s) {
			_lw(ctx, s);
			ctx.fillStyle = '#ffd166';
			ctx.beginPath();
			ctx.moveTo(-0.95, 0.05);
			ctx.lineTo(-0.95, -0.62);
			ctx.lineTo(-0.48, -0.25);
			ctx.lineTo(0, -0.85);
			ctx.lineTo(0.48, -0.25);
			ctx.lineTo(0.95, -0.62);
			ctx.lineTo(0.95, 0.05);
			ctx.closePath();
			ctx.fill(); ctx.stroke();
			ctx.fillStyle = '#e05548';
			for (const gx of [-0.5, 0, 0.5]) {
				ctx.beginPath();
				ctx.arc(gx, -0.12, 0.09, 0, Math.PI * 2);
				ctx.fill();
			}
		},
	},
	{
		id: 'goldpoop', name: 'GOLDEN POOP', price: 2500,
		draw(ctx, s) {
			_lw(ctx, s);
			ctx.fillStyle = '#d4a017';
			ctx.beginPath();
			ctx.moveTo(0, -1.05);
			ctx.quadraticCurveTo(0.7, -0.85, 0.4, -0.55);
			ctx.quadraticCurveTo(0.95, -0.3, 0.35, -0.05);
			ctx.lineTo(-0.35, -0.05);
			ctx.quadraticCurveTo(-0.95, -0.3, -0.4, -0.55);
			ctx.quadraticCurveTo(-0.7, -0.85, 0, -1.05);
			ctx.closePath();
			ctx.fill(); ctx.stroke();
			ctx.fillStyle = '#fff3c2';
			ctx.beginPath(); ctx.arc(-0.18, -0.75, 0.12, 0, Math.PI * 2); ctx.fill();
			ctx.strokeStyle = '#fff3c2';              // the sparkle
			_lw(ctx, s, 2.5);
			ctx.beginPath();
			ctx.moveTo(0.6, -1.0); ctx.lineTo(0.85, -1.0);
			ctx.moveTo(0.72, -1.13); ctx.lineTo(0.72, -0.87);
			ctx.stroke();
			_lw(ctx, s);
		},
	},
];

/* ------------------------------------------------------------ drawHat
   Called by the player renderer and by shop thumbnails. (x, y) is the
   head-top-centre in the CURRENT transform, s = head radius. */
function drawHat(ctx, hatDef, x, y, s) {
	if (!hatDef || !hatDef.draw) return;
	ctx.save();
	ctx.translate(x, y);
	ctx.scale(s, s);
	ctx.strokeStyle = NAVY_HAT;
	hatDef.draw(ctx, s);
	ctx.restore();
}

/* hat lookup — price-ordered like the shop shows them */
HATS.byId = function (id) {
	for (const h of this) if (h.id === id) return h;
	return this[0];
};

/* the player's head-top sits at about (0, -34) in character space;
   head radius ≈ 22 for every shape, so hats can use a constant mount */
const HATS_MOUNT = { x: 0, y: -34, s: 22 };

if (typeof module !== 'undefined' && module.exports) module.exports = { HATS, drawHat };