'use strict';
/* ============================================================
   Input — drag steering (mobile-first) + keyboard.

   Fixes vs the previous build:
   - drag deltas are converted to GAME space, so steering feels
     identical on a 360px phone and a 1440px desktop (before, a
     100px swipe moved the player 140 game-px regardless of how
     large that swipe was relative to the screen)
   - pointer capture keeps tracking a finger that slides outside
     the canvas instead of silently dropping the gesture
   - multi-touch hands control to the newest finger instead of
     ignoring it, which used to feel like the game froze
   - input is GATED: drags accumulated in menus / while paused no
     longer teleport the player the instant play resumes
   - arrow keys no longer scroll the page; P / Esc pause
   ============================================================ */
const Input = {
	dragDX: 0,          // pending horizontal movement, in GAME px
	keys: Object.create(null),
	enabled: false,     // set true only while a run is active

	_ptrId: null,
	_lastX: 0,
	_canvas: null,
	_scale: 1,          // game px per CSS px

	init(canvas) {
		this._canvas = canvas;

		const down = (e) => {
			// newest finger takes control (feels responsive with 2 thumbs)
			this._ptrId = e.pointerId;
			this._lastX = e.clientX;
			try { canvas.setPointerCapture(e.pointerId); } catch (err) { /* not supported */ }
		};

		const move = (e) => {
			if (e.pointerId !== this._ptrId) return;
			const dx = e.clientX - this._lastX;
			this._lastX = e.clientX;
			if (this.enabled) this.dragDX += dx * this._scale;
		};

		const up = (e) => {
			if (e.pointerId !== this._ptrId) return;
			this._ptrId = null;
			try { canvas.releasePointerCapture(e.pointerId); } catch (err) { /* ignore */ }
		};

		canvas.addEventListener('pointerdown', down, { passive: true });
		canvas.addEventListener('pointermove', move, { passive: true });
		canvas.addEventListener('pointerup', up, { passive: true });
		canvas.addEventListener('pointercancel', up, { passive: true });
		canvas.addEventListener('lostpointercapture', up, { passive: true });

		const NAV_KEYS = new Set([
			'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Space', 'Tab',
		]);

		window.addEventListener('keydown', (e) => {
			if (e.repeat) {
				if (NAV_KEYS.has(e.code)) e.preventDefault();
				return;
			}
			this.keys[e.code] = true;
			// stop the page from scrolling / the focus ring from wandering
			if (NAV_KEYS.has(e.code) && e.target === document.body) e.preventDefault();
		});

		window.addEventListener('keyup', (e) => { this.keys[e.code] = false; });

		// any focus loss must clear held keys or the player drifts forever
		const clear = () => this.reset();
		window.addEventListener('blur', clear);
		document.addEventListener('visibilitychange', () => { if (document.hidden) clear(); });
	},

	/* called by the resize handler: how many game px one CSS px equals */
	setScale(gamePxPerCssPx) {
		this._scale = Number.isFinite(gamePxPerCssPx) && gamePxPerCssPx > 0
			? gamePxPerCssPx : 1;
	},

	axis() {
		let a = 0;
		if (this.keys['ArrowLeft'] || this.keys['KeyA']) a -= 1;
		if (this.keys['ArrowRight'] || this.keys['KeyD']) a += 1;
		return a;
	},

	consumeDrag() {
		const d = this.dragDX;
		this.dragDX = 0;
		return d;
	},

	/* drop every pending input — used on pause, death, menu, blur */
	reset() {
		this.keys = Object.create(null);
		this.dragDX = 0;
		this._ptrId = null;
	},

	setEnabled(on) {
		if (this.enabled === on) return;
		this.enabled = on;
		this.dragDX = 0;   // never carry stale motion across a state change
	},
};

if (typeof module !== 'undefined' && module.exports) module.exports = { Input };
