'use strict';
/* ============================================================
   Game — boot, state machine, fixed-timestep loop, sizing.

   Fixes vs the previous build:
   - PHYSICS NOW RUNS ON A FIXED TIMESTEP. The old loop fed raw frame
     time straight into the simulation and only clamped at 1/20s. On a
     120Hz phone the player bounced noticeably higher than on a 60Hz
     one, and a single 50ms stutter could move the player 75px in one
     step — straight through a platform. Rendering stays interpolation-
     free (the game is not motion-sensitive) but the simulation is now
     frame-rate independent and identical on every device.
   - the loop scheduled the next frame BEFORE doing any work, so a
     thrown exception left rAF running forever and produced an
     unbounded error spam. Now guarded and reported once.
   - `document.title = 'TJ2 ERROR'` was the only error surface. There
     is now a real on-screen error card, and the loop keeps running so
     one bad frame can't brick the game.
   - resize used `window.innerWidth/Height`, which on Android excludes
     nothing and on iOS Safari changes as the toolbar hides, causing a
     permanent letterbox. Now uses visualViewport when available, is
     debounced through rAF, and reacts to orientationchange.
   - the audio unlock listener was `{once:true}` on pointerdown: if the
     very first gesture was a keydown the pointer listener stayed
     armed and vice versa; both now unlock and both are cleaned up.
   - pause is now also bound to P/Escape and to losing focus, and
     resuming re-syncs the clock so a long background pause doesn't
     produce a giant catch-up step.
   ============================================================ */

/* roundRect polyfill for older Android WebViews */
if (typeof CanvasRenderingContext2D !== 'undefined' &&
	!CanvasRenderingContext2D.prototype.roundRect) {
	CanvasRenderingContext2D.prototype.roundRect = function (x, y, w, h, r) {
		if (typeof r === 'number') r = [r, r, r, r];
		else if (!Array.isArray(r)) r = [0, 0, 0, 0];
		if (r.length === 1) r = [r[0], r[0], r[0], r[0]];
		if (r.length === 2) r = [r[0], r[1], r[0], r[1]];
		const max = Math.min(Math.abs(w), Math.abs(h)) / 2;
		for (let i = 0; i < 4; i++) r[i] = Math.min(r[i], max);
		this.moveTo(x + r[0], y);
		this.arcTo(x + w, y, x + w, y + h, r[1]);
		this.arcTo(x + w, y + h, x, y + h, r[2]);
		this.arcTo(x, y + h, x, y, r[3]);
		this.arcTo(x, y, x + w, y, r[0]);
		this.closePath();
		return this;
	};
}

const Game = {
	state: 'menu',            // menu | play | over
	paused: false,
	reviveUsed: false,
	canvas: null, ctx: null,

	STEP: 1 / 120,            // fixed simulation step (seconds)
	MAX_STEPS: 8,             // never simulate more than this per frame
	_accum: 0,
	_last: 0,
	_time: 0,
	_lastFlush: 0,
	_booted: false,
	_rafId: 0,
	_errorShown: false,
	_resizePending: false,
	_smoke: false, _smokeT: 0, _smokeLogged: false,

	/* ---------------------------------------------------------- boot */
	boot() {
		if (this._booted) return;
		this._booted = true;

		this.canvas = document.getElementById('game');
		if (!this.canvas) { this._fatal('canvas #game missing'); return; }

		this.ctx = this.canvas.getContext('2d', { alpha: false });
		if (!this.ctx) { this._fatal('this device has no 2D canvas support'); return; }

		Storage.load();
		Storage.installLifecycleHooks();
		CharacterArt.load();
		World.init();
		Missions.ensure();

		Input.init(this.canvas);
		UI.init();
		if (!Storage.data.quizDone) UI.show('quiz');
		else UI.show('menu');
		UI.setReviveHandlers(() => this.revive(), null);

		this._installAudioUnlock();
		this._installLifecycle();
		this._installResize();
		this._applyQueryFlags();

		// out-of-store update check (APK banner; web-bundle hot-swap is done
		// natively by @capgo/capacitor-updater before this code even runs)
		if (typeof Updater !== 'undefined') setTimeout(() => Updater.check(), 3500);

		// debugging/testing hook
		window.__toot = { Game: this, World, Storage, UI, FX, SFX, CFG, Input, Missions };

		this._last = performance.now();
		this._rafId = requestAnimationFrame((t) => this._frame(t));
	},

	/* audio and vibration both need a real user gesture — accept whichever
	   comes first, then remove ALL listeners (the old code armed two
	   independent `once` listeners so one always leaked) */
	_installAudioUnlock() {
		const unlock = () => {
			SFX.noteGesture();
			SFX.init();
			SFX.resume();
			window.removeEventListener('pointerdown', unlock);
			window.removeEventListener('keydown', unlock);
			window.removeEventListener('touchstart', unlock);
		};
		window.addEventListener('pointerdown', unlock, { passive: true });
		window.addEventListener('touchstart', unlock, { passive: true });
		window.addEventListener('keydown', unlock);
	},

	_installLifecycle() {
		document.addEventListener('visibilitychange', () => {
			if (document.hidden) {
				if (this.state === 'play' && !this.paused) this.togglePause();
				Storage.flush();
				// the WebView keeps playing the generated music over other
				// apps unless we suspend the AudioContext ourselves
				SFX.suspend();
				// battery: the render loop does nothing useful while hidden —
				// stop it outright instead of letting the OS throttle it
				this._stopLoop();
			} else {
				SFX.resume();
				this._startLoop();
			}
		});

		window.addEventListener('blur', () => {
			if (this.state === 'play' && !this.paused) this.togglePause();
		});

		// keyboard: P / Escape pause, Enter restarts from game over
		window.addEventListener('keydown', (e) => {
			if (e.code === 'KeyP' || e.code === 'Escape') {
				if (this.state === 'play') { e.preventDefault(); this.togglePause(); }
			}
		});

		this._installCapacitorLifecycle();
	},

	/* render loop control — used by the lifecycle hooks so a hidden app
	   burns zero frames instead of relying on rAF throttling */
	_stopLoop() {
		if (this._rafId) { cancelAnimationFrame(this._rafId); this._rafId = 0; }
	},

	_startLoop() {
		if (this._rafId) return;   // already running
		this._last = performance.now();
		this._accum = 0;
		this._rafId = requestAnimationFrame((t) => this._frame(t));
	},

	/* native app lifecycle — Android only (Capacitor plugins absent on web).
	   The old build listened for the Cordova-only 'backbutton' event, which
	   Capacitor never fires, so the hardware back button just closed the
	   app from any screen. */
	_installCapacitorLifecycle() {
		if (!window.Capacitor || !window.Capacitor.Plugins) return;
		const App = window.Capacitor.Plugins.App;
		if (!App) return;

		// hardware back: route by screen instead of exiting
		try {
			App.addListener('backButton', () => this._hardwareBack());
		} catch (e) { /* plugin unavailable */ }

		// minimize/restore: silence audio + pause the run while backgrounded
		try {
			App.addListener('appStateChange', (s) => {
				if (!s.isActive) {
					if (this.state === 'play' && !this.paused) this.togglePause();
					Storage.flush();
					SFX.suspend();
					this._stopLoop();
				} else {
					SFX.resume();
					this._startLoop();
				}
			});
		} catch (e) { /* plugin unavailable */ }
	},

	_hardwareBack() {
		const screen = UI._current;
		if (this.state === 'play') {
			// back during a run pauses; back on the pause screen quits to menu
			if (this.paused) { this.toMenu(); return; }
			this.togglePause();
			return;
		}
		if (this.state === 'over') { this.toMenu(); return; }
		// menu sub-screens go back to the menu, never out of the app
		if (screen === 'chars' || screen === 'howto' || screen === 'badges' ||
			screen === 'shop' || screen === 'crates' || screen === 'quiz') {
			UI.refreshMenu();
			UI.show('menu');
			return;
		}
		// on the menu itself: standard Android behaviour — background the app
		try { window.Capacitor.Plugins.App.minimizeApp(); } catch (e) { /* ignore */ }
	},

	_installResize() {
		const onResize = () => {
			if (this._resizePending) return;
			this._resizePending = true;
			requestAnimationFrame(() => {
				this._resizePending = false;
				this._resize();
			});
		};
		this._resize();
		window.addEventListener('resize', onResize);
		window.addEventListener('orientationchange', onResize);
		if (window.visualViewport) {
			window.visualViewport.addEventListener('resize', onResize);
		}
	},

	_applyQueryFlags() {
		let qp;
		try { qp = new URLSearchParams(location.search); } catch (e) { return; }

		if (qp.has('easyhazards')) {
			CFG.SPIKE_START_M = 5;
			CFG.ENEMY_START_M = 5;
			CFG.DIFF_DIST = 6000;
		}
		if (qp.has('forcebest')) {
			Storage.data.best = Math.max(Storage.data.best, parseInt(qp.get('forcebest'), 10) || 30);
		}
		if (qp.has('coins')) {
			Storage.data.coins += Math.max(0, parseInt(qp.get('coins'), 10) || 0);
			Storage.save();
		}
		if (qp.has('smoke')) {
			this._smoke = true;
			this._smokeDur = Math.max(3, parseFloat(qp.get('smoke')) || 20);
			World.autopilot = true;
			Storage.data.quizDone = true;   // smoke tests must not stall on the quiz
			setTimeout(() => this.startRun(), 400);
		}
		if (qp.has('killcamtest')) {
			setTimeout(() => { if (World.playing) FX.startKillcam(); }, 8000);
		}
	},

	/* ---------------------------------------------------------- sizing
	   The old build letterboxed a fixed 720x1280 box, which left ~85px of
	   dead navy bars on the top and bottom of a modern 19.5:9 phone. The
	   design WIDTH is still locked to 720 (the horizontal budget is what
	   makes a row reachable, so it must not vary), but the design HEIGHT now
	   follows the device aspect ratio within a clamped range, so the game
	   fills the screen edge to edge. */
	_resize() {
		const vv = window.visualViewport;
		const vw = Math.max(1, Math.floor(vv ? vv.width : window.innerWidth));
		const vh = Math.max(1, Math.floor(vv ? vv.height : window.innerHeight));

		CFG.setViewHeight(CFG.VIEW_W * (vh / vw));

		const s = Math.min(vw / CFG.VIEW_W, vh / CFG.VIEW_H);
		const cssW = Math.max(1, Math.round(CFG.VIEW_W * s));
		const cssH = Math.max(1, Math.round(CFG.VIEW_H * s));

		const stage = document.getElementById('stage');
		stage.style.width = cssW + 'px';
		stage.style.height = cssH + 'px';

		// cap DPR: a 3x-DPR phone rendering 720x1560 at 3x is 10M pixels per
		// frame, which no mid-range GPU sustains at 60fps
		const dpr = Math.min(window.devicePixelRatio || 1, 2);
		const bw = Math.round(cssW * dpr);
		const bh = Math.round(cssH * dpr);
		if (this.canvas.width !== bw || this.canvas.height !== bh) {
			this.canvas.width = bw;
			this.canvas.height = bh;
		}
		this.ctx.setTransform(bw / CFG.VIEW_W, 0, 0, bh / CFG.VIEW_H, 0, 0);
		this.ctx.imageSmoothingEnabled = true;

		const ui = document.getElementById('ui');
		ui.style.width = CFG.VIEW_W + 'px';
		ui.style.height = CFG.VIEW_H + 'px';
		ui.style.transform = `scale(${cssW / CFG.VIEW_W})`;

		// tell Input how many game px one CSS px is worth, so drag
		// sensitivity feels the same on every screen size
		const uiScale = cssW / CFG.VIEW_W;
		Input.setScale(uiScale > 0 ? 1 / uiScale : 1);
	},

	/* ---------------------------------------------------------- flow */
	startRun(daily) {
		SFX.stopAll();
		SFX.resume();
		UI.hideBanner();
		UI.clearToasts();
		UI.resetHUD();
		UI.cancelRevive();
		Missions.resetPerRun();

		// the daily challenge: date-seeded world, tracked separately
		World.dailyMode = !!daily;
		this._dailyScorePending = !!daily;

		this.reviveUsed = !!daily;   // no continue on the daily — one clean shot
		this.paused = false;
		Input.reset();
		Input.setEnabled(true);

		World.reset(Storage.data.selected);
		UI.show('hud');
		this.state = 'play';
		this._accum = 0;
		this._last = performance.now();
		if (this._smoke) { this._smokeT = this._time; this._smokeLogged = false; }
	},

	/* daily challenge entry point (menu card) */
	startDaily() {
		this.startRun(true);
		FX.text(CFG.VIEW_W / 2, -420, 'DAILY CHALLENGE!', { color: '#ffd166', size: 42, life: 2.2, vy: -26 });
	},

	gameOver() {
		if (this.state !== 'play') return;
		this.state = 'over';
		this.paused = false;
		Input.setEnabled(false);
		Input.reset();
		UI.hideBanner();

		const d = Storage.data;
		const score = World.score();
		const isNewBest = score > d.best;
		const gapToBest = isNewBest ? 0 : d.best - score;
		if (isNewBest) d.best = score;
		d.runs++;
		d.stats.deaths++;

		/* invisible DDA — record the death altitude band AFTER stats so the
		   ease applies to the NEXT run's generator, never retroactively */
		World._ddaRecordDeath();

		/* DAILY CHALLENGE — record the result, pay the once-a-day bonus */
		let dailyBonus = 0;
		if (World.dailyMode) {
			const today = World._today();
			if (d.dailyRun.date !== today) {
				d.dailyRun.date = today;
				d.dailyRun.best = 0;
				d.dailyRun.played = false;
			}
			d.dailyRun.played = true;
			if (score > d.dailyRun.best) {
				const beat = d.dailyRun.best > 0;
				d.dailyRun.best = score;
				dailyBonus = CFG.DAILY_BONUS + (beat ? CFG.DAILY_STREAK_BONUS : 0);
				d.coins += dailyBonus;
				d.stats.coins += dailyBonus;
				UI.toast(`☀️ DAILY DONE: ${score} m  +${dailyBonus}`, 'coin');
				if (World.runLog) World.runLog.push({ icon: '☀️', label: `daily challenge +${dailyBonus}` });
			}
		}

		/* CUP LADDER — authoritative check with the final best */
		World._checkCups();

		d.stats.stomps += World.runStomps;
		d.stats.springs += World.runSprings;
		if (World.comboMax > d.stats.maxCombo) d.stats.maxCombo = World.comboMax;
		Missions.notify('reach', World.meters());

		// weekly leaderboard — keep the best 5 of the last 7 days
		const now = Date.now();
		d.board.push({ score, char: d.selected, ts: now });
		d.board.sort((a, b) => b.score - a.score);
		d.board = d.board.filter(e => now - e.ts < 7 * 86400000).slice(0, 5);

		Missions.notify('runs', 1);
		Storage.save();

		const cost = this.reviveCost();
		UI.showGameOver({
			title: CFG.DEATH_TITLES[(Math.random() * CFG.DEATH_TITLES.length) | 0],
			line: CFG.DEATH_LINES[(Math.random() * CFG.DEATH_LINES.length) | 0],
			score,
			best: d.best,
			isNewBest,
			gapToBest,
			coins: World.runCoins,
			canRevive: !this.reviveUsed && d.coins >= cost,
			reviveCost: cost,
			recap: this._recapLines(),
			rewards: (World.runLog || []).slice(0, 8),
		});

		Achievements.check();
		SFX.play('gameover', 0.05, 1);
		SFX.stopRocket();
		SFX.haptic([60, 40, 120]);
		if (isNewBest) FX.confetti(CFG.VIEW_W / 2, World.camY);
		// NOTE: no notification work here — scheduling from game over made
		// Android pop its permission/"alarms & reminders" screen right after
		// death. Notifications are handled in toMenu() only.
	},

	/* the death recap: two or three funniest true facts about the run */
	_recapLines() {
		const lines = [];
		const cc = World.runCloseCalls;
		if (cc > 0) lines.push(cc === 1 ? '1 CLOSE call. the platform is still laughing' : `${cc} CLOSE calls — the platforms are scared of you`);
		if (World.runHits >= 3) lines.push(`${World.runHits} chappals taken and STILL climbing`);
		if (World.runStomps >= 3) lines.push(`${World.runStomps} grumps flattened 💀`);
		if (World.runBeansUsed > 0) lines.push(`${World.runBeansUsed} mega-toots deployed`);
		if (World.runGolden) lines.push('touched the golden poop. we saw everything');
		if (World.runSprings === 0 && World.meters() > 150) lines.push('zero springs used. pure lung power');
		if (World.comboMax >= 9) lines.push(`${World.comboMax}x combo — the grumps filed a complaint`);
		// pick at most 3, prioritising the spicy ones
		return lines.slice(0, 3);
	},

	reviveCost() {
		const perk = World.player && World.player.char ? World.player.char.perkCode : null;
		return perk === 'halfRevive' ? Math.round(CFG.REVIVE_COST / 2) : CFG.REVIVE_COST;
	},

	revive() {
		const d = Storage.data;
		const cost = this.reviveCost();
		if (this.reviveUsed || d.coins < cost || this.state !== 'over') return;
		d.coins -= cost;
		d.stats.revives++;
		Storage.save();
		this.reviveUsed = true;
		UI.cancelRevive();
		UI.resetHUD();
		World.revive();
		Input.reset();
		Input.setEnabled(true);
		UI.show('hud');
		this.state = 'play';
		this._accum = 0;
		this._last = performance.now();
		SFX.play('powerup', 0.05);
	},

	toMenu() {
		// quitting mid-run from the pause menu: the climb still happened.
		// Record the height and any cups it earned before wiping the run —
		// previously quitting silently threw the whole run away.
		if (this.state === 'play') {
			const score = World.score();
			if (score > Storage.data.best) Storage.data.best = score;
			World._checkCups();
			Storage.save();
		}
		this.state = 'menu';
		this.paused = false;
		World.playing = false;
		World.dailyMode = false;
		Input.setEnabled(false);
		Input.reset();
		SFX.stopRocket();
		FX.clear();
		UI.cancelRevive();
		UI.hideBanner();
		UI.refreshMenu();
		UI.show('menu');
		Storage.flush();
		// ask for notification permission once, after the player has engaged
		if (typeof Notify !== 'undefined' && Notify.available() && Storage.data.notif.ask) {
			Storage.data.notif.ask = false;
			Storage.save();
			Notify.request().then(() => Notify.refresh());
		}
	},

	togglePause() {
		if (this.state !== 'play') return;
		this.paused = !this.paused;
		if (this.paused) {
			Input.setEnabled(false);
			Input.reset();
			SFX.stopRocket();
			UI.refreshPause();
			UI.show('pause');
		} else {
			Input.reset();
			Input.setEnabled(true);
			UI.show('hud');
			// re-sync so the paused wall-clock time isn't simulated at once
			this._last = performance.now();
			this._accum = 0;
		}
	},

	resume() {
		if (this.state === 'play' && this.paused) this.togglePause();
	},

	/* ---------------------------------------------------------- loop */
	_frame(now) {
		try {
			this._step(now);
		} catch (err) {
			this._reportError(err);
		}
		// scheduled AFTER the work so a throw can't spin a runaway loop
		this._rafId = requestAnimationFrame((t) => this._frame(t));
	},

	_step(now) {
		let dt = (now - this._last) / 1000;
		this._last = now;
		if (!Number.isFinite(dt) || dt < 0) dt = 0;
		if (dt > 0.25) dt = 0.25;            // long stall: drop the excess
		this._time += dt;

		/* ADAPTIVE QUALITY — shed visual weight on slow phones, restore it
		   when FPS recovers. Measured on the real frame clock. */
		if (dt > 0) this._aqFps = this._aqFps ? this._aqFps * 0.9 + (1 / dt) * 0.1 : 1 / dt;
		this._aqT = (this._aqT || 0) + dt;
		if (this._aqT >= CFG.AQ_CHECK_EVERY) {
			this._aqT = 0;
			const tier = this._aqTier || 0;
			if (this._aqFps < CFG.AQ_DROP_FPS && tier < CFG.AQ_TIERS - 1) {
				this._aqTier = tier + 1;
				this._aqGood = 0;
			} else if (this._aqFps > CFG.AQ_RESTORE_FPS) {
				this._aqGood = (this._aqGood || 0) + 1;
				if (this._aqGood >= 2 && tier > 0) { this._aqTier = tier - 1; this._aqGood = 0; }
			} else {
				this._aqGood = 0;
			}
		}

		// real-time effects (shake, hit-stop, kill cam) must not be slowed
		// by the very slow-mo they cause
		FX.tickReal(dt);

		// simulation time scale
		const scale = FX.hitstop > 0 ? 0.12 : (FX.killcamT > 0 ? 0.35 : 1);

		if (this.state === 'play' && !this.paused) {
			this._accum += dt * scale;
			let steps = 0;
			while (this._accum >= this.STEP && steps < this.MAX_STEPS) {
				World.update(this.STEP);
				this._accum -= this.STEP;
				steps++;
				// World.update may end the run mid-catch-up
				if (this.state !== 'play') { this._accum = 0; break; }
			}
			// if we blew the step budget, drop the backlog instead of
			// accumulating debt that produces a slow-motion death spiral
			if (steps >= this.MAX_STEPS) this._accum = 0;
			// tier 2 (lightest): cap particles harder — cheap phones first
			if ((this._aqTier || 0) >= 2) {
				while (FX.parts.length > 140) FX._recyclePart(0);
			}
			FX.update(dt * scale);
			UI.updateHUD();
		} else {
			FX.update(dt);
			if (this.state === 'over') UI.updateRevive(dt);
			if (this.state === 'menu') World.menuUpdate(dt);
		}

		// debounced storage flush (at most every ~2.5s)
		if (this._time - this._lastFlush > 2.5) {
			this._lastFlush = this._time;
			Storage.flush();
		}

		World.draw(this.ctx, this._time);
		UI.tick(this._time, dt);

		this._smokeReport();
	},

	/* current adaptive-quality tier (0 full juice … 2 lightest) */
	_aqTier: 0,

	_smokeReport() {
		if (!this._smoke || this._smokeLogged) return;
		if (this.state !== 'play' && this.state !== 'over') return;
		if (this._time - this._smokeT < (this._smokeDur || 20)) return;
		this._smokeLogged = true;
		const report = {
			score: World.score(),
			meters: World.meters(),
			platforms: World.platforms.length,
			enemies: World.enemies.length,
			coins: World.coins.length,
			powerups: World.powerups.length,
			particles: FX.parts.length,
			combo: World.combo,
			comboMax: World.comboMax,
			state: this.state,
			runCoins: World.runCoins,
			stomps: World.runStomps,
			springs: World.runSprings,
		};
		console.log('SMOKE_RESULT ' + JSON.stringify(report));
		console.log('SMOKE_OK');
	},

	/* ---------------------------------------------------------- errors */
	_reportError(err) {
		const msg = (err && (err.stack || err.message)) || String(err);
		console.error('[TootJump2]', err);
		if (this._errorShown) return;
		this._errorShown = true;
		this._fatal(msg, true);
	},

	/* non-blocking error card — the game keeps running behind it */
	_fatal(message, dismissable) {
		try {
			const box = document.createElement('div');
			box.id = 'fatal';
			box.setAttribute('role', 'alert');
			const title = document.createElement('div');
			title.className = 'fatal-title';
			title.textContent = 'something tooted wrong';
			const body = document.createElement('pre');
			body.className = 'fatal-body';
			body.textContent = String(message).slice(0, 600);
			box.appendChild(title);
			box.appendChild(body);
			if (dismissable) {
				const btn = document.createElement('button');
				btn.className = 'btn small coral';
				btn.textContent = 'DISMISS';
				btn.addEventListener('click', () => box.remove());
				box.appendChild(btn);
			}
			document.body.appendChild(box);
		} catch (e) { /* nothing left to do */ }
	},
};

/* surface load-time errors too */
window.addEventListener('error', (e) => {
	if (Game._errorShown) return;
	Game._errorShown = true;
	Game._fatal((e && e.message) || 'unknown script error', true);
});
window.addEventListener('unhandledrejection', (e) => {
	console.error('[TootJump2] unhandled rejection', e && e.reason);
});

if (document.readyState === 'loading') {
	document.addEventListener('DOMContentLoaded', () => Game.boot());
} else {
	Game.boot();
}
