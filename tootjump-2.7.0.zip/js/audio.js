'use strict';
/* ============================================================
   AudioManager — meme sounds with synth fallbacks.

   Fixes vs the previous build:
   - loading is MANIFEST-DRIVEN and parallel. The old loader awaited
     11 slots x 6 variants x 3 extensions sequentially (up to 198
     round trips, most of them 404s) which took many seconds and
     spammed the console. Now one manifest.json lists the real files
     and they decode concurrently.
   - decodeAudioData is called with the promise form and per-file
     failures are isolated, so one bad mp3 no longer aborts the rest.
   - voices are tracked per-slot AND globally, and every source is
     disconnected on end — the old code leaked GainNodes for every
     sound played in a session.
   - the rocket loop can no longer be orphaned by a slot collision.
   - AudioContext is resumed on visibility return (Android WebView
     suspends it when backgrounded, which used to kill all audio for
     the rest of the session).
   - music scheduler uses a drift-free absolute clock and stops
     cleanly; it no longer keeps an interval running after stop.
   ============================================================ */
const SFX = {
	CTX: null, master: null, sfxBus: null, musicBus: null,
	pools: {}, ready: false, loaded: false,
	RATE: 22050,
	SLOTS: ['jump', 'hurt', 'spring', 'break', 'boing', 'coin', 'powerup', 'gameover', 'button', 'combo', 'whoosh', 'magnet'],

	/* meme clips are LONG and loudness-varied. Two rules keep them clean:
	   1) ONE real sound on stage at a time — an equal-or-bigger event takes
	      the stage; a smaller event waits until the big meme finishes.
	      Blips (coin/button) stay silent while anything real plays.
	   2) every clip is loudness-normalised (RMS) so they all hit equally. */
	PRIORITY: { gameover: 100, hurt: 90, powerup: 80, magnet: 80, boing: 70, whoosh: 65, combo: 60, spring: 55, break: 50, jump: 45, button: 40, coin: 20 },
	/* jump cooldown is SHORT so holding beans fires a toot on EVERY bounce —
	   the old 1.0s cooldown silently swallowed consecutive mega-toots, which
	   played as "the fart sound skips jumps" */
	COOLDOWN: { jump: 0.18, coin: 0.22, boing: 0.5, spring: 0.8, hurt: 0.5, powerup: 0.5, magnet: 1.0, combo: 0.7, gameover: 0.5, button: 0.15, break: 0.45, whoosh: 0.3 },
	/* some meme rips are full songs — cap how long each slot may hold the
	   stage. The fade is a long musical tail, not a chop (see play()).
	   magnet 1.9s = exactly the first "money follows my brother" phrase in
	   the 21s rip — the lyric IS the mechanic (coins fly to you). */
	MAX_DUR: { coin: 1.4, magnet: 1.9, button: 1.2, spring: 3.2, combo: 3.2, boing: 3.6, jump: 3.6, break: 3.2, hurt: 6, gameover: 6 },
	BLIP_MAX_PRIO: 40,

	_voices: {},
	_lastPlay: {},
	_rocketLoop: null,
	_musicTimer: null, _musicStep: 0, _musicNextT: 0,

	/* ------------------------------------------------------- lifecycle */
	init() {
		if (this.ready) return true;
		const AC = window.AudioContext || window.webkitAudioContext;
		if (!AC) return false;
		try {
			this.CTX = new AC();
		} catch (e) {
			return false;
		}

		this.master = this.CTX.createGain();
		this.master.gain.value = 0.9;
		this.master.connect(this.CTX.destination);

		this.sfxBus = this.CTX.createGain();
		this.sfxBus.connect(this.master);

		this.musicBus = this.CTX.createGain();
		this.musicBus.connect(this.master);

		for (const slot of this.SLOTS) {
			this.pools[slot] = { files: [], synth: [this.synthSlot(slot)] };
		}

		this.ready = true;
		this.applyVolumes();
		this.resume();
		this.loadFiles();

		// Android/iOS WebViews suspend the context when backgrounded
		document.addEventListener('visibilitychange', () => {
			if (!document.hidden) this.resume();
		});
		window.addEventListener('focus', () => this.resume());

		if (Storage.data.settings.music) this.startMusic();
		return true;
	},

	/* apply the saved volume sliders to the live buses (0..1 each) */
	applyVolumes() {
		if (!this.ready) return;
		const s = Storage.data.settings;
		this.sfxBus.gain.value = Math.max(0, Math.min(1, s.sfxVol !== undefined ? s.sfxVol : 0.9));
		this.musicBus.gain.value = Math.max(0, Math.min(1, s.musicVol !== undefined ? s.musicVol : 0.35)) * 0.4;
	},

	resume() {
		if (!this.CTX) return;
		if (this.CTX.state === 'suspended' || this.CTX.state === 'interrupted') {
			const p = this.CTX.resume();
			if (p && p.catch) p.catch(() => { /* needs another gesture */ });
		}
	},

	/* app minimized: the Capacitor WebView keeps the AudioContext running,
	   so the generated music + any meme tail keeps playing over the user's
	   other apps unless we suspend the context ourselves */
	suspend() {
		if (!this.CTX) return;
		if (this.CTX.state === 'running') {
			try { this.CTX.suspend(); } catch (e) { /* ignore */ }
		}
	},

	/* -------------------------------------------- manifest file loading */
	async loadFiles() {
		if (this.loaded) return;
		this.loaded = true;
		const base = 'assets/sounds/';

		let manifest = null;
		try {
			const res = await fetch(base + 'manifest.json', { cache: 'force-cache' });
			if (res.ok) manifest = await res.json();
		} catch (e) { /* no manifest — synths only */ }

		if (!manifest || !manifest.slots) return;
		this.memeNames = manifest.names || {};

		const jobs = [];
		for (const slot of this.SLOTS) {
			const list = manifest.slots[slot];
			if (!Array.isArray(list)) continue;
			for (const file of list) {
				jobs.push(this._loadOne(base + file, slot));
			}
		}
		// isolate failures: one unplayable file must not abort the batch
		await Promise.allSettled(jobs);

		// keep manifest order stable so slot.mp3 is variant 0
		for (const slot of this.SLOTS) {
			const pool = this.pools[slot];
			if (pool && pool.files.length) pool.files.sort((a, b) => a._ord - b._ord);
		}
	},

	async _loadOne(url, slot) {
		const res = await fetch(url, { cache: 'force-cache' });
		if (!res.ok) throw new Error('404 ' + url);
		const arr = await res.arrayBuffer();
		const buf = await this._decode(arr);
		if (!buf || !buf.length) return;
		buf._gain = this._normGain(buf);
		buf._ord = this.pools[slot].files.length;
		this.pools[slot].files.push(buf);
	},

	/* decodeAudioData has a callback form in old WebViews and a promise
	   form everywhere else — support both */
	_decode(arrayBuffer) {
		return new Promise((resolve, reject) => {
			let settled = false;
			const ok = (b) => { if (!settled) { settled = true; resolve(b); } };
			const bad = (e) => { if (!settled) { settled = true; reject(e || new Error('decode')); } };
			try {
				const maybe = this.CTX.decodeAudioData(arrayBuffer, ok, bad);
				if (maybe && typeof maybe.then === 'function') maybe.then(ok, bad);
			} catch (e) { bad(e); }
		});
	},

	/* loudness normalisation: scale so every clip hits the same RMS */
	_normGain(buf) {
		try {
			const ch = buf.getChannelData(0);
			let sum = 0, n = 0;
			for (let i = 0; i < ch.length; i += 16) { const s = ch[i]; sum += s * s; n++; }
			const rms = Math.sqrt(sum / Math.max(1, n));
			if (!rms || !isFinite(rms)) return 1;
			return Math.max(0.25, Math.min(4, 0.12 / rms));
		} catch (e) { return 1; }
	},

	/* ------------------------------------------------------ playback */
	_releaseVoice(slot, voice) {
		const cur = this._voices[slot];
		if (cur && cur.src === voice.src) delete this._voices[slot];
		try { voice.src.disconnect(); } catch (e) { /* already gone */ }
		try { voice.gain.disconnect(); } catch (e) { /* already gone */ }
	},

	_stopVoice(slot) {
		const v = this._voices[slot];
		if (!v) return;
		delete this._voices[slot];
		try {
			const now = this.CTX.currentTime;
			v.gain.gain.cancelScheduledValues(now);
			v.gain.gain.setTargetAtTime(0, now, 0.03);
			v.src.stop(now + 0.12);
		} catch (e) { /* already stopped */ }
		// disconnect after the fade so we never leak nodes
		setTimeout(() => {
			try { v.src.disconnect(); } catch (e) {}
			try { v.gain.disconnect(); } catch (e) {}
		}, 220);
	},

	play(slot, pitchVar = 0.12, vol = 1.0, force = false) {
		if (!this.ready || !Storage.data.settings.sfx) return;
		if (this.CTX.state === 'suspended') { this.resume(); return; }

		const pool = this.pools[slot];
		if (!pool) return;

		const now = this.CTX.currentTime;
		const cd = this.COOLDOWN[slot] || 0.08;
		if (this._lastPlay[slot] !== undefined && now - this._lastPlay[slot] < cd) return;

		const prio = (this.PRIORITY[slot] || 50) + (force ? 60 : 0);
		const isBlip = prio <= this.BLIP_MAX_PRIO;

		// stage rules: one real sound at a time. Blips (coin/button) no
		// longer wait for the stage to clear — they used to be fully blocked,
		// which played as "the coin sound fired late". They now duck to a
		// quiet background level and play immediately.
		// `force` (bean mega-toots) outranks whatever holds the stage so the
		// fart is NEVER swallowed by a lingering combo/spring meme.
		let duck = 1;
		for (const s of Object.keys(this._voices)) {
			const vp = this.PRIORITY[s] || 50;
			if (vp <= this.BLIP_MAX_PRIO) continue;  // other blips can coexist
			if (isBlip) { duck = 0.35; continue; }   // duck under the big sound
			if (prio >= vp) this._stopVoice(s);      // equal-or-bigger takes over — never the reverse
			else return;                             // smaller event waits
		}
		this._lastPlay[slot] = now;

		const list = pool.files.length ? pool.files : pool.synth;
		const buf = list[(Math.random() * list.length) | 0];
		if (!buf) return;

		let src, g;
		try {
			src = this.CTX.createBufferSource();
			src.buffer = buf;
			src.playbackRate.value = Math.max(0.25, 1 + (Math.random() * 2 - 1) * pitchVar);
			g = this.CTX.createGain();
			g.gain.value = Math.max(0, vol) * duck * (buf._gain || 1);
			src.connect(g);
			g.connect(this.sfxBus);
			src.start();
		} catch (e) {
			return;
		}

		const voice = { src, gain: g };
		this._voices[slot] = voice;

		// duration cap — a long fade-out tail so the clip feels finished,
		// not chopped off mid-word
		const cap = this.MAX_DUR[slot];
		if (cap && buf.duration / src.playbackRate.value > cap) {
			try {
				const t0 = this.CTX.currentTime;
				const fadeAt = t0 + Math.max(0.2, cap - 0.55);
				g.gain.setTargetAtTime(0, fadeAt, 0.17);
				src.stop(t0 + cap + 0.15);
			} catch (e) { /* ignore */ }
		}

		src.onended = () => this._releaseVoice(slot, voice);
	},

	/* looping rocket whoosh */
	startRocket() {
		if (!this.ready || !Storage.data.settings.sfx || this._rocketLoop) return;
		const pool = this.pools.whoosh;
		if (!pool) return;
		const list = pool.files.length ? pool.files : pool.synth;
		const buf = list[0];
		if (!buf) return;
		try {
			const src = this.CTX.createBufferSource();
			src.buffer = buf;
			src.loop = true;
			const g = this.CTX.createGain();
			g.gain.value = 0.5 * (buf._gain || 1);
			src.connect(g);
			g.connect(this.sfxBus);
			src.start();
			this._rocketLoop = { src, gain: g };
			// keep it out of _voices: a slot collision used to orphan the loop
			// and leave a permanent whoosh playing under everything
		} catch (e) { /* ignore */ }
	},

	stopRocket() {
		const r = this._rocketLoop;
		if (!r) return;
		this._rocketLoop = null;
		try {
			const now = this.CTX.currentTime;
			r.gain.gain.cancelScheduledValues(now);
			r.gain.gain.setTargetAtTime(0, now, 0.05);
			r.src.stop(now + 0.2);
		} catch (e) { /* already stopped */ }
		setTimeout(() => {
			try { r.src.disconnect(); } catch (e) {}
			try { r.gain.disconnect(); } catch (e) {}
		}, 320);
	},

	/* Vibration.

	   Browsers reject navigator.vibrate() until the frame has seen a real
	   user gesture and log an intervention warning when you try — the old
	   build fired haptics from the autopilot/smoke path and produced exactly
	   that console noise. Gate it on the same gesture that unlocks audio. */
	gestured: false,

	noteGesture() { this.gestured = true; },

	haptic(ms) {
		if (!this.gestured) return;
		if (!Storage.data.settings.haptics) return;
		if (!navigator.vibrate) return;
		try {
			navigator.vibrate(ms);
		} catch (e) { /* blocked by permissions policy */ }
	},

	stopAll() {
		this.stopRocket();
		for (const s of Object.keys(this._voices)) this._stopVoice(s);
		this._lastPlay = {};
	},

	/* ============================================= synthesized comedy */
	synthSlot(slot) {
		switch (slot) {
			case 'jump':     return this.buf(this.synthFart());
			case 'hurt':     return this.buf(this.synthScream());
			case 'spring':   return this.buf(this.synthChirp());
			case 'break':    return this.buf(this.synthCrack());
			case 'boing':    return this.buf(this.synthBoing());
			case 'gameover': return this.buf(this.synthTrombone());
			case 'coin':     return this.buf(this.synthCoin());
			case 'powerup':  return this.buf(this.synthPowerup());
			case 'magnet':   return this.buf(this.synthPowerup());
			case 'button':   return this.buf(this.synthBlip());
			case 'combo':    return this.buf(this.synthCombo());
			case 'whoosh':   return this.buf(this.synthWhoosh());
		}
		return this.buf(this.synthBlip());
	},

	buf(samples) {
		const b = this.CTX.createBuffer(1, samples.length, this.RATE);
		b.copyToChannel(samples, 0);
		b._gain = this._normGain(b);
		b._ord = 0;
		return b;
	},

	_lcg(seed) {
		let s = seed | 0;
		return () => {
			s = (Math.imul(s, 1103515245) + 12345) & 0x7fffffff;
			return (s / 0x3fffffff) - 1;
		};
	},

	/* Classic bubbly toot — random-walking low frequency with wobble. */
	synthFart() {
		const n = Math.floor(this.RATE * 0.38);
		const out = new Float32Array(n);
		const rnd = this._lcg(20260823);
		let freq = 88, phase = 0, lp = 0;
		for (let i = 0; i < n; i++) {
			const t = i / this.RATE;
			freq = Math.min(128, Math.max(62, freq + rnd() * 7));
			phase += freq / this.RATE;
			const saw = (phase % 1) * 2 - 1;
			const raw = Math.sin(phase * Math.PI * 2) * 0.72 + saw * 0.28;
			lp += (raw - lp) * 0.34;
			const env = Math.min(1, t / 0.018) * Math.exp(-t * 7.5);
			const wob = 0.74 + 0.26 * Math.sin(Math.PI * 2 * 27 * t);
			out[i] = (lp + rnd() * 0.06) * env * wob;
		}
		return out;
	},

	/* Dramatic cartoon "AAAAH!" — gliding pitch with vibrato. */
	synthScream() {
		const dur = 0.55, n = Math.floor(this.RATE * dur);
		const out = new Float32Array(n);
		let phase = 0;
		for (let i = 0; i < n; i++) {
			const t = i / this.RATE;
			let f = 760 * Math.pow(210 / 760, t / dur);
			f += 42 * Math.sin(Math.PI * 2 * 27 * t);
			phase += f / this.RATE;
			const sq = Math.sin(phase * Math.PI * 2) * 2.4;
			const voice = sq / (1 + Math.abs(sq));
			let env = Math.min(1, t / 0.012);
			if (t > dur * 0.62) env *= Math.max(0, 1 - (t - dur * 0.62) / (dur * 0.38));
			out[i] = voice * env * 0.85;
		}
		return out;
	},

	/* Springy rising boiiing. */
	synthChirp() {
		const dur = 0.24, n = Math.floor(this.RATE * dur);
		const out = new Float32Array(n);
		let phase = 0;
		for (let i = 0; i < n; i++) {
			const t = i / this.RATE;
			const f = 190 * Math.pow(980 / 190, t / dur);
			phase += f / this.RATE;
			const env = Math.min(1, t / 0.008) * Math.exp(-t * 9);
			out[i] = Math.sin(phase * Math.PI * 2) * env * 0.8;
		}
		return out;
	},

	/* Crumbly crack. */
	synthCrack() {
		const dur = 0.2, n = Math.floor(this.RATE * dur);
		const out = new Float32Array(n);
		const rnd = this._lcg(777);
		let lp = 0;
		for (let i = 0; i < n; i++) {
			const t = i / this.RATE;
			const mix = 0.92 + (0.16 - 0.92) * (t / dur);
			lp += (rnd() - lp) * mix;
			out[i] = lp * Math.exp(-t * 17) * 0.95;
		}
		return out;
	},

	/* Rubber-boing squash. */
	synthBoing() {
		const dur = 0.32, n = Math.floor(this.RATE * dur);
		const out = new Float32Array(n);
		let phase = 0;
		for (let i = 0; i < n; i++) {
			const t = i / this.RATE;
			const f = 295 - 165 * Math.sin(Math.PI * 2 * 11.5 * t) * (1 - t / dur) - 40 * t;
			phase += Math.max(60, f) / this.RATE;
			const env = Math.min(1, t / 0.006) * Math.exp(-t * 8);
			out[i] = Math.sin(phase * Math.PI * 2) * env * 0.85;
		}
		return out;
	},

	/* Sad trombone wah-wah-waaah. */
	synthTrombone() {
		const notes = [233.08, 207.65, 174.61, 0];
		const durs = [0.26, 0.26, 0.26, 0.62];
		const total = durs.reduce((a, b) => a + b, 0);
		const n = Math.floor(this.RATE * total);
		const out = new Float32Array(n);
		let idx = 0, tNote = 0, phase = 0, fCur = notes[0];
		for (let i = 0; i < n; i++) {
			tNote += 1 / this.RATE;
			if (tNote > durs[idx] && idx < notes.length - 1) { tNote = 0; idx++; }
			const target = notes[idx];
			let fTarget = target > 0 ? target : fCur * 0.86;
			if (idx === notes.length - 1 && tNote > durs[idx] * 0.45) fTarget = fCur * 0.995;
			fCur += (fTarget - fCur) * 0.18;
			phase += fCur / this.RATE;
			const sq = Math.sin(phase * Math.PI * 2) * 1.7 + Math.sin(phase * Math.PI * 4) * 0.35;
			const voice = sq / (1 + Math.abs(sq));
			const dn = durs[idx];
			const env = Math.min(1, tNote / 0.03) * (1 - Math.max(0, tNote - dn * 0.7) / (dn * 0.3));
			out[i] = Math.max(-1, Math.min(1, voice * env * 0.8));
		}
		return out;
	},

	/* Bright two-tone coin ding. */
	synthCoin() {
		const n = Math.floor(this.RATE * 0.16);
		const out = new Float32Array(n);
		for (let i = 0; i < n; i++) {
			const t = i / this.RATE;
			const f = t < 0.07 ? 1318.5 : 1975.5;
			const env = Math.min(1, t / 0.004) * Math.exp(-t * 16);
			out[i] = Math.sin(Math.PI * 2 * f * t) * env * 0.55;
		}
		return out;
	},

	/* Rising powerup arpeggio. */
	synthPowerup() {
		const notes = [392, 523.3, 659.3, 784, 1046.5];
		const per = 0.07, n = Math.floor(this.RATE * per * notes.length + this.RATE * 0.25);
		const out = new Float32Array(n);
		for (let i = 0; i < n; i++) {
			const t = i / this.RATE;
			const idx = Math.min(notes.length - 1, Math.floor(t / per));
			const tn = t - idx * per;
			const env = Math.min(1, tn / 0.006) * Math.exp(-tn * 7);
			out[i] = (Math.sin(Math.PI * 2 * notes[idx] * t) * 0.6 + Math.sin(Math.PI * 4 * notes[idx] * t) * 0.2) * env * 0.7;
		}
		return out;
	},

	/* UI tap blip. */
	synthBlip() {
		const dur = 0.08, n = Math.floor(this.RATE * dur);
		const out = new Float32Array(n);
		let phase = 0;
		for (let i = 0; i < n; i++) {
			const t = i / this.RATE;
			const f = 680 + (500 - 680) * (t / dur);
			phase += f / this.RATE;
			out[i] = Math.sin(phase * Math.PI * 2) * Math.exp(-t * 30) * 0.6;
		}
		return out;
	},

	/* Combo jingle. */
	synthCombo() {
		const notes = [523.3, 659.3, 784];
		const per = 0.055, n = Math.floor(this.RATE * per * notes.length + this.RATE * 0.12);
		const out = new Float32Array(n);
		for (let i = 0; i < n; i++) {
			const t = i / this.RATE;
			const idx = Math.min(notes.length - 1, Math.floor(t / per));
			const tn = t - idx * per;
			const env = Math.min(1, tn / 0.004) * Math.exp(-tn * 9);
			out[i] = Math.sin(Math.PI * 2 * notes[idx] * t) * env * 0.6;
		}
		return out;
	},

	/* Airy rocket whoosh (loops seamlessly). */
	synthWhoosh() {
		const dur = 1.2, n = Math.floor(this.RATE * dur);
		const out = new Float32Array(n);
		const rnd = this._lcg(4242);
		let lp = 0;
		for (let i = 0; i < n; i++) {
			const t = i / this.RATE;
			const mix = 0.3 + 0.25 * Math.sin(Math.PI * 2 * t / dur);
			lp += (rnd() - lp) * mix;
			const env = 0.7 + 0.3 * Math.sin(Math.PI * 2 * 2 * t / dur - Math.PI / 2);
			out[i] = lp * env * 0.8;
		}
		// crossfade the seam so the loop has no click
		const xf = Math.floor(this.RATE * 0.04);
		for (let i = 0; i < xf; i++) {
			const a = i / xf;
			out[i] = out[i] * a + out[n - xf + i] * (1 - a);
		}
		return out;
	},

	/* ============================================= generative music */
	_CHORDS: [0, -5, -9, -7, 0, -5, -7, -5],
	_MEL: {
		0: 12, 2: 16, 4: 19, 6: 16, 8: 21, 10: 19, 12: 16, 14: 19,
		16: 24, 18: 21, 20: 19, 22: 16, 24: 19, 26: 16, 28: 14, 30: 12,
	},

	startMusic() {
		if (!this.ready || this._musicTimer) return;
		this._musicStep = 0;
		this._musicNextT = this.CTX.currentTime + 0.1;
		this._musicTimer = setInterval(() => this._musicTick(), 60);
	},

	stopMusic() {
		if (this._musicTimer) { clearInterval(this._musicTimer); this._musicTimer = null; }
	},

	_musicTick() {
		if (!this.CTX || !Storage.data.settings.music) { this.stopMusic(); return; }
		if (this.CTX.state !== 'running') return;
		const bpm = 132, stepDur = (60 / bpm) / 4;
		// if the context was suspended for a while, don't try to catch up
		if (this._musicNextT < this.CTX.currentTime - 0.5) {
			this._musicNextT = this.CTX.currentTime + 0.05;
		}
		let guard = 0;
		while (this._musicNextT < this.CTX.currentTime + 0.18 && guard++ < 64) {
			this._scheduleStep(this._musicStep, this._musicNextT, stepDur);
			this._musicStep = (this._musicStep + 1) % 128;
			this._musicNextT += stepDur;
		}
	},

	_note(freq, when, dur, type, vol, filterHz) {
		const o = this.CTX.createOscillator();
		o.type = type;
		o.frequency.value = freq;
		const g = this.CTX.createGain();
		g.gain.setValueAtTime(0, when);
		g.gain.linearRampToValueAtTime(vol, when + 0.015);
		g.gain.exponentialRampToValueAtTime(0.001, when + dur);
		let node = o;
		let filter = null;
		if (filterHz) {
			filter = this.CTX.createBiquadFilter();
			filter.type = 'lowpass';
			filter.frequency.value = filterHz;
			o.connect(filter);
			node = filter;
		}
		node.connect(g);
		g.connect(this.musicBus);
		o.start(when);
		o.stop(when + dur + 0.05);
		o.onended = () => {
			try { o.disconnect(); } catch (e) {}
			try { if (filter) filter.disconnect(); } catch (e) {}
			try { g.disconnect(); } catch (e) {}
		};
	},

	_hat(when, vol) {
		const len = Math.floor(this.RATE * 0.04);
		const b = this.CTX.createBuffer(1, len, this.RATE);
		const d = b.getChannelData(0);
		for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.exp(-i / len * 9);
		const s = this.CTX.createBufferSource();
		s.buffer = b;
		const f = this.CTX.createBiquadFilter();
		f.type = 'highpass';
		f.frequency.value = 6000;
		const g = this.CTX.createGain();
		g.gain.value = vol;
		s.connect(f); f.connect(g); g.connect(this.musicBus);
		s.start(when);
		s.onended = () => {
			try { s.disconnect(); } catch (e) {}
			try { f.disconnect(); } catch (e) {}
			try { g.disconnect(); } catch (e) {}
		};
	},

	_scheduleStep(step, when, stepDur) {
		const bar = Math.floor(step / 16) % this._CHORDS.length;
		const root = 261.63 * Math.pow(2, this._CHORDS[bar] / 12);
		if (step % 2 === 0) {
			const oct = (step % 4 === 0) ? 0.5 : 1;
			this._note(root * 0.5 * (step % 8 === 6 ? 1.5 : oct), when, stepDur * 1.8, 'triangle', 0.5);
		}
		const s32 = step % 32;
		const off = this._MEL[s32];
		if (off !== undefined && (step % 2 === 0)) {
			const f = 261.63 * Math.pow(2, (off + this._CHORDS[bar]) / 12);
			this._note(f, when, stepDur * 1.6, 'square', 0.16, 1400);
		}
		if (step % 2 === 1) this._hat(when, step % 8 === 3 ? 0.10 : 0.05);
	},
};

if (typeof module !== 'undefined' && module.exports) module.exports = { SFX };
