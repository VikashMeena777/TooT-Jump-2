'use strict';
/* ============================================================
   FX — particles, floating text, screen shake, hit-stop.

   Fixes vs the previous build:
   - HARD CAPS on particles and floaters (CFG.MAX_PARTICLES /
     MAX_FLOATS). The old version was unbounded: a rocket + magnet
     + confetti + milestone burst could push 900+ particles and drop
     a mid-range phone to ~20fps with no way to recover.
   - the shake offset is generated ONCE per frame instead of per
     draw call, and it decays in real time so hit-stop can't freeze
     the shake into a static offset.
   - pools are bounded too, so a long session can't grow them
     without limit.
   ============================================================ */
const FX = {
	parts: [],
	floats: [],
	shake: 0,
	hitstop: 0,
	killcamT: 0,     // slow-mo kill cam: seconds remaining (real time)
	zoom: 1,         // camera zoom about the player during kill cam
	flashT: 0,       // white screen flash (new best, golden pickup)
	shakeX: 0,
	shakeY: 0,

	_partPool: [],
	_floatPool: [],
	POOL_MAX: 400,

	burst(x, y, opts) {
		opts = opts || {};
		const room = CFG.MAX_PARTICLES - this.parts.length;
		if (room <= 0) return;
		const n = Math.min(opts.n || 10, room);
		const spread = opts.spread !== undefined ? opts.spread : 20;
		const speed = opts.speed !== undefined ? opts.speed : 200;
		const baseAngle = opts.baseAngle || 0;
		const colorArr = Array.isArray(opts.color) ? opts.color : null;

		for (let i = 0; i < n; i++) {
			const p = this._partPool.pop() || {};
			const a = baseAngle + Math.random() * Math.PI * 2;
			const sp = speed * (0.4 + Math.random() * 0.9);
			p.x = x + (Math.random() - 0.5) * spread;
			p.y = y + (Math.random() - 0.5) * spread;
			p.vx = Math.cos(a) * sp;
			p.vy = Math.sin(a) * sp - (opts.up || 0);
			p.life = p.maxLife = (opts.life || 0.6) * (0.7 + Math.random() * 0.6);
			p.r = (opts.r || 8) * (0.5 + Math.random());
			p.color = colorArr
				? colorArr[(Math.random() * colorArr.length) | 0]
				: (opts.color || '#fff');
			p.grav = opts.grav !== undefined ? opts.grav : 500;
			p.shape = opts.shape || 'circle';
			p.spin = Math.random() * Math.PI * 2;
			this.parts.push(p);
		}
	},

	text(x, y, str, opts) {
		opts = opts || {};
		// drop the oldest floater rather than refusing new feedback
		if (this.floats.length >= CFG.MAX_FLOATS) {
			this._recycleFloat(0);
		}
		const f = this._floatPool.pop() || {};
		f.x = x; f.y = y;
		f.str = String(str);
		f.vy = opts.vy !== undefined ? opts.vy : -110;
		f.life = f.maxLife = opts.life || 1.0;
		f.color = opts.color || '#fff9ee';
		f.size = opts.size || 34;
		f.stroke = opts.stroke !== false;
		// draw a vector coin after the text instead of the 🪙 emoji, which is
		// an Emoji 12 codepoint and shows as a tofu box on Android 7-9
		f.coin = !!opts.coin;
		this.floats.push(f);
	},

	confetti(x, y) {
		const cols = ['#ff6f61', '#ffd166', '#59cd90', '#5aa9e6', '#c4a6ec'];
		this.burst(x, y, { n: 34, speed: 420, up: 260, r: 7, life: 1.3, grav: 700, color: cols, shape: 'rect' });
	},

	kick(amt) { this.shake = Math.max(this.shake, amt); },
	freeze(amt) { this.hitstop = Math.max(this.hitstop, amt); },
	flash(amt) { this.flashT = Math.max(this.flashT, amt); },

	/* slow-mo with zoom about the player.
	   kill cam (stomp): 0.5s · 1.18x — the flattening deserves ceremony.
	   near miss: 0.18s · 1.08x — a quick "CLOSE ONE!" breath. */
	startKillcam() {
		this.startSlowmo(0.5, 1.18);
	},

	startSlowmo(dur, zoom) {
		// a longer slow-mo in progress always wins
		if (dur >= this.killcamT) {
			this.killcamT = dur;
			this.zoom = Math.max(this.zoom, zoom);
		}
	},

	/* real-time ticker (unscaled dt) — shake/hitstop/killcam must not be
	   slowed by the very slow-mo they trigger */
	tickReal(dt) {
		if (this.killcamT > 0) this.killcamT = Math.max(0, this.killcamT - dt);
		if (this.zoom > 1.0005) {
			this.zoom += (1 - this.zoom) * Math.min(1, dt * 3.2);
		} else {
			this.zoom = 1;
		}
		if (this.flashT > 0) this.flashT = Math.max(0, this.flashT - dt * 2.2);
		this.hitstop = Math.max(0, this.hitstop - dt);
		this.shake = Math.max(0, this.shake - dt * 2.4);

		// one shake sample per frame: sampling per-draw made the whole scene
		// jitter incoherently instead of shaking as one image
		if (this.shake > 0.001) {
			const amt = this.shake * 26;
			this.shakeX = (Math.random() - 0.5) * amt;
			this.shakeY = (Math.random() - 0.5) * amt;
		} else {
			this.shakeX = this.shakeY = 0;
		}
	},

	_recyclePart(i) {
		const p = this.parts[i];
		this.parts.splice(i, 1);
		if (this._partPool.length < this.POOL_MAX) this._partPool.push(p);
	},

	_recycleFloat(i) {
		const f = this.floats[i];
		this.floats.splice(i, 1);
		if (this._floatPool.length < this.POOL_MAX) this._floatPool.push(f);
	},

	update(dt) {
		for (let i = this.parts.length - 1; i >= 0; i--) {
			const p = this.parts[i];
			p.life -= dt;
			if (p.life <= 0) { this._recyclePart(i); continue; }
			p.vy += p.grav * dt;
			p.x += p.vx * dt;
			p.y += p.vy * dt;
		}
		for (let i = this.floats.length - 1; i >= 0; i--) {
			const f = this.floats[i];
			f.life -= dt;
			if (f.life <= 0) { this._recycleFloat(i); continue; }
			f.y += f.vy * dt;
			f.vy *= (1 - Math.min(0.9, dt * 1.5));
		}
	},

	clear() {
		while (this.parts.length) this._recyclePart(this.parts.length - 1);
		while (this.floats.length) this._recycleFloat(this.floats.length - 1);
		this.shake = 0;
		this.shakeX = this.shakeY = 0;
		this.hitstop = 0;
		this.killcamT = 0;
		this.zoom = 1;
		this.flashT = 0;
	},

	/* world-space draw */
	draw(ctx) {
		for (let i = 0; i < this.parts.length; i++) {
			const p = this.parts[i];
			const a = Math.max(0, Math.min(1, p.life / (p.maxLife * 0.6)));
			ctx.globalAlpha = a;
			ctx.fillStyle = p.color;
			if (p.shape === 'rect') {
				ctx.save();
				ctx.translate(p.x, p.y);
				ctx.rotate(p.spin + p.life * 7);
				ctx.fillRect(-p.r, -p.r * 0.6, p.r * 2, p.r * 1.2);
				ctx.restore();
			} else {
				ctx.beginPath();
				ctx.arc(p.x, p.y, Math.max(0.5, p.r * a), 0, Math.PI * 2);
				ctx.fill();
			}
		}
		ctx.globalAlpha = 1;

		if (this.floats.length) {
			ctx.textBaseline = 'alphabetic';
			ctx.lineJoin = 'round';
			for (let i = 0; i < this.floats.length; i++) {
				const f = this.floats[i];
				ctx.globalAlpha = Math.max(0, Math.min(1, f.life * 2.5));
				ctx.font = `800 ${f.size}px "Baloo 2", "Comic Sans MS", sans-serif`;

				if (f.coin) {
					// text + coin, centred together as one unit
					const r = f.size * 0.36;
					const gap = f.size * 0.22;
					const tw = ctx.measureText(f.str).width;
					const total = tw + gap + r * 2;
					const left = f.x - total / 2;
					ctx.textAlign = 'left';
					if (f.stroke) {
						ctx.lineWidth = f.size * 0.18;
						ctx.strokeStyle = '#232a45';
						ctx.strokeText(f.str, left, f.y);
					}
					ctx.fillStyle = f.color;
					ctx.fillText(f.str, left, f.y);
					ctx.save();
					ctx.translate(left + tw + gap + r, f.y - f.size * 0.3);
					drawCoinIcon(ctx, r);
					ctx.restore();
				} else {
					ctx.textAlign = 'center';
					if (f.stroke) {
						ctx.lineWidth = f.size * 0.18;
						ctx.strokeStyle = '#232a45';
						ctx.strokeText(f.str, f.x, f.y);
					}
					ctx.fillStyle = f.color;
					ctx.fillText(f.str, f.x, f.y);
				}
			}
			ctx.globalAlpha = 1;
			ctx.textAlign = 'left';
		}
	},
};

if (typeof module !== 'undefined' && module.exports) module.exports = { FX };
