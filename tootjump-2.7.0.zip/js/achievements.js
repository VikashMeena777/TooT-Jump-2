'use strict';
/* ============================================================
   Achievements — a badge wall with unlock toasts.

   Badges are checked against the save data (never against live
   frame state), so checking is idempotent and cheap: call
   Achievements.check() after each run and from the menu.
   ============================================================ */
const Achievements = {
	DEFS: [
		{ id: 'first-blood', name: 'FIRST BLOOD', desc: 'Stomp your first grump', icon: '🥾',
			check: d => d.stats.stomps >= 1 },
		{ id: 'grumper', name: 'GRUMPER', desc: 'Stomp 10 grumps total', icon: '😤',
			check: d => d.stats.stomps >= 10 },
		{ id: 'grumpocalypse', name: 'GRUMPOCALYPSE', desc: 'Stomp 100 grumps total', icon: '☄️',
			check: d => d.stats.stomps >= 100 },
		{ id: 'liftoff', name: 'LIFTOFF', desc: 'Reach 500 m', icon: '🚀',
			check: d => d.best >= 500 },
		{ id: 'stratosphere', name: 'STRATOSPHERE', desc: 'Reach 1000 m', icon: '🌍',
			check: d => d.best >= 1000 },
		{ id: 'astronaut', name: 'Certified Astronaut', desc: 'Find the space zone', icon: '🧑‍🚀',
			check: d => d.best >= 2200 },
		{ id: 'toot-god', name: 'TOOT GOD', desc: 'Hit the TOOT GOD combo', icon: '👑',
			check: d => d.bestTier >= 4 },
		{ id: 'sheesh', name: 'SHEEESH', desc: 'Reach the SHEEESH combo', icon: '🥶',
			check: d => d.bestTier >= 2 },
		{ id: 'close-caller', name: 'DANGER ADDICT', desc: '10 near-misses', icon: '😰',
			check: d => d.stats.closeCalls >= 10 },
		{ id: 'chappal-proof', name: 'CHAPPAL-PROOF', desc: 'Survive 25 hits', icon: '🩴',
			check: d => d.stats.hits >= 25 },
		{ id: 'golden-touch', name: 'GOLDEN TOUCH', desc: 'Grab the golden poop', icon: '💫',
			check: d => d.stats.golden >= 1 },
		{ id: 'tootillionaire', name: 'Tootillionaire', desc: 'Earn 1000 coins total', icon: '💰',
			check: d => d.stats.coins >= 1000 },
		{ id: 'devoted', name: 'DEVOTED TOOTER', desc: '3-day daily streak', icon: '🔥',
			check: d => d.daily.streak >= 3 },
		{ id: 'regular', name: 'REGULAR HERE', desc: 'Play 25 runs', icon: '🎟️',
			check: d => d.runs >= 25 },
	],

	check() {
		const d = Storage.data;
		const gained = [];
		for (const a of this.DEFS) {
			if (d.achievements.includes(a.id)) continue;
			let ok = false;
			try { ok = a.check(d); } catch (e) { ok = false; }
			if (ok) {
				d.achievements.push(a.id);
				gained.push(a);
			}
		}
		if (gained.length) {
			Storage.save();
			if (typeof UI !== 'undefined' && UI.toast) {
				for (const a of gained) UI.toast(`🏆 ${a.name} — ${a.desc}`);
				SFX.play('powerup', 0.05, 0.9);
			}
		}
		return gained;
	},
};

if (typeof module !== 'undefined' && module.exports) module.exports = { Achievements };
