'use strict';
/* ============================================================
   ShareCard — renders the score card to a canvas and hands the
   PNG to the native share sheet (WhatsApp etc).

   Route order:
   1. Capacitor Share plugin (files:) — needs @capacitor/share +
      @capacitor/filesystem, used when running inside the APK.
   2. navigator.share({files}) — Web Share L2, works on many
      Android WebViews directly.
   3. text-only share / clipboard fallback (previous behaviour).

   The card is drawn at 1080x1350 (4:5, WhatsApp-friendly) with
   the character rendered big, the score, the zone reached and a
   "beat that" tail.
   ============================================================ */
const ShareCard = {
	W: 1080,
	H: 1350,

	/* main entry — call from the game-over screen */
	async share(score, isNewBest, dailyBest) {
		const canvas = this.render(score, isNewBest, dailyBest);
		const dataUrl = canvas.toDataURL('image/png');

		// 1. Capacitor native share (APK build)
		if (window.Capacitor && window.Capacitor.isPluginAvailable && window.Capacitor.isPluginAvailable('Share')) {
			try {
				await this._capacitorShare(dataUrl);
				return;
			} catch (e) { /* user cancelled or plugin failed — fall through */ }
		}

		// 2. Web Share Level 2 with files
		try {
			if (navigator.canShare) {
				const blob = await this._toBlob(canvas);
				const file = new File([blob], 'toot-jump-score.png', { type: 'image/png' });
				if (navigator.canShare({ files: [file] })) {
					await navigator.share({
						files: [file],
						title: 'TOOT JUMP 2',
						text: this._text(score, isNewBest, dailyBest),
					});
					return;
				}
			}
		} catch (e) { return; /* user cancelled the sheet */ }

		// 3. text-only
		try {
			if (navigator.share) {
				await navigator.share({ title: 'TOOT JUMP 2', text: this._text(score, isNewBest, dailyBest) });
				return;
			}
		} catch (e) { return; }
		try {
			await navigator.clipboard.writeText(this._text(score, isNewBest, dailyBest));
			UI.toast('score copied to clipboard! 📋');
		} catch (e) {
			UI.toast(this._text(score, isNewBest, dailyBest));
		}
	},

	_text(score, isNewBest, dailyBest) {
		let t = `I tooted ${score} m into the sky in TOOT JUMP 2 💨 beat that.`;
		if (isNewBest) t += ' NEW PERSONAL BEST! 🏆';
		if (dailyBest) t += ` (daily challenge: ${dailyBest} m)`;
		return t;
	},

	/* write base64 to the Cache dir and share the file:// URI.
	   Two Capacitor realities this must respect (both previously broke the
	   whole image route and silently fell back to a text share):
	   1. Filesystem.writeFile wants RAW base64 — a data:image/png;base64,
	      URL produces a corrupt file.
	   2. The Directory enum only exists when you import @capacitor/filesystem
	      as a module. This game uses global script tags, so pass the enum's
	      underlying string value ('CACHE') directly. */
	async _capacitorShare(dataUrl) {
		const { Share } = window.Capacitor.Plugins;
		const { Filesystem } = window.Capacitor.Plugins;
		const base64 = dataUrl.slice(dataUrl.indexOf(',') + 1);
		const { uri } = await Filesystem.writeFile({
			path: 'toot-jump-score.png',
			data: base64,
			directory: 'CACHE',
		});
		await Share.share({ files: [uri], dialogTitle: 'Share your toot' });
	},

	_toBlob(canvas) {
		return new Promise((res, rej) => {
			if (canvas.toBlob) canvas.toBlob(b => b ? res(b) : rej(new Error('toBlob null')), 'image/png');
			else rej(new Error('no toBlob'));
		});
	},

	/* -------------------------------------------------- the card itself */
	render(score, isNewBest, dailyBest) {
		const c = document.createElement('canvas');
		c.width = this.W; c.height = this.H;
		const g = c.getContext('2d');
		const W = this.W, H = this.H;

		// sky straight from the zone palette
		const m = score;
		const zs = CFG.ZONES;
		let zi = 0;
		for (let k = 0; k < zs.length; k++) if (m >= zs[k].m) zi = k;
		const z = zs[zi];
		const grad = g.createLinearGradient(0, 0, 0, H);
		grad.addColorStop(0, z.top);
		grad.addColorStop(0.62, z.mid);
		grad.addColorStop(1, z.bot);
		g.fillStyle = grad;
		g.fillRect(0, 0, W, H);

		// a few stars in the night zones
		if (z.stars > 0) {
			g.fillStyle = 'rgba(255,255,255,0.8)';
			let seed = 7;
			const rnd = () => { seed = (Math.imul(seed, 48271)) & 0x7fffffff; return seed / 0x7fffffff; };
			for (let i = 0; i < 70; i++) {
				g.beginPath();
				g.arc(rnd() * W, rnd() * H * 0.7, 1 + rnd() * 2.4, 0, Math.PI * 2);
				g.fill();
			}
		}

		// hero character, huge, centre
		g.save();
		g.translate(W / 2, H * 0.40);
		g.scale(7.2, 7.2);
		drawCharacter(g, CharacterArt.byId(Storage.data.selected), {
			t: 0.6, vy: -650, blinkSeed: 2.2,
		});
		g.restore();

		// the equipped hat, same mount maths as in-game
		const hatId = Storage.data.hats.equipped;
		if (hatId && hatId !== 'none') {
			g.save();
			g.translate(W / 2, H * 0.40 - 34 * 7.2);
			drawHat(g, HATS.byId(hatId), 0, 0, 22 * 7.2);
			g.restore();
		}

		// title
		g.textAlign = 'center';
		g.textBaseline = 'alphabetic';
		g.fillStyle = '#232a45';
		g.font = '800 92px "Baloo 2", "Comic Sans MS", sans-serif';
		g.fillText('TOOT JUMP 2', W / 2, 150);
		g.font = '800 44px "Baloo 2", sans-serif';
		g.fillStyle = 'rgba(35,42,69,0.75)';
		g.fillText('💨 the fart-powered climber', W / 2, 210);

		// big score plate
		g.fillStyle = '#fff9ee';
		g.strokeStyle = '#232a45';
		g.lineWidth = 8;
		g.beginPath();
		g.roundRect(W / 2 - 330, H * 0.62, 660, 190, 36);
		g.fill(); g.stroke();
		g.fillStyle = '#232a45';
		g.font = '800 120px "Baloo 2", sans-serif';
		g.fillText(score + ' m', W / 2, H * 0.62 + 128);
		g.font = '800 38px "Baloo 2", sans-serif';
		g.fillStyle = 'rgba(35,42,69,0.7)';
		g.fillText(`reached ${z.name}`, W / 2, H * 0.62 + 172);

		// badges
		if (isNewBest) this._pill(g, W / 2, H * 0.62 + 250, '🏆 NEW BEST!', '#ffd166');
		else if (dailyBest) this._pill(g, W / 2, H * 0.62 + 250, `DAILY BEST ${dailyBest} m`, '#8ec4f2');

		// tail
		g.fillStyle = '#232a45';
		g.font = '800 52px "Baloo 2", sans-serif';
		g.fillText('beat that. I dare you 😏', W / 2, H - 90);

		return c;
	},

	_pill(g, x, y, text, bg) {
		g.font = '800 40px "Baloo 2", sans-serif';
		const w = g.measureText(text).width + 70;
		g.fillStyle = bg;
		g.strokeStyle = '#232a45';
		g.lineWidth = 6;
		g.beginPath();
		g.roundRect(x - w / 2, y - 52, w, 72, 36);
		g.fill(); g.stroke();
		g.fillStyle = '#232a45';
		g.textBaseline = 'middle';
		g.fillText(text, x, y + 14);
		g.textBaseline = 'alphabetic';
	},
};

if (typeof module !== 'undefined' && module.exports) module.exports = { ShareCard };
