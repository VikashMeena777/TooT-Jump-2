'use strict';
/* ============================================================
   Persistent save — coins, unlocks, missions, settings, stats.

   Hardened vs the previous build:
   - every field is validated & coerced on load (a hand-edited or
     partially-written save can no longer crash the game or make
     `coins` NaN, which used to poison every later save)
   - `saveSoon()` is a real debounce with a guaranteed flush on
     pagehide/visibilitychange, so coins earned in the last seconds
     of a run survive the user swiping the app away
   - localStorage failures (private mode, quota) degrade to an
     in-memory save instead of throwing every frame
   ============================================================ */
const Storage = {
	KEY: 'tootjump2_save_v1',
	SCHEMA: 4,
	data: null,
	_dirty: false,
	_writable: true,

	defaults() {
		return {
			schema: this.SCHEMA,
			best: 0,
			bestTier: -1,          // -1 = "none yet" (0 is a real tier: GAS)
			coins: 0,
			runs: 0,
			unlocked: ['gary'],
			selected: 'gary',
			missions: [],
			/* daily missions: 3 fresh goals every calendar day + a streak flame */
			daily: { date: '', missions: [], streak: 0, lastDone: '' },
			/* local weekly leaderboard — top 5 runs of the last 7 days */
			board: [],
			/* unlocked achievement ids */
			achievements: [],
			settings: { sfx: true, music: false, haptics: true, sfxVol: 0.9, musicVol: 0.35 },
			stats: { stomps: 0, springs: 0, coins: 0, maxCombo: 0, deaths: 0, revives: 0, powerups: 0, closeCalls: 0, hits: 0, golden: 0, beansUsed: 0 },
			/* ---- v4: hat shop + cosmetics ---- */
			hats: { owned: ['none'], equipped: 'none' },
			/* ---- v4: character perk leveling (id -> level 1..3) ---- */
			charLevels: {},
			/* ---- v4: tutorial quest chain ---- */
			tut: { step: 0, done: false },
			/* ---- v4: daily seeded challenge (same level for everyone) ---- */
			dailyRun: { date: '', best: 0, played: false },
			/* ---- v4: trophy shelf — cups earned per 100m milestone.
			    Cups REFRESH DAILY (cupsDate) so players re-earn them + the
			    coin reward every day; cupsBest is today's highest climb. ---- */
			cups: [],
			cupsDate: '',
			cupsBest: 0,
			/* ---- v4: invisible difficulty smoothing (never shown to player) ---- */
			ddas: 0,               // deaths recorded by the DDA at roughly the same altitude
			ddasY: 0,              // altitude band of those deaths
			ddEase: 0,             // 0..1, how much the level is quietly helping
			/* ---- v4: mystery gift state ---- */
			gift: { nextM: 500 },
			/* ---- v4.1: crate vault — crates BANK until the player opens them ---- */
			crates: { normal: 0, golden: 0 },
			/* ---- v4: local notifications ---- */
			notif: { ask: true, hour: 19, streakReminder: true },
			/* ---- v4: meme quiz seen ---- */
			quizDone: false,
		};
	},

	/* -------------------------------------------------- validation */
	_int(v, min, max, fallback) {
		const n = Math.floor(Number(v));
		if (!Number.isFinite(n)) return fallback;
		return Math.max(min, Math.min(max, n));
	},

	_bool(v, fallback) {
		return typeof v === 'boolean' ? v : fallback;
	},

	_sanitize(raw) {
		const d = this.defaults();
		if (!raw || typeof raw !== 'object') return d;

		const MAX = 1e12;
		d.best = this._int(raw.best, 0, MAX, 0);
		d.bestTier = this._int(raw.bestTier, -1, 4, -1);
		d.coins = this._int(raw.coins, 0, MAX, 0);
		d.runs = this._int(raw.runs, 0, MAX, 0);

		// unlocked: only ids that actually exist in the roster
		const validIds = (typeof CHARACTERS !== 'undefined')
			? new Set(CHARACTERS.map(c => c.id))
			: null;
		if (Array.isArray(raw.unlocked)) {
			const seen = new Set();
			d.unlocked = raw.unlocked.filter(id =>
				typeof id === 'string' && !seen.has(id) && seen.add(id) &&
				(!validIds || validIds.has(id))
			);
		}
		if (!d.unlocked.includes('gary')) d.unlocked.unshift('gary');

		d.selected = (typeof raw.selected === 'string' && d.unlocked.includes(raw.selected))
			? raw.selected : 'gary';

		if (raw.settings && typeof raw.settings === 'object') {
			d.settings.sfx = this._bool(raw.settings.sfx, d.settings.sfx);
			d.settings.music = this._bool(raw.settings.music, d.settings.music);
			d.settings.haptics = this._bool(raw.settings.haptics, d.settings.haptics);
			d.settings.sfxVol = Math.max(0, Math.min(1, Number(raw.settings.sfxVol) || 0)) || d.settings.sfxVol;
			d.settings.musicVol = Math.max(0, Math.min(1, Number(raw.settings.musicVol) || 0)) || d.settings.musicVol;
		}

		if (raw.stats && typeof raw.stats === 'object') {
			for (const k of Object.keys(d.stats)) {
				d.stats[k] = this._int(raw.stats[k], 0, MAX, d.stats[k]);
			}
		}

		// missions: drop anything malformed rather than rendering NaN bars
		if (Array.isArray(raw.missions)) {
			d.missions = raw.missions.filter(m =>
				m && typeof m === 'object' &&
				typeof m.type === 'string' &&
				typeof m.label === 'string' &&
				Number.isFinite(Number(m.target)) && Number(m.target) > 0
			).slice(0, 3).map(m => ({
				type: m.type,
				target: this._int(m.target, 1, 1e9, 1),
				reward: this._int(m.reward, 0, 1e6, 40),
				prog: this._int(m.prog, 0, 1e9, 0),
				label: String(m.label).slice(0, 120),
			}));
		}

		// daily missions
		if (raw.daily && typeof raw.daily === 'object') {
			d.daily.streak = this._int(raw.daily.streak, 0, 9999, 0);
			d.daily.date = typeof raw.daily.date === 'string' ? raw.daily.date.slice(0, 10) : '';
			d.daily.lastDone = typeof raw.daily.lastDone === 'string' ? raw.daily.lastDone.slice(0, 10) : '';
			if (Array.isArray(raw.daily.missions)) {
				d.daily.missions = raw.daily.missions.filter(m =>
					m && typeof m === 'object' && typeof m.type === 'string' &&
					typeof m.label === 'string' && Number(m.target) > 0
				).slice(0, 3).map(m => ({
					type: m.type,
					target: this._int(m.target, 1, 1e9, 1),
					reward: this._int(m.reward, 0, 1e6, 60),
					prog: this._int(m.prog, 0, 1e9, 0),
					label: String(m.label).slice(0, 120),
				}));
			}
		}

		// weekly leaderboard: keep only sane entries
		if (Array.isArray(raw.board)) {
			d.board = raw.board
				.filter(e => e && typeof e === 'object')
				.map(e => ({
					score: this._int(e.score, 0, MAX, 0),
					char: typeof e.char === 'string' ? e.char.slice(0, 24) : 'gary',
					ts: this._int(e.ts, 0, Date.now() + 86400000, 0),
				}))
				.slice(0, 5);
		}

		if (Array.isArray(raw.achievements)) {
			const seen = new Set();
			d.achievements = raw.achievements.filter(id =>
				typeof id === 'string' && !seen.has(id) && seen.add(id)).slice(0, 100);
		}

		/* ---- v4 validation ---- */

		// hats: only ids HATS knows about (guarded — hats.js may load after us)
		const validHats = (typeof HATS !== 'undefined') ? new Set(HATS.map(h => h.id)) : null;
		if (raw.hats && typeof raw.hats === 'object') {
			const seen = new Set();
			d.hats.owned = Array.isArray(raw.hats.owned)
				? raw.hats.owned.filter(id =>
					typeof id === 'string' && !seen.has(id) && seen.add(id) &&
					(!validHats || validHats.has(id)))
				: d.hats.owned;
			if (!d.hats.owned.includes('none')) d.hats.owned.unshift('none');
			d.hats.equipped = (typeof raw.hats.equipped === 'string' &&
				(!validHats || validHats.has(raw.hats.equipped)) &&
				d.hats.owned.includes(raw.hats.equipped))
				? raw.hats.equipped : 'none';
		}

		// charLevels: id -> level 1..3 only for known characters
		if (raw.charLevels && typeof raw.charLevels === 'object') {
			const validChars = (typeof CHARACTERS !== 'undefined') ? new Set(CHARACTERS.map(c => c.id)) : null;
			for (const id of Object.keys(raw.charLevels)) {
				if (validChars && !validChars.has(id)) continue;
				const lv = this._int(raw.charLevels[id], 1, 3, 1);
				if (lv > 1) d.charLevels[id] = lv;
			}
		}

		// tutorial progress
		if (raw.tut && typeof raw.tut === 'object') {
			d.tut.step = this._int(raw.tut.step, 0, 99, 0);
			d.tut.done = this._bool(raw.tut.done, false);
		}

		// daily challenge
		if (raw.dailyRun && typeof raw.dailyRun === 'object') {
			d.dailyRun.date = typeof raw.dailyRun.date === 'string' ? raw.dailyRun.date.slice(0, 10) : '';
			d.dailyRun.best = this._int(raw.dailyRun.best, 0, MAX, 0);
			d.dailyRun.played = this._bool(raw.dailyRun.played, false);
		}

		// cups: distinct milestone scores, ascending
		if (Array.isArray(raw.cups)) {
			const seen = new Set();
			d.cups = raw.cups
				.map(c => this._int(c && c.m !== undefined ? c.m : c, 0, 1e9, -1))
				.filter(m => m >= 0 && !seen.has(m) && seen.add(m))
				.sort((a, b) => a - b)
				.slice(0, 200);
		}
		if (raw.cupsDate !== undefined) d.cupsDate = typeof raw.cupsDate === 'string' ? raw.cupsDate.slice(0, 10) : '';
		if (raw.cupsBest !== undefined) d.cupsBest = this._int(raw.cupsBest, 0, MAX, 0);

		// DDA state (invisible; harmless if lost)
		if (raw.ddas !== undefined) d.ddas = this._int(raw.ddas, 0, 99, 0);
		if (raw.ddasY !== undefined) d.ddasY = this._int(raw.ddasY, -1e9, 0, 0);
		if (raw.ddEase !== undefined) d.ddEase = Math.max(0, Math.min(1, Number(raw.ddEase) || 0));

		// mystery gift
		if (raw.gift && typeof raw.gift === 'object') {
			d.gift.nextM = this._int(raw.gift.nextM, 500, 1e9, 500);
		}

		// crate vault: banked loot, never negative, sane cap
		if (raw.crates && typeof raw.crates === 'object') {
			d.crates = {
				normal: this._int(raw.crates.normal, 0, 99, 0),
				golden: this._int(raw.crates.golden, 0, 99, 0),
			};
		}

		// notifications
		if (raw.notif && typeof raw.notif === 'object') {
			d.notif.ask = this._bool(raw.notif.ask, true);
			d.notif.hour = this._int(raw.notif.hour, 0, 23, 19);
			d.notif.streakReminder = this._bool(raw.notif.streakReminder, true);
		}

		d.quizDone = this._bool(raw.quizDone, false);

		return d;
	},

	/* -------------------------------------------------- load / save */
	load() {
		let raw = null;
		try {
			const txt = localStorage.getItem(this.KEY);
			if (txt) raw = JSON.parse(txt);
		} catch (e) {
			// corrupt JSON or storage disabled — fall back to defaults
			raw = null;
		}

		this.data = this._sanitize(raw);
		this._migrate(raw);
		this.data.schema = this.SCHEMA;
		return this.data;
	},

	/* one-time schema upgrades */
	_migrate(raw) {
		const prev = raw && Number.isFinite(Number(raw.schema)) ? Number(raw.schema) : 1;
		if (prev >= this.SCHEMA) return;
		// v1 -> v2: bestTier 0 used to mean "none"; only treat it as a real
		// GAS tier if the player has actually completed a run.
		if (prev < 2 && raw && raw.bestTier === 0 && !(raw.runs > 0)) {
			this.data.bestTier = -1;
		}
		// v3 -> v4: nothing to move — new fields default through _sanitize.
		// The schema bump itself just forces one save.
		this.save();
	},

	save() {
		this._dirty = false;
		if (!this._writable) return;
		try {
			localStorage.setItem(this.KEY, JSON.stringify(this.data));
		} catch (e) {
			// quota exceeded / private mode — stop retrying every frame
			this._writable = false;
		}
	},

	/* debounced — coin pickups happen many times a second and writing
	   localStorage every frame causes visible jank on phones */
	saveSoon() {
		this._dirty = true;
	},

	flush() {
		if (this._dirty) this.save();
	},

	/* guarantee a write when the app goes away */
	installLifecycleHooks() {
		const flush = () => this.flush();
		window.addEventListener('pagehide', flush);
		window.addEventListener('beforeunload', flush);
		document.addEventListener('visibilitychange', () => {
			if (document.hidden) flush();
		});
	},

	reset() {
		this.data = this.defaults();
		this.save();
	},
};

if (typeof module !== 'undefined' && module.exports) module.exports = { Storage };
