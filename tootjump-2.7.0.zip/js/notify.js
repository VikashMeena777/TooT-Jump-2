'use strict';
/* ============================================================
   Notify — daily local notifications.

   Two reminders, both driven by saved state so nothing fires
   spuriously:
   - STREAK: "your N-day streak dies tonight" — scheduled while a
     streak is alive and the day's dailies are still undone.
   - NUDGE: a plain "missions waiting" ping for players without a
     streak yet.

   Inside the APK this uses @capacitor/local-notifications. On the
   web it degrades to nothing (Notification API is unreliable on
   Android Chrome and the game is primarily distributed as an APK).
   ============================================================ */
const Notify = {
	_plugin() {
		return (window.Capacitor && window.Capacitor.Plugins &&
			window.Capacitor.Plugins.LocalNotifications) || null;
	},

	available() { return !!this._plugin(); },

	async request() {
		const p = this._plugin();
		if (!p) return false;
		try {
			const res = await p.requestPermissions();
			return res && res.display === 'granted';
		} catch (e) { return false; }
	},

	/* schedule today at Storage.data.notif.hour. Called ONLY from the menu
	   flow, and only after permission is already granted — never from
	   game over. Two reasons:
	   1. scheduling without POST_NOTIFICATIONS makes Android surface its
	      own permission prompt at the worst possible moment (right after
	      you die),
	   2. with allowWhileIdle the Capacitor plugin uses EXACT alarms, which
	      on Android 12+ auto-launches the "Alarms & reminders" special
	      access screen. A streak reminder does not need to be
	      second-perfect, so we schedule an inexact alarm instead. */
	async refresh() {
		const p = this._plugin();
		if (!p) return;
		const d = Storage.data;
		if (!d.notif.streakReminder) { await this.cancel(); return; }

		// hard gate: schedule() must never be the thing that prompts
		try {
			const perms = await p.checkPermissions();
			if (!perms || perms.display !== 'granted') return;
		} catch (e) { return; }

		const hour = d.notif.hour;
		const streak = d.daily.streak || 0;
		const dailiesLeft = d.daily.missions.some(m => m.prog < m.target);
		let title, body;
		if (streak >= 1 && dailiesLeft && d.daily.lastDone !== Missions._today()) {
			title = `🔥 ${streak}-day streak dies tonight!`;
			body = '3 daily missions are waiting. Save the streak 💰';
		} else if (streak >= 1) {
			// dailies already done today — remind about tomorrow instead
			title = '💨 New day, new dailies!';
			body = `Your ${streak}-day streak is safe. Keep it going tomorrow!`;
		} else {
			title = '💨 Toot Jump 2';
			body = 'Your daily missions + a fresh challenge are waiting 🪙';
		}

		const now = new Date();
		const at = new Date(now.getFullYear(), now.getMonth(), now.getDate(), hour, 0, 0);
		if (at.getTime() <= now.getTime()) at.setDate(at.getDate() + 1);

		try {
			await p.schedule({
				notifications: [{
					id: CFG.NOTIF_ID_STREAK,
					title,
					body,
					// inexact on purpose (see note above): exact alarms would
					// make Android auto-open its "Alarms & reminders" screen
					schedule: { at, allowWhileIdle: false },
				}],
			});
		} catch (e) { /* scheduling is best-effort */ }
	},

	async cancel() {
		const p = this._plugin();
		if (!p) return;
		try { await p.cancel({ notifications: [{ id: CFG.NOTIF_ID_STREAK }] }); } catch (e) {}
	},
};

if (typeof module !== 'undefined' && module.exports) module.exports = { Notify };
