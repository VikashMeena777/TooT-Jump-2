'use strict';
/* ============================================================
   Quests — the first-session tutorial chain.

   One quest at a time, guaranteed coins, taught with a hint line
   on the HUD. Events reuse the Missions.notify plumbing: the
   quest list watches the same 'coin' / 'stomp' / 'spring' / 'tier'
   / 'reach' events, plus 'bounce' which World reports on landing.
   The chain ends with the shop unlock — the tutorial literally
   hands the player their first coin sink.
   ============================================================ */
const Quests = {
	_done: {},          // per-run event accumulation: type -> count this run
	_tierHit: false,

	/* the quest index the save points at (or -1 when finished) */
	idx() {
		const t = Storage.data.tut;
		if (t.done) return -1;
		return Math.min(t.step, CFG.TUTORIAL.length - 1);
	},

	current() {
		const i = this.idx();
		return i >= 0 ? CFG.TUTORIAL[i] : null;
	},

	/* how far along the CURRENT quest the player is this run */
	prog() {
		const q = this.current();
		if (!q) return 0;
		if (q.type === 'tier') return this._tierHit ? 1 : 0;
		if (q.type === 'reach') return Math.min(q.n, this._reach || 0);
		return Math.min(q.n, this._done[q.type] || 0);
	},

	/* new run started — per-run counters reset, but the chain persists */
	resetRun() {
		this._done = {};
		this._tierHit = false;
		this._reach = 0;
	},

	/* same event vocabulary as Missions.notify */
	notify(type, value) {
		const q = this.current();
		if (!q) return;
		if (type === 'reach') {
			this._reach = Math.max(this._reach || 0, Number(value) || 0);
		} else if (type === 'tier') {
			// tutorial combo tier is the 2nd tier index (3x combo = GAS+1)
			if ((Number(value) | 0) >= 1) this._tierHit = true;
		} else if (type === 'bounce') {
			this._done[type] = (this._done[type] || 0) + (Number(value) || 0);
		} else {
			this._done[type] = (this._done[type] || 0) + (Number(value) || 0);
		}
		this._check();
	},

	_check() {
		const q = this.current();
		if (!q) return;
		if (this.prog() < q.n) return;
		// complete: pay, advance, celebrate
		Storage.data.coins += q.reward;
		Storage.data.stats.coins += q.reward;
		if (typeof World !== 'undefined' && World._logReward) {
			World._logReward('🎓', 'training: ' + q.label.toLowerCase());
		}
		const t = Storage.data.tut;
		t.step++;
		if (t.step >= CFG.TUTORIAL.length) {
			t.done = true;
			// capstone: finishing the whole chain banks a GOLDEN crate
			const vault = Storage.data.crates;
			vault.golden = Math.min(99, (vault.golden || 0) + 1);
			Storage.save();
			UI.toast('🎓 TRAINING COMPLETE! GOLDEN CRATE IN THE VAULT! 🌟');
			SFX.play('powerup', 0.1, 1.1);
			FX.confetti(CFG.VIEW_W / 2, World.camY - 200);
		} else {
			Storage.save();
			UI.toast(`✓ ${q.label}  +${q.reward}`, 'coin');
			SFX.play('coin', 0.08, 1.3);
		}
	},
};

if (typeof module !== 'undefined' && module.exports) module.exports = { Quests };
