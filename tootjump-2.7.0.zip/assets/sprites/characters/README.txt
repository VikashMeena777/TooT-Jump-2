TOOT JUMP 2 - YOUR MEME CHARACTER ART GOES HERE
===============================================

Drop a transparent PNG (or WebP), ~256x256 or bigger, named exactly:

  gary.png        skibidi.png     sigma.png       rizz.png
  ohio.png        gyatt.png       bombardino.png  tralalero.png

AFTER ADDING OR REMOVING FILES, RUN:

  npm run assets

That rewrites manifest.json, which is the list the game actually loads.
The game does not probe for files: the old build requested all eight PNGs
on every boot and logged eight 404s for the default install. If you skip
this step your art simply will not be picked up.

Once it is in the manifest the PNG replaces that character's cartoon
drawing everywhere - the menu mascot, the squad picker, and in-game - and
the card gets a "MEME!" tag.

WANT MORE OR DIFFERENT CHARACTERS?
  Open js/characters.js. Every character is one small entry:

    { id: 'yourmeme', name: 'Your Meme', shape: 'blob',
      price: 500, colors: { body: '#...', belly: '#...', accent: '#...' },
      perk: 'what it does', perkCode: null, trail: '#ffffff' }

  Add an entry, drop yourmeme.png here, run npm run assets. Done.
  `perkCode` must be one of the codes handled in js/world.js
  (halfRevive, longCombo, richRat, startBubble, springy, stompy,
  longMagnet) or null for no perk.

TIPS
  - transparent background, character facing forward
  - roughly square, centred art looks best; it is scaled to ~84px tall
  - keep it under ~300KB so the game loads instantly
  - a file that fails to decode is ignored, and the procedural cartoon is
    used instead, so a bad PNG cannot break the game
