TOOT JUMP 2 - YOUR MEME SOUNDS GO HERE
======================================

Drop your sound files in THIS folder, named after a slot.
Extensions: .mp3, .ogg, .wav or .m4a

  jump      -> every bounce (your fart meme)
  hurt      -> spikes and enemies (the scream)
  spring    -> mega-boost spring platforms
  break     -> crumbly platform breaking
  boing     -> stomping a grump
  coin      -> picking up coins
  powerup   -> rocket / bubble / magnet / beans
  gameover  -> game over jingle
  button    -> menu clicks
  combo     -> combo tier up (pitch rises with the tier)
  whoosh    -> rocket loop (should loop cleanly, ~1-2s)

MULTIPLE VARIANTS = EXTRA FUNNY
  hurt.mp3, hurt_1.mp3, hurt_2.mp3, ...
  A random one is picked each play, with slight pitch randomisation, so
  the same meme never gets boring. There is no hard limit on variants.

AFTER ADDING OR REMOVING FILES, RUN:

  npm run assets

That rewrites manifest.json, which is the list the game actually loads.
The game does not probe for files: the old build requested 198 URLs on
every boot and logged a wall of 404s. If you skip this step your new
sound simply will not be picked up.

NOTES
  - if a slot has no file, a built-in synthesized cartoon sound plays
    instead, so the game is fully playable with this folder empty
  - your files ALWAYS override the built-ins
  - every clip is loudness-normalised (RMS), so a quiet rip and a
    blown-out rip end up at the same volume
  - long clips are capped per slot (see MAX_DUR in js/audio.js) so a
    meme that is secretly a whole song cannot hold the stage
  - only one "real" sound plays at a time; a bigger event interrupts a
    smaller one, and coin/button blips stay quiet underneath
  - meme-names.json is optional and only used for credits/labels
