'use strict';
/* ============================================================
   UI — DOM screens: menu, character select, how-to, pause, game over, HUD.

   Fixes vs the previous build:
   - `show()` had contradictory HUD logic (it toggled the HUD off for
     'over' on line 1 and then re-hid it on line 2), so the HUD state
     depended on evaluation order rather than intent. Rewritten as a
     single explicit table.
   - the game-over score count-up ran on a 24ms setInterval that was
     never cleared when the player left the screen, so retrying fast
     left timers running and the interval fought the next count-up.
     Now driven by the main loop's rAF clock and cancelled on hide.
   - character thumbnails created a new 260x260 canvas per card on
     every render (8 canvases each time the screen opened, never
     released). Thumbnails are now cached once per character.
   - toasts were uncapped: a mission-completion cascade could stack a
     dozen overlapping toasts. Capped at CFG.MAX_TOASTS.
   - `bestTier` of -1 rendered as `CFG.TIERS[-1]` → "undefined" in the
     stats line for every new player.
   - revive button label/cost is set here (it was patched from main.js
     after showGameOver, causing a visible text flash).
   - buttons are real <button>s with aria labels and keyboard support;
     the character cards are focusable and activate on Enter/Space.
   ============================================================ */

const UI = {
	el: {},
	_mascotCtx: null,
	_reviveT: 0,
	_reviveMax: 0,
	_onRevive: null,
	_onReviveExpire: null,
	_thumbCache: new Map(),
	_countAnim: null,
	_lastScore: -1,
	_lastCoins: -1,
	_lastTier: -1,
	_bannerTO: 0,

	q(id) { return document.getElementById(id); },

	/* a drawn coin element — see the .coin rule in style.css for why this is
	   not the 🪙 emoji */
	_coinEl(small) {
		const s = document.createElement('span');
		s.className = small ? 'coin sm' : 'coin';
		s.setAttribute('aria-hidden', 'true');
		return s;
	},

	/* "<text> <coin> <after>" as a document fragment */
	_coinText(before, after) {
		const frag = document.createDocumentFragment();
		if (before) frag.append(before);
		frag.appendChild(this._coinEl());
		if (after) frag.append(after);
		return frag;
	},

	init() {
		const q = this.q.bind(this);
		this.el = {
			hud: q('hud'), hudScore: q('hud-score'), hudCoins: q('hud-coins'),
			comboPill: q('combo-pill'), comboName: q('combo-name'), comboFill: q('combo-fill'),
			pauseBtn: q('btn-pause'),
			menu: q('screen-menu'), chars: q('screen-chars'), howto: q('screen-howto'),
			badges: q('screen-badges'),
			shop: q('screen-shop'),
			crates: q('screen-crates'),
			pause: q('screen-pause'), over: q('screen-over'),
			zoneBanner: q('zone-banner'), toasts: q('toasts'),
		};

		this._buildMenu();
		this._buildChars();
		this._buildHowto();
		this._buildBadges();
		this._buildShop();
		this._buildCrates();
		this._buildQuiz();
		this._buildPause();
		this._buildGameOver();

		this.el.pauseBtn.addEventListener('click', () => {
			SFX.play('button', 0.06);
			Game.togglePause();
		});
	},

	/* ---------------------------------------------------------- screens */
	SCREENS: ['menu', 'chars', 'howto', 'badges', 'shop', 'crates', 'pause', 'over'],

	/* which screens keep the in-game HUD visible behind them */
	HUD_VISIBLE: { hud: true, pause: true, over: false },

	show(name) {
		for (const k of this.SCREENS) {
			this.el[k].classList.add('hidden');
			this.el[k].setAttribute('aria-hidden', 'true');
		}
		const showHud = !!this.HUD_VISIBLE[name];
		this.el.hud.classList.toggle('hidden', !showHud);

		if (name !== 'over') this._stopCountUp();
		if (name === 'menu') this._trimStaleToasts();

		if (this.el[name] && name !== 'hud') {
			const scr = this.el[name];
			scr.classList.remove('hidden');
			scr.setAttribute('aria-hidden', 'false');
			// every screen is a scroll container; always open at the top
			scr.scrollTop = 0;
			// move focus to the primary action for keyboard/screen-reader users
			const focusTarget = scr.querySelector('[data-autofocus]') || scr.querySelector('button');
			if (focusTarget) {
				try { focusTarget.focus({ preventScroll: true }); } catch (e) { /* ignore */ }
			}
		}
		this._current = name;
	},

	/* ---------------------------------------------------------- menu */
	_buildMenu() {
		const m = this.el.menu;
		m.innerHTML = `
			<div class="title" role="heading" aria-level="1">
				<span class="l1">TOOT</span>
				<span class="l2">JUMP 2</span>
			</div>
			<div class="subtitle">now with 200% more gas 💨</div>
			<canvas id="mascot" width="240" height="150" style="width:240px;height:150px" aria-hidden="true"></canvas>
			<div class="update-banner hidden" id="update-banner" role="button" tabindex="0">
				🚀 NEW VERSION AVAILABLE — TAP TO UPDATE
			</div>
			<button class="btn pulse" id="btn-play" data-autofocus>PLAY</button>
			<div class="btn-row">
				<button class="btn ghost small" id="btn-chars">CHARACTERS</button>
				<button class="btn ghost small" id="btn-howto">HOW TO TOOT</button>
			</div>
			<div class="btn-row">
				<button class="btn ghost small" id="btn-badges">🏆 BADGES <span id="badge-count" class="badge-count"></span></button>
				<button class="btn ghost small" id="btn-shop">🎩 HAT SHOP</button>
			</div>
			<button class="btn yellow small" id="btn-crates">🎁 CRATES <span id="crate-count" class="badge-count"></span></button>
			<div class="pill-row">
				<div class="pill yellow" id="menu-best">BEST 0 m</div>
				<div class="pill" id="menu-coins"><span class="coin" aria-hidden="true"></span><span id="menu-coin-n">0</span></div>
			</div>
			<div class="cup-shelf" id="menu-cups" aria-label="trophy shelf"></div>
			<div class="hint" id="cups-hint">trophies REFRESH DAILY — climb again tomorrow to re-earn them + coins 🏆</div>
			<button class="daily-challenge" id="btn-daily" type="button">
				<div class="dc-left">
					<div class="dc-title">☀️ DAILY CHALLENGE</div>
					<div class="dc-sub" id="daily-sub">Same level for EVERYONE — how high can you go?</div>
				</div>
				<div class="dc-right" id="daily-right">PLAY</div>
			</button>
			<div class="card missions-card" id="tut-card">
				<div class="card-title">🎓 TRAINING</div>
				<div id="menu-tut" class="mission-list"></div>
			</div>
			<div class="card missions-card">
				<div class="card-title">🎯 MISSIONS</div>
				<div id="menu-missions" class="mission-list"></div>
			</div>
			<div class="card missions-card">
				<div class="card-title" id="daily-title">🔥 DAILY</div>
				<div id="menu-daily" class="mission-list"></div>
			</div>
			<div class="card missions-card">
				<div class="card-title">🏆 THIS WEEK</div>
				<div id="menu-board" class="board-list"></div>
			</div>
			<div class="card settings-card">
				<div class="card-title">⚙️ SETTINGS</div>
				<label class="slider-row">🔊 SFX
					<input type="range" id="vol-sfx" min="0" max="100" step="5" aria-label="sound effects volume">
				</label>
				<label class="slider-row">🎵 MUSIC
					<input type="range" id="vol-music" min="0" max="100" step="5" aria-label="music volume">
				</label>
				<div class="btn-row">
					<button class="chip" id="chip-sfx" aria-pressed="false">🔊 SFX</button>
					<button class="chip" id="chip-music" aria-pressed="false">🎵 MUSIC</button>
					<button class="chip" id="chip-haptics" aria-pressed="false">📳 BUZZ</button>
				</div>
				<button class="chip danger" id="btn-reset">reset progress</button>
			</div>
			<div class="menu-stat" id="menu-stats"></div>
		`;

		m.querySelector('#btn-play').addEventListener('click', () => {
			SFX.init();
			SFX.play('jump', 0.15);
			Game.startRun();
		});
		m.querySelector('#btn-chars').addEventListener('click', () => {
			SFX.play('button', 0.06);
			this.show('chars');
			this._renderChars();
		});
		m.querySelector('#btn-howto').addEventListener('click', () => {
			SFX.play('button', 0.06);
			this.show('howto');
		});
		m.querySelector('#btn-badges').addEventListener('click', () => {
			SFX.play('button', 0.06);
			this.show('badges');
			this._renderBadges();
		});
		m.querySelector('#btn-shop').addEventListener('click', () => {
			SFX.play('button', 0.06);
			this.show('shop');
			this._renderShop();
		});
		m.querySelector('#btn-crates').addEventListener('click', () => {
			SFX.play('button', 0.06);
			this.show('crates');
			this._renderCrates();
		});
		m.querySelector('#btn-daily').addEventListener('click', () => {
			SFX.play('jump', 0.15);
			Game.startDaily();
		});

		// out-of-store update banner (see js/updater.js)
		const ub = m.querySelector('#update-banner');
		ub.addEventListener('click', () => {
			SFX.play('button', 0.06);
			if (typeof Updater !== 'undefined' && this._updateApkUrl) Updater.openApk(this._updateApkUrl);
		});

		m.querySelector('#chip-sfx').addEventListener('click', () => this._toggleSetting('sfx'));
		m.querySelector('#chip-music').addEventListener('click', () => this._toggleSetting('music'));
		m.querySelector('#chip-haptics').addEventListener('click', () => this._toggleSetting('haptics'));

		// volume sliders — immediate, saved, and applied to the live buses
		const volSfx = m.querySelector('#vol-sfx');
		const volMusic = m.querySelector('#vol-music');
		volSfx.addEventListener('input', () => this._setVolume('sfxVol', volSfx.value / 100));
		volMusic.addEventListener('input', () => this._setVolume('musicVol', volMusic.value / 100));

		// reset progress — two-tap confirm instead of a native dialog
		const resetBtn = m.querySelector('#btn-reset');
		resetBtn.addEventListener('click', () => {
			if (resetBtn.classList.contains('armed')) {
				Storage.reset();
				SFX.stopAll();
				SFX.init();
				this.refreshMenu();
				this.toast('all progress wiped — best, coins, hats AND trophies 🧼');
				resetBtn.classList.remove('armed');
				resetBtn.textContent = 'reset progress';
			} else {
				resetBtn.classList.add('armed');
				resetBtn.textContent = 'SURE? TAP AGAIN';
				SFX.play('break', 0.1, 0.7);
				clearTimeout(this._resetTO);
				this._resetTO = setTimeout(() => {
					resetBtn.classList.remove('armed');
					resetBtn.textContent = 'reset progress';
				}, 3000);
			}
		});

		this._mascotCtx = m.querySelector('#mascot').getContext('2d');
		this.refreshMenu();
	},

	_setVolume(key, v) {
		Storage.data.settings[key] = v;
		Storage.saveSoon();
		SFX.applyVolumes();
	},

	_toggleSetting(key) {
		const s = Storage.data.settings;
		s[key] = !s[key];
		Storage.save();
		if (key === 'music') {
			if (s.music) { SFX.init(); SFX.startMusic(); }
			else SFX.stopMusic();
		}
		if (key === 'sfx' && !s.sfx) SFX.stopAll();
		SFX.play('button', 0.06);
		this.refreshMenu();
		this.refreshPause();
	},

	refreshMenu() {
		const d = Storage.data;
		if (typeof World !== 'undefined' && World.rollDailyCups) World.rollDailyCups();
		const m = this.el.menu;
		m.querySelector('#menu-best').textContent = `BEST ${d.best} m`;
		m.querySelector('#menu-coin-n').textContent = String(d.coins);

		// trophy shelf
		this._renderCups(m.querySelector('#menu-cups'));

		// daily challenge card
		const playedToday = d.dailyRun.date === this._todayKey() && d.dailyRun.played;
		const dcRight = m.querySelector('#daily-right');
		if (playedToday) {
			dcRight.textContent = '✓ ' + d.dailyRun.best + ' m';
			dcRight.classList.add('done');
		} else {
			dcRight.textContent = 'PLAY';
			dcRight.classList.remove('done');
		}

		// tutorial card — hide once done
		const tutCard = m.querySelector('#tut-card');
		const q = (typeof Quests !== 'undefined') ? Quests.current() : null;
		if (q && !d.tut.done) {
			tutCard.classList.remove('hidden');
			this._renderQuestCard(m.querySelector('#menu-tut'), q);
		} else {
			tutCard.classList.add('hidden');
		}

		// bestTier === -1 means "no combo yet" — the old build printed
		// CFG.TIERS[-1] → "undefined" for every fresh save
		const tierTxt = (d.bestTier >= 0 && d.bestTier < CFG.TIERS.length)
			? ` • ${CFG.TIERS[d.bestTier]}` : '';
		m.querySelector('#menu-stats').textContent =
			`${d.runs} runs • ${d.stats.stomps} stomps • best combo ${d.stats.maxCombo}x${tierTxt}`;

		for (const k of ['sfx', 'music', 'haptics']) {
			const chip = m.querySelector('#chip-' + k);
			const on = !!d.settings[k];
			chip.classList.toggle('on', on);
			chip.setAttribute('aria-pressed', on ? 'true' : 'false');
		}
		m.querySelector('#vol-sfx').value = Math.round(d.settings.sfxVol * 100);
		m.querySelector('#vol-music').value = Math.round(d.settings.musicVol * 100);

		// badge counter on the menu button
		const bc = m.querySelector('#badge-count');
		if (bc) bc.textContent = `${d.achievements.length}/${Achievements.DEFS.length}`;

		// crate vault counter on the menu button
		const cc = m.querySelector('#crate-count');
		if (cc) {
			const n = (d.crates.normal || 0) + (d.crates.golden || 0);
			cc.textContent = String(n);
			cc.classList.toggle('glow', n > 0);
		}

		// daily missions — roll the day over if it changed while open
		Missions.ensureDaily();
		m.querySelector('#daily-title').textContent =
			`🔥 DAILY${d.daily.streak > 0 ? ` — ${d.daily.streak} day streak!` : ''}`;
		this._renderMissionList(m.querySelector('#menu-daily'), d.daily.missions);

		// weekly leaderboard
		Missions.ensure();
		this._renderMissionList(m.querySelector('#menu-missions'), d.missions);
		this._renderBoard(m.querySelector('#menu-board'));
	},

	_todayKey() {
		const d = new Date();
		return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
	},

	/* trophy shelf: cups refresh DAILY — each 100m tier re-earned today pays
	   CUP_REWARD coins again. Slots are tappable so the shelf explains itself. */
	_renderCups(wrap) {
		wrap.textContent = '';
		const d = Storage.data;
		const earned = d.cups || [];
		const next = (earned.length + 1) * CFG.CUP_STEP;
		for (let i = 0; i < Math.max(3, Math.min(6, earned.length + 1)); i++) {
			const slot = document.createElement('div');
			slot.className = 'cup-slot';
			slot.setAttribute('role', 'button');
			slot.style.cursor = 'pointer';
			if (i < earned.length) {
				const m = earned[i];
				const tier = m >= 1000 ? 'plat' : m >= 500 ? 'gold' : m >= 300 ? 'silver' : 'bronze';
				slot.classList.add('earned', tier);
				slot.textContent = '🏆';
				slot.title = m + ' m — +' + CFG.CUP_REWARD + ' coins';
				slot.addEventListener('click', () => {
					this.toast(`🏆 ${m} m cup — paid ${CFG.CUP_REWARD} coins`);
					SFX.play('button', 0.08);
				});
			} else if (i === earned.length) {
				slot.classList.add('next');
				slot.textContent = next + 'm';
				slot.title = 'reach ' + next + ' m to earn this cup';
				slot.addEventListener('click', () => {
					this.toast(`reach ${next} m in a run to earn this cup 🏆`);
					SFX.play('button', 0.08);
				});
			} else {
				slot.textContent = '·';
			}
			wrap.appendChild(slot);
		}
	},

	/* the single training quest shown on the menu + its hint */
	_renderQuestCard(wrap, q) {
		wrap.textContent = '';
		const frac = Math.min(1, (typeof Quests !== 'undefined' ? Quests.prog() : 0) / q.n);
		const div = document.createElement('div');
		div.className = 'mission';
		const row = document.createElement('div');
		row.className = 'row';
		const label = document.createElement('span');
		label.textContent = q.label;
		const reward = document.createElement('span');
		reward.className = 'reward';
		reward.append('+' + q.reward + ' ');
		reward.appendChild(this._coinEl());
		row.appendChild(label);
		row.appendChild(reward);
		const bar = document.createElement('div');
		bar.className = 'bar';
		const fill = document.createElement('div');
		fill.style.width = (frac * 100).toFixed(1) + '%';
		bar.appendChild(fill);
		const hint = document.createElement('div');
		hint.className = 'hint';
		hint.textContent = '💡 ' + q.hint;
		div.appendChild(row);
		div.appendChild(bar);
		div.appendChild(hint);
		wrap.appendChild(div);
	},

	_renderMissionList(wrap, list) {
		wrap.textContent = '';
		for (const mi of list) {
			const frac = Math.max(0, Math.min(1, mi.prog / mi.target));
			const done = mi.prog >= mi.target;
			const div = document.createElement('div');
			div.className = 'mission' + (done ? ' done' : '');
			const row = document.createElement('div');
			row.className = 'row';
			const label = document.createElement('span');
			label.textContent = (done ? '✓ ' : '') + mi.label;
			const reward = document.createElement('span');
			reward.className = 'reward';
			reward.append('+' + mi.reward + ' ');
			reward.appendChild(this._coinEl());
			row.appendChild(label);
			row.appendChild(reward);

			const bar = document.createElement('div');
			bar.className = 'bar';
			bar.setAttribute('role', 'progressbar');
			bar.setAttribute('aria-valuemin', '0');
			bar.setAttribute('aria-valuemax', String(mi.target));
			bar.setAttribute('aria-valuenow', String(Math.min(mi.prog, mi.target)));
			const fill = document.createElement('div');
			fill.style.width = (frac * 100).toFixed(1) + '%';
			bar.appendChild(fill);

			div.appendChild(row);
			div.appendChild(bar);
			wrap.appendChild(div);
		}
		if (!list.length) {
			const empty = document.createElement('div');
			empty.className = 'hint';
			empty.textContent = 'all done — new ones tomorrow!';
			wrap.appendChild(empty);
		}
	},

	_renderBoard(wrap) {
		wrap.textContent = '';
		const d = Storage.data;
		const entries = (d.board || []).slice(0, 5);
		if (!entries.length) {
			const empty = document.createElement('div');
			empty.className = 'hint';
			empty.textContent = 'no runs yet — set the bar 📈';
			wrap.appendChild(empty);
			return;
		}
		entries.forEach((e, i) => {
			const ch = CharacterArt.byId(e.char);
			const row = document.createElement('div');
			row.className = 'board-row' + (i === 0 ? ' top' : '');
			const rank = document.createElement('span');
			rank.className = 'rank';
			rank.textContent = ['🥇', '🥈', '🥉'][i] || (i + 1) + '.';
			const who = document.createElement('span');
			who.className = 'who';
			who.textContent = ch.name;
			const sc = document.createElement('span');
			sc.className = 'score';
			sc.textContent = e.score + ' m';
			row.append(rank, who, sc);
			wrap.appendChild(row);
		});
	},

	/* ---------------------------------------------------------- chars */
	_buildChars() {
		const c = this.el.chars;
		c.innerHTML = `
			<div class="go-title blue-title">THE SQUAD</div>
			<div class="subtitle">pick your tooter</div>
			<div class="char-grid" id="char-grid" role="list"></div>
			<button class="btn coral small" id="chars-back" data-autofocus>BACK</button>
			<div class="hint">💡 drop a transparent PNG named <b>&lt;id&gt;.png</b> into
			<b>assets/sprites/characters/</b>, run <b>npm run assets</b>, and it replaces
			that cartoon. Add characters in <b>js/characters.js</b></div>
		`;
		c.querySelector('#chars-back').addEventListener('click', () => {
			SFX.play('button', 0.06);
			this.show('menu');
		});
	},

	/* Cached character thumbnail.

	   The old build allocated a fresh 260x260 canvas for all 8 cards every
	   time the screen opened (and never released them), and drew the art at
	   scale 1.6, which left the character floating in a third of the card.
	   One cached bitmap per character now, drawn large enough to actually
	   read on a phone. */
	THUMB_PX: 300,

	_thumb(ch) {
		const key = ch.id + (CharacterArt.get(ch.id) ? ':png' : ':art');
		let cv = this._thumbCache.get(key);
		if (cv) return cv;
		const N = this.THUMB_PX;
		cv = document.createElement('canvas');
		cv.width = cv.height = N;
		const g = cv.getContext('2d');
		/* The art spans roughly -46..+48 vertically (body ry 34-37, horns and
		   feet on top of that) and -46..+46 horizontally. Scale 3 puts that in
		   a ~285px box, and the origin sits slightly above centre so the feet
		   and the antenna both fit. */
		g.translate(N / 2, N / 2 + 8);
		g.scale(3, 3);
		drawCharacter(g, ch, { t: 0.6, vy: -650, blinkSeed: ch.id.length });
		this._thumbCache.set(key, cv);
		return cv;
	},

	_renderChars() {
		const grid = this.el.chars.querySelector('#char-grid');
		grid.textContent = '';
		const d = Storage.data;

		for (const ch of CHARACTERS) {
			const owned = d.unlocked.includes(ch.id);
			const selected = d.selected === ch.id;
			const affordable = d.coins >= ch.price;

			const card = document.createElement('div');
			card.className = 'char-card' +
				(selected ? ' selected' : '') +
				(!owned ? ' locked' : '') +
				(!owned && affordable ? ' affordable' : '');
			card.setAttribute('role', 'listitem');
			card.tabIndex = 0;
			card.setAttribute('aria-label', owned
				? `${ch.name}. ${ch.perk}. ${selected ? 'Selected' : 'Tap to select'}`
				: `${ch.name}. ${ch.perk}. Locked, costs ${ch.price} coins`);

			if (CharacterArt.get(ch.id)) {
				const tag = document.createElement('div');
				tag.className = 'tag';
				tag.textContent = 'MEME!';
				card.appendChild(tag);
			}

			const thumbWrap = document.createElement('div');
			thumbWrap.className = 'thumb';
			const src = this._thumb(ch);
			const shown = document.createElement('canvas');
			shown.width = shown.height = this.THUMB_PX;
			shown.getContext('2d').drawImage(src, 0, 0);
			thumbWrap.appendChild(shown);
			card.appendChild(thumbWrap);

			const name = document.createElement('div');
			name.className = 'name';
			name.textContent = ch.name;
			card.appendChild(name);

			const perk = document.createElement('div');
			perk.className = 'perk';
			perk.textContent = ch.perk;
			card.appendChild(perk);

			const foot = document.createElement('div');
			if (owned) {
				foot.className = 'badge' + (selected ? '' : ' blue');
				foot.textContent = selected ? 'SELECTED ✓' : 'TAP TO SELECT';
			} else {
				foot.className = 'price' + (affordable ? ' can-buy' : '');
				foot.append(this._coinEl(), ' ' + ch.price);
			}
			card.appendChild(foot);

			// character leveling — spend coins to boost the perk (lv 1..3)
			if (owned && ch.perkCode) this._appendLevelRow(card, ch);

			const activate = () => this._charClick(ch);
			card.addEventListener('click', activate);
			card.addEventListener('keydown', (e) => {
				if (e.code === 'Enter' || e.code === 'Space') {
					e.preventDefault();
					activate();
				}
			});
			grid.appendChild(card);
		}
	},

	/* level pips + upgrade button for an owned character */
	_appendLevelRow(card, ch) {
		const d = Storage.data;
		const lv = d.charLevels[ch.id] || 1;
		const row = document.createElement('div');
		row.className = 'level-row';
		for (let i = 1; i <= 3; i++) {
			const pip = document.createElement('span');
			pip.className = 'lvl-pip' + (i <= lv ? ' on' : '');
			row.appendChild(pip);
		}
		if (lv < 3) {
			const cost = CFG.CHAR_LEVEL_COSTS[lv - 1];
			const btn = document.createElement('button');
			btn.className = 'lvl-btn' + (d.coins < cost ? ' cant' : '');
			btn.setAttribute('aria-label', `Upgrade ${ch.name} to level ${lv + 1} for ${cost} coins`);
			btn.append(this._coinEl(), ' ' + cost);
			btn.addEventListener('click', (e) => {
				e.stopPropagation();
				if ((d.charLevels[ch.id] || 1) !== lv) return;
				if (d.coins < cost) {
					SFX.play('break', 0.1, 0.6);
					this.toast(`need ${cost - d.coins} more coins to upgrade`);
					return;
				}
				d.coins -= cost;
				d.charLevels[ch.id] = lv + 1;
				Storage.save();
				SFX.play('powerup', 0.06, 1.2);
				this.toast(`${ch.name} is now LV ${lv + 1} — perk boosted! 📈`);
				this._renderChars();
				this.refreshMenu();
			});
			row.appendChild(btn);
		} else {
			const max = document.createElement('span');
			max.className = 'lvl-btn max';
			max.textContent = 'MAX';
			row.appendChild(max);
		}
		card.appendChild(row);
	},

	_charClick(ch) {
		const d = Storage.data;
		if (d.unlocked.includes(ch.id)) {
			if (d.selected === ch.id) return;
			d.selected = ch.id;
			Storage.save();
			SFX.play('button', 0.06);
			this._renderChars();
			this.refreshMenu();
		} else if (d.coins >= ch.price) {
			d.coins -= ch.price;
			d.unlocked.push(ch.id);
			d.selected = ch.id;
			Storage.save();
			SFX.play('powerup', 0.05);
			this.toast(`UNLOCKED: ${ch.name}! 🎉`);
			this._renderChars();
			this.refreshMenu();
		} else {
			SFX.play('break', 0.1, 0.6);
			this.toast(`need ${ch.price - d.coins} more coins — go climb!`);
		}
	},

	/* ---------------------------------------------------------- crate vault
	   Collected crates live here until the player opens them — a crate never
	   opens on its own. Each tap rolls the reward, pays it, and pops the
	   crate out of the vault. Golden crates shine and pay strictly better. */
	_buildCrates() {
		const c = this.el.crates;
		c.innerHTML = `
			<div class="go-title coral-title">CRATE VAULT</div>
			<div class="subtitle" id="vault-counts"></div>
			<div class="crate-grid" id="crate-grid" role="list"></div>
			<button class="btn small hidden" id="btn-open-all">OPEN ALL</button>
			<button class="btn coral small" id="crates-back" data-autofocus>BACK</button>
			<div class="hint">bank crates by climbing, then tap to open 🎁 — challenges bank even more</div>
		`;
		c.querySelector('#crates-back').addEventListener('click', () => {
			SFX.play('button', 0.06);
			this.refreshMenu();
			this.show('menu');
		});
		c.querySelector('#btn-open-all').addEventListener('click', () => {
			const vault = Storage.data.crates;
			const n = (vault.normal || 0) + (vault.golden || 0);
			if (!n) return;
			SFX.play('powerup', 0.08, 1.1);
			let total = 0;
			// open golden first so their better table applies before normals run out
			while (vault.golden > 0) total += World.vaultOpen(true).coins;
			while (vault.normal > 0) total += World.vaultOpen(false).coins;
			this.toast(`opened ${n} crates — +${total} coins!`, 'coin');
			SFX.play('coin', 0.05, 0.8);
			this._renderCrates();
			this.refreshMenu();
		});
	},

	_renderCrates() {
		const c = this.el.crates;
		const vault = Storage.data.crates;
		const normal = vault.normal || 0, golden = vault.golden || 0;
		c.querySelector('#vault-counts').textContent =
			`${normal} normal · ${golden} golden — tap a crate to open it`;
		const grid = c.querySelector('#crate-grid');
		grid.textContent = '';
		const add = (golden, idx) => {
			const card = document.createElement('button');
			card.type = 'button';
			card.className = 'crate-card' + (golden ? ' golden' : '');
			card.setAttribute('role', 'listitem');
			card.setAttribute('aria-label', golden ? 'open golden crate' : 'open crate');
			card.innerHTML = `<div class="crate-art">${golden ? '🌟' : '🎁'}</div>`;
			card.addEventListener('click', () => this._openVaultCrate(card, golden));
			grid.appendChild(card);
		};
		for (let i = 0; i < normal; i++) add(false, i);
		for (let i = 0; i < golden; i++) add(true, i);
		if (!normal && !golden) {
			const empty = document.createElement('div');
			empty.className = 'vault-empty';
			empty.textContent = 'vault empty — climb past a 🎁 in your next run, or finish challenges, to bank crates';
			grid.appendChild(empty);
		}
		const openAll = c.querySelector('#btn-open-all');
		openAll.classList.toggle('hidden', normal + golden < 2);
		openAll.classList.toggle('yellow', normal + golden >= 2);
	},

	_openVaultCrate(card, golden) {
		const res = World.vaultOpen(golden);
		if (!res) { this._renderCrates(); return; }
		SFX.play('powerup', 0.08, golden ? 1.3 : 1.15);
		// three-beat spectacle: 1) the crate shakes itself apart,
		// 2) POP — confetti flies and the coin appears, 3) the number
		// rolls up so the reward is felt, not just read
		card.classList.add('opening');
		setTimeout(() => {
			card.classList.remove('opening');
			card.classList.add('opened');
			card.disabled = true;
			card.innerHTML = '<div class="crate-art">🪙</div><div class="crate-pay">+0</div>';
			this._burstConfetti(card, golden);
			SFX.play('coin', 0.05, 0.9);
			this.toast(`crate opened — +${res.coins} coins!`, 'coin');
			this.refreshMenu();
			this._countUpPay(card.querySelector('.crate-pay'), res.coins);
			setTimeout(() => this._renderCrates(), 1500);
		}, 480);
	},

	/* confetti burst inside a card: absolutely-positioned particles flung
	   outward via per-particle CSS custom properties (--tx/--ty/--rot) */
	_burstConfetti(card, golden) {
		const colors = golden
			? ['#ffd166', '#fff9ee', '#f4b942', '#c4a6ec', '#ffd166']
			: ['#ff6f61', '#ffd166', '#59cd90', '#5aa9e6', '#fff9ee'];
		for (let i = 0; i < 16; i++) {
			const p = document.createElement('span');
			p.className = 'confetti-particle';
			const angle = (Math.PI * 2 * i) / 16 + Math.random() * 0.5;
			const dist = 60 + Math.random() * 70;
			p.style.setProperty('--tx', `${Math.cos(angle) * dist}px`);
			p.style.setProperty('--ty', `${Math.sin(angle) * dist - 20}px`);
			p.style.setProperty('--rot', `${(Math.random() * 720 - 360).toFixed(0)}deg`);
			p.style.background = colors[i % colors.length];
			card.appendChild(p);
			setTimeout(() => p.remove(), 950);
		}
	},

	/* roll the reward number up over ~0.7s (ease-out) so the claim lands */
	_countUpPay(el, target) {
		if (!el) return;
		const t0 = performance.now(), dur = 700;
		const tick = (now) => {
			const t = Math.min(1, (now - t0) / dur);
			const eased = 1 - Math.pow(1 - t, 3);
			el.textContent = '+' + Math.round(target * eased);
			if (t < 1) requestAnimationFrame(tick);
		};
		requestAnimationFrame(tick);
	},

	/* ---------------------------------------------------------- shop */
	_buildShop() {
		const s = this.el.shop;
		s.innerHTML = `
			<div class="go-title yellow-title">HAT SHOP</div>
			<div class="subtitle shop-coins">your coins: <span class="coin" aria-hidden="true"></span> <b id="shop-coins">0</b></div>
			<div class="shop-grid" id="shop-grid" role="list"></div>
			<button class="btn coral small" id="shop-back" data-autofocus>BACK</button>
			<div class="hint">level up a character on the CHARACTERS screen to boost its perk 📈</div>
		`;
		s.querySelector('#shop-back').addEventListener('click', () => {
			SFX.play('button', 0.06);
			this.show('menu');
		});
	},

	_renderShop() {
		const grid = this.el.shop.querySelector('#shop-grid');
		grid.textContent = '';
		const d = Storage.data;
		this.el.shop.querySelector('#shop-coins').textContent = String(d.coins);
		for (const hat of HATS) {
			const owned = d.hats.owned.includes(hat.id);
			const equipped = d.hats.equipped === hat.id;
			const affordable = d.coins >= hat.price;
			const card = document.createElement('div');
			card.className = 'shop-card' + (equipped ? ' selected' : '') + (!owned ? ' locked' : '') + (!owned && affordable ? ' affordable' : '');
			card.setAttribute('role', 'listitem');
			card.tabIndex = 0;

			// hat preview drawn on a small canvas — always full colour
			// (greyscale previews read as broken, not as locked)
			const cv = document.createElement('canvas');
			cv.width = cv.height = 120;
			const g = cv.getContext('2d');
			g.save();
			g.translate(60, 78);
			drawHat(g, hat, 0, 0, 34);
			g.restore();
			cv.className = 'hat-preview';
			card.appendChild(cv);

			if (!owned) {
				const chip = document.createElement('div');
				chip.className = 'lock-chip';
				chip.textContent = '🔒';
				card.appendChild(chip);
			}

			const name = document.createElement('div');
			name.className = 'name';
			name.textContent = hat.name;
			card.appendChild(name);

			const foot = document.createElement('div');
			if (equipped) {
				foot.className = 'badge';
				foot.textContent = 'WEARING ✓';
			} else if (owned) {
				foot.className = 'badge blue';
				foot.textContent = 'WEAR';
			} else {
				foot.className = 'price' + (affordable ? ' can-buy' : '');
				foot.append(this._coinEl(), ' ' + hat.price);
			}
			card.appendChild(foot);

			const activate = () => this._hatClick(hat);
			card.addEventListener('click', activate);
			card.addEventListener('keydown', (e) => {
				if (e.code === 'Enter' || e.code === 'Space') { e.preventDefault(); activate(); }
			});
			grid.appendChild(card);
		}
	},

	_hatClick(hat) {
		const d = Storage.data;
		if (d.hats.owned.includes(hat.id)) {
			d.hats.equipped = hat.id;
			Storage.save();
			SFX.play('button', 0.06);
			this._renderShop();
		} else if (d.coins >= hat.price) {
			d.coins -= hat.price;
			d.hats.owned.push(hat.id);
			d.hats.equipped = hat.id;
			Storage.save();
			SFX.play('powerup', 0.05, 1.1);
			this.toast(`NEW HAT: ${hat.name}! 🎩`);
			this._renderShop();
			this.refreshMenu();
		} else {
			SFX.play('break', 0.1, 0.6);
			this.toast(`need ${hat.price - d.coins} more coins — go climb!`);
		}
	},

	/* ---------------------------------------------------------- howto */
	_buildHowto() {
		const h = this.el.howto;
		h.innerHTML = `
			<div class="go-title green-title">HOW TO TOOT</div>
			<div class="card">
				<div class="howto-list">
					<b>DRAG</b> anywhere to steer (or <b>← →</b> / <b>A D</b>)<br>
					You auto-fart upward — just don't miss 💨<br>
					<b>STOMP</b> grumps from above for style<br>
					Chain springs &amp; stomps for <b>COMBO TIERS</b><br>
					Grab <span class="coin" aria-hidden="true"></span> coins → unlock the whole meme squad<br>
					Spikes &amp; grumps only <b>knock you down</b> —<br>
					you only die by falling off the screen!<br>
					Chase the dashed <b>BEST line</b> 🏁<br>
					<b>P</b> or <b>ESC</b> pauses
				</div>
			</div>
			<div class="card">
				<div class="legend">
					<div class="row"><div class="swatch sw-normal"></div>plain platform — the vibe</div>
					<div class="row"><div class="swatch sw-moving"></div>moving — it's shy</div>
					<div class="row"><div class="swatch sw-break"></div>crumbly — one toot max</div>
					<div class="row"><div class="swatch sw-spring"></div>SPRING — mega launch</div>
					<div class="row"><div class="swatch sw-ghost"></div>ghost — blinks in &amp; out</div>
					<div class="row spike-row"><div class="swatch sw-spike"></div>spikes — land on the EDGES</div>
				</div>
			</div>
			<button class="btn coral small" id="howto-back" data-autofocus>GOT IT</button>
		`;
		h.querySelector('#howto-back').addEventListener('click', () => {
			SFX.play('button', 0.06);
			this.show('menu');
		});
	},

	/* ---------------------------------------------------------- badges */
	_buildBadges() {
		const b = this.el.badges;
		b.innerHTML = `
			<div class="go-title yellow-title">BADGES</div>
			<div class="subtitle" id="badges-progress"></div>
			<div class="badge-grid" id="badge-grid" role="list"></div>
			<button class="btn coral small" id="badges-back" data-autofocus>BACK</button>
		`;
		b.querySelector('#badges-back').addEventListener('click', () => {
			SFX.play('button', 0.06);
			this.show('menu');
		});
	},

	_renderBadges() {
		const grid = this.el.badges.querySelector('#badge-grid');
		grid.textContent = '';
		const d = Storage.data;
		let got = 0;
		for (const a of Achievements.DEFS) {
			const unlocked = d.achievements.includes(a.id);
			if (unlocked) got++;
			const card = document.createElement('div');
			card.className = 'badge-card' + (unlocked ? '' : ' locked');
			card.setAttribute('role', 'listitem');
			const icon = document.createElement('div');
			icon.className = 'badge-icon';
			icon.textContent = unlocked ? a.icon : '🔒';
			const name = document.createElement('div');
			name.className = 'badge-name';
			name.textContent = a.name;
			const desc = document.createElement('div');
			desc.className = 'badge-desc';
			desc.textContent = unlocked ? a.desc : '???';
			card.append(icon, name, desc);
			grid.appendChild(card);
		}
		this.el.badges.querySelector('#badges-progress').textContent =
			`${got} / ${Achievements.DEFS.length} unlocked`;
	},

	/* ---------------------------------------------------------- quiz */
	/* First-launch meme quiz: hides the audio-decode hitch, teaches the
	   soundboard, and pays a few coins. One overlay, three questions,
   three buttons each. */
	QUIZ: [
		{ q: 'You flatten a grump. Which meme plays?', a: ['BOING + taunt time', 'sad violin', 'door creak'], right: 0 },
		{ q: 'You grab a coin. What do you hear?', a: ['MEGA TOOT', 'a money meme (short!)', 'rocket launch'], right: 1 },
		{ q: 'GAME OVER. What sound hits?', a: ['a dramatic meme', 'silence', 'bird chirps'], right: 0 },
	],

	_buildQuiz() {
		const qz = document.createElement('div');
		qz.id = 'screen-quiz';
		qz.className = 'screen hidden dim';
		qz.setAttribute('aria-hidden', 'true');
		document.getElementById('ui').appendChild(qz);
		this.el.quiz = qz;
		this.SCREENS.push('quiz');
		this._quizStep = 0;
		this._quizRight = 0;
		this._renderQuiz();
	},

	_renderQuiz() {
		const qz = this.el.quiz;
		const step = this._quizStep;
		if (step >= this.QUIZ.length) return this._finishQuiz();
		const item = this.QUIZ[step];
		qz.innerHTML = `
			<div class="go-title blue-title" style="font-size:54px">MEME QUIZ</div>
			<div class="subtitle">question ${step + 1} of ${this.QUIZ.length} — win coins!</div>
			<div class="card quiz-card"><div class="quiz-q">${item.q}</div></div>
			<div class="quiz-answers" id="quiz-answers"></div>
		`;
		const wrap = qz.querySelector('#quiz-answers');
		item.a.forEach((label, i) => {
			const btn = document.createElement('button');
			btn.className = 'btn small ' + ['green', 'blue', 'coral'][i % 3];
			btn.textContent = label;
			btn.addEventListener('click', () => {
				const good = i === item.right;
				if (good) this._quizRight++;
				SFX.play(good ? 'coin' : 'break', 0.1, good ? 1.2 : 0.7);
				this._quizStep++;
				this._renderQuiz();
			});
			wrap.appendChild(btn);
		});
	},

	_finishQuiz() {
		Storage.data.quizDone = true;
		const earned = this._quizRight * 30;
		Storage.data.coins += earned;
		Storage.save();
		this.show('menu');
		this.toast(`quiz done! +${earned} coins 🪙`);
	},

	/* ---------------------------------------------------------- pause */
	_buildPause() {
		const p = this.el.pause;
		p.classList.add('dim');
		p.innerHTML = `
			<div class="go-title blue-title">PAUSED</div>
			<div class="subtitle">catching your breath? 💨</div>
			<canvas id="pause-mascot" width="200" height="150" style="width:200px;height:150px" aria-hidden="true"></canvas>
			<div class="pause-score" id="pause-score"></div>
			<button class="btn" id="pause-resume" data-autofocus>RESUME</button>
			<div class="slider-row">🔊
				<input type="range" id="pause-vol-sfx" min="0" max="100" step="5" aria-label="sound effects volume">
			</div>
			<div class="slider-row">🎵
				<input type="range" id="pause-vol-music" min="0" max="100" step="5" aria-label="music volume">
			</div>
			<button class="btn coral small" id="pause-menu">MAIN MENU</button>
		`;
		p.querySelector('#pause-resume').addEventListener('click', () => {
			SFX.play('button', 0.06);
			Game.resume();
		});
		p.querySelector('#pause-menu').addEventListener('click', () => {
			SFX.play('button', 0.06);
			Game.toMenu();
		});
		p.querySelector('#pause-vol-sfx').addEventListener('input', (e) =>
			this._setVolume('sfxVol', e.target.value / 100));
		p.querySelector('#pause-vol-music').addEventListener('input', (e) =>
			this._setVolume('musicVol', e.target.value / 100));
		this._pauseMascotCtx = p.querySelector('#pause-mascot').getContext('2d');
	},

	refreshPause() {
		const s = Storage.data.settings;
		const p = this.el.pause;
		for (const k of ['sfx', 'music', 'haptics']) {
			const chip = p.querySelector('#pause-' + k);
			if (!chip) continue;
			chip.classList.toggle('on', !!s[k]);
			chip.setAttribute('aria-pressed', s[k] ? 'true' : 'false');
		}
		const vs = p.querySelector('#pause-vol-sfx');
		const vm = p.querySelector('#pause-vol-music');
		if (vs) vs.value = Math.round(s.sfxVol * 100);
		if (vm) vm.value = Math.round(s.musicVol * 100);
		const sc = p.querySelector('#pause-score');
		if (sc) {
			sc.textContent = '';
			sc.append(`${World.score()} m · `, this._coinEl(), ` ${World.runCoins} this run`);
		}
	},

	/* ---------------------------------------------------------- game over */
	_buildGameOver() {
		const o = this.el.over;
		o.classList.add('dim');
		o.innerHTML = `
			<div class="go-title" id="go-title">RIP BOZO</div>
			<div class="go-msg" id="go-msg"></div>
			<div class="newbest hidden" id="go-newbest">NEW BEST! 🏆</div>
			<div class="go-score" id="go-score">0 m</div>
			<div class="go-best" id="go-best"></div>
			<div class="go-nudge hidden" id="go-nudge"></div>
			<div class="go-earn" id="go-earn"></div>
			<div class="rewards-card hidden" id="go-rewards">
				<div class="rewards-title">🎉 EARNED THIS RUN</div>
				<div id="rewards-lines"></div>
			</div>
			<div class="recap-card" id="go-recap">
				<canvas id="recap-face" width="120" height="110" aria-hidden="true"></canvas>
				<div id="recap-lines"></div>
			</div>
			<button class="btn yellow hidden" id="go-revive">CONTINUE</button>
			<div class="revive-note hidden" id="go-revive-note"></div>
			<button class="btn" id="go-retry" data-autofocus>TOOT AGAIN</button>
			<div class="retry-hint" id="go-retry-hint">or tap anywhere to retry</div>
			<div class="btn-row">
				<button class="btn blue small" id="go-share">📷 SHARE CARD</button>
				<button class="btn grey small" id="go-menu">MAIN MENU</button>
			</div>
		`;
		o.querySelector('#go-retry').addEventListener('click', () => {
			SFX.play('jump', 0.15);
			Game.startRun();
		});
		// tap anywhere on the game-over card = instant retry (the zero-friction
		// death→play loop). Buttons still work; retry ignores clicks on them.
		o.addEventListener('click', (e) => {
			if (this._current !== 'over') return;
			if (e.target.closest('button')) return;
			if (this._reviveT > 0) return;    // don't steal the revive decision
			SFX.play('jump', 0.15);
			Game.startRun();
		});
		o.querySelector('#go-menu').addEventListener('click', () => {
			SFX.play('button', 0.06);
			Game.toMenu();
		});
		o.querySelector('#go-share').addEventListener('click', (e) => {
			e.stopPropagation();
			this._share();
		});
		o.querySelector('#go-revive').addEventListener('click', () => {
			if (this._onRevive) this._onRevive();
		});
	},

	showGameOver(data) {
		const o = this.el.over;
		this._lastOverScore = data.score;
		this._lastOverBest = data.isNewBest;
		o.querySelector('#go-title').textContent = data.title;
		o.querySelector('#go-msg').textContent = data.line;
		o.querySelector('#go-best').textContent = `BEST ${data.best} m`;
		const earn = o.querySelector('#go-earn');
		earn.textContent = '';
		earn.append('earned ', this._coinEl(), ` ${data.coins} this run`);
		o.querySelector('#go-newbest').classList.toggle('hidden', !data.isNewBest);

		// "X m from your best!" + a pulsing retry when a record slipped away
		const nudge = o.querySelector('#go-nudge');
		const retry = o.querySelector('#go-retry');
		if (!data.isNewBest && data.gapToBest > 0 && data.gapToBest <= 75) {
			nudge.textContent = `🎯 just ${data.gapToBest} m from your best!`;
			nudge.classList.remove('hidden');
			retry.classList.add('pulse');
		} else {
			nudge.classList.add('hidden');
			retry.classList.remove('pulse');
		}

		// everything the run PAID: cups, crates, training, daily — so the
		// rewards from a high climb are still visible after it ends
		const rewards = o.querySelector('#go-rewards');
		const rlines = o.querySelector('#rewards-lines');
		if (data.rewards && data.rewards.length) {
			rewards.classList.remove('hidden');
			rlines.textContent = '';
			for (const r of data.rewards) {
				const div = document.createElement('div');
				div.className = 'reward-line';
				div.append(`${r.icon} ${r.label}`);
				rlines.appendChild(div);
			}
		} else {
			rewards.classList.add('hidden');
		}

		// the death recap: your character, dizzy, with the run's funniest facts
		const recap = o.querySelector('#go-recap');
		const lines = o.querySelector('#recap-lines');
		if (data.recap && data.recap.length) {
			recap.classList.remove('hidden');
			lines.textContent = '';
			for (const line of data.recap) {
				const div = document.createElement('div');
				div.className = 'recap-line';
				div.textContent = line;
				lines.appendChild(div);
			}
			const face = o.querySelector('#recap-face').getContext('2d');
			face.clearRect(0, 0, 120, 110);
			face.save();
			face.translate(60, 58);
			drawCharacter(face, CharacterArt.byId(Storage.data.selected), {
				t: 0.6, vy: 200, hurt: true, blinkSeed: 3.3, scale: 0.85,
			});
			face.restore();
		} else {
			recap.classList.add('hidden');
		}

		const reviveBtn = o.querySelector('#go-revive');
		const reviveNote = o.querySelector('#go-revive-note');
		if (data.canRevive) {
			// label set here so there is no visible "100 → 50" flash
			reviveBtn.textContent = '';
			reviveBtn.append('CONTINUE · ', this._coinEl(), ' ' + data.reviveCost);
			reviveBtn.setAttribute('aria-label', `Continue for ${data.reviveCost} coins`);
			reviveBtn.classList.remove('hidden');
			reviveNote.classList.remove('hidden');
			this._reviveT = this._reviveMax = CFG.REVIVE_WINDOW;
			reviveNote.textContent = this._reviveLabel();
		} else {
			reviveBtn.classList.add('hidden');
			reviveNote.classList.add('hidden');
			this._reviveT = 0;
		}

		this.show('over');
		this._startCountUp(o.querySelector('#go-score'), data.score);
	},

	/* rAF-driven count-up. The old setInterval was never cancelled when the
	   screen closed, so back-to-back runs left orphaned timers writing into
	   a hidden element. */
	_startCountUp(el, target) {
		this._stopCountUp();
		const safeTarget = Math.max(0, Math.floor(Number(target) || 0));
		this._countAnim = {
			el,
			target: safeTarget,
			cur: 0,
			dur: Math.min(1.0, 0.25 + safeTarget * 0.0016),
			t: 0,
			done: safeTarget === 0,
		};
		el.textContent = safeTarget === 0 ? '0 m' : '0 m';
	},

	_stopCountUp() {
		this._countAnim = null;
	},

	_tickCountUp(dt) {
		const a = this._countAnim;
		if (!a || a.done) return;
		a.t += dt;
		const k = Math.min(1, a.t / a.dur);
		// ease-out so the last digits settle
		const eased = 1 - Math.pow(1 - k, 3);
		const v = Math.round(a.target * eased);
		if (v !== a.cur) {
			a.cur = v;
			a.el.textContent = v + ' m';
		}
		if (k >= 1) {
			a.done = true;
			a.el.textContent = a.target + ' m';
			if (a.el.animate) {
				try {
					a.el.animate(
						[{ transform: 'scale(1)' }, { transform: 'scale(1.12)' }, { transform: 'scale(1)' }],
						{ duration: 260, easing: 'ease-out' }
					);
				} catch (e) { /* older WebView */ }
			}
		}
	},

	setReviveHandlers(onRevive, onExpire) {
		this._onRevive = onRevive;
		this._onReviveExpire = onExpire;
	},

	/* "continuing in 6..." implied the game would resume by itself. The offer
	   expires; it does not auto-accept. */
	_reviveLabel() {
		return `offer expires in ${Math.ceil(Math.max(0, this._reviveT))}...`;
	},

	updateRevive(dt) {
		if (this._reviveT <= 0) return;
		this._reviveT -= dt;
		const o = this.el.over;
		const note = o.querySelector('#go-revive-note');
		if (this._reviveT <= 0) {
			o.querySelector('#go-revive').classList.add('hidden');
			note.classList.add('hidden');
			if (this._onReviveExpire) this._onReviveExpire();
			return;
		}
		note.textContent = this._reviveLabel();
	},

	cancelRevive() {
		this._reviveT = 0;
		const o = this.el.over;
		o.querySelector('#go-revive').classList.add('hidden');
		o.querySelector('#go-revive-note').classList.add('hidden');
	},

	async _share() {
		const d = Storage.data;
		try {
			await ShareCard.share(this._lastOverScore ?? d.best, this._lastOverBest ?? false, null);
			return;
		} catch (e) { /* fall through to text share */ }
		const text = `I tooted ${d.best} m into the sky in TOOT JUMP 2 💨 beat that.`;
		try {
			if (navigator.share) {
				await navigator.share({ text, title: 'TOOT JUMP 2' });
				return;
			}
		} catch (e) { return; /* user cancelled the sheet */ }
		try {
			if (navigator.clipboard && navigator.clipboard.writeText) {
				await navigator.clipboard.writeText(text);
				this.toast('score copied to clipboard! 📋');
				return;
			}
		} catch (e) { /* clipboard blocked */ }
		this.toast(text);
	},

	/* ---------------------------------------------------------- HUD */
	updateHUD() {
		const w = World;
		const sc = w.score();
		if (sc !== this._lastScore) {
			this.el.hudScore.textContent = sc;
			this._lastScore = sc;
		}
		const coins = Storage.data.coins;
		if (coins !== this._lastCoins) {
			this.el.hudCoins.textContent = coins;
			this._lastCoins = coins;
		}

		if (w.combo > 0) {
			const wasHidden = this.el.comboPill.classList.contains('hidden');
			if (wasHidden) this.el.comboPill.classList.remove('hidden');
			const tier = Math.max(0, w.comboTier);
			if (tier !== this._lastTier || wasHidden) {
				this._lastTier = tier;
				this.el.comboName.textContent = `${CFG.TIERS[tier]} ×${w.combo}`;
				this.el.comboName.style.color = CFG.TIER_COLORS[tier];
				this.el.comboFill.style.background = CFG.TIER_COLORS[tier];
				this.el.comboPill.style.animation = 'none';
				void this.el.comboPill.offsetWidth;
				this.el.comboPill.style.animation = '';
			} else {
				this.el.comboName.textContent = `${CFG.TIERS[tier]} ×${w.combo}`;
			}
			const maxT = CFG.COMBO_TIME + (w.player.char.perkCode === 'longCombo' ? 1.5 : 0);
			const frac = Math.max(0, Math.min(1, w.comboTimer / maxT));
			this.el.comboFill.style.transform = `scaleX(${frac})`;
		} else if (!this.el.comboPill.classList.contains('hidden')) {
			this.el.comboPill.classList.add('hidden');
			this._lastTier = -1;
		}
	},

	resetHUD() {
		this._lastScore = -1;
		this._lastCoins = -1;
		this._lastTier = -1;
		this.el.comboPill.classList.add('hidden');
	},

	/* ---------------------------------------------------------- banners */
	zoneBanner(name, idx) {
		const b = this.el.zoneBanner;
		b.textContent = `✨ ${name} ✨`;
		b.classList.toggle('night', idx >= 3);
		b.classList.remove('hidden');
		b.style.animation = 'none';
		void b.offsetWidth;
		b.style.animation = '';
		clearTimeout(this._bannerTO);
		this._bannerTO = setTimeout(() => b.classList.add('hidden'), 2600);
	},

	hideBanner() {
		clearTimeout(this._bannerTO);
		this.el.zoneBanner.classList.add('hidden');
	},

	/* `coinSuffix`, when given, is appended followed by a drawn coin icon */
	toast(text, coinSuffix) {
		// cap: a mission cascade used to stack a dozen overlapping toasts
		while (this.el.toasts.children.length >= CFG.MAX_TOASTS) {
			this.el.toasts.removeChild(this.el.toasts.firstChild);
		}
		const t = document.createElement('div');
		t.className = 'toast';
		t.setAttribute('role', 'status');
		t.dataset.ts = String(Date.now());
		t.textContent = text;
		if (coinSuffix) t.append('  ' + coinSuffix + ' ', this._coinEl());
		this.el.toasts.appendChild(t);
		setTimeout(() => {
			t.classList.add('out');
			setTimeout(() => { if (t.parentNode) t.remove(); }, 350);
		}, 2400);
	},

	/* returning to the menu must not show run toasts drifting over the
	   menu cards — drop anything that has already been on screen a while */
	_trimStaleToasts() {
		const now = Date.now();
		for (const t of [...this.el.toasts.children]) {
			const ts = Number(t.dataset.ts || 0);
			if (!ts || now - ts > 2000) t.remove();
		}
	},

	/* out-of-store update banner — Updater found a newer APK than the
	   installed one; keep it visible on the menu until the player updates */
	showUpdateBanner(apkUrl) {
		this._updateApkUrl = apkUrl;
		const b = this.el.menu.querySelector('#update-banner');
		if (b) b.classList.remove('hidden');
	},

	clearToasts() {
		this.el.toasts.textContent = '';
	},

	/* ---------------------------------------------------------- ticker */
	tick(t, dt) {
		this._tickCountUp(dt || 0);

		// mascot bounce on the menu — only while the menu is actually visible
		if (this._mascotCtx && this._current === 'menu') {
			const g = this._mascotCtx;
			g.clearRect(0, 0, 240, 150);
			g.save();
			g.translate(120, 75 + Math.sin(t * 2.2) * 8);
			drawCharacter(g, CharacterArt.byId(Storage.data.selected), {
				t, vy: -650, blinkSeed: 1.7, scale: 1.05,
			});
			g.restore();
		}

		// idle mascot on the pause card — tapping its foot, waiting for you
		if (this._pauseMascotCtx && this._current === 'pause') {
			const g = this._pauseMascotCtx;
			g.clearRect(0, 0, 200, 150);
			g.save();
			g.translate(100, 72 + Math.sin(t * 1.4) * 4);
			drawCharacter(g, CharacterArt.byId(Storage.data.selected), {
				t: t * 0.7, vy: 0, blinkSeed: 2.4, scale: 1.0,
			});
			g.restore();
		}
	},
};

if (typeof module !== 'undefined' && module.exports) module.exports = { UI };
