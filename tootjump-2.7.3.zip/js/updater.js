'use strict';
/* ============================================================
   Updater — out-of-store update flow.

   TWO update layers, because a side-loaded APK (no Play Store)
   can't update itself silently in one mechanism:

   1. WEB BUNDLE (silent, automatic): @capgo/capacitor-updater is
      configured in capacitor.config.json with `updateUrl` pointing
      at our update feed. On every launch the plugin POSTs to the
      feed; if the feed answers {version, url, checksum} it
      downloads the new www/ zip, verifies it, and hot-swaps it for
      the NEXT launch — no permissions, no user action. Any change
      that lives in js/css/assets ships this way.

   2. NATIVE APK (banner, two taps): changes inside the native
      shell (new Capacitor plugins, manifest/theme/cutout changes)
      need a new APK. This module fetches the same feed, compares
      feed.apkVersion against the installed versionName, and shows
      a banner on the menu linking to feed.apk — the player taps,
      the browser downloads the APK, and Android's package installer
      takes over (the browser gets "install unknown apps" grant
      once, first time only).

   The feed is a static JSON + zip files on GitHub Pages (free),
   produced by `node tools/publish-update.mjs` after every release.

   On the web build (no Capacitor) everything here is a no-op, so
   the test sandbox can load this file safely for cmpVersion().
   ============================================================ */

const Updater = {
	/* the feed URL — MUST match capacitor.config.json's updateUrl host */
	FEED_URL: 'https://vikashmeena777.github.io/TooT-Jump-2/update.json',

	/* semver-ish compare: -1 a<b, 0 equal, 1 a>b. Tolerates "2.7.0" vs
	   "2.7" and strips leading noise like "v" */
	cmpVersion(a, b) {
		const parse = (v) => String(v || '0').replace(/^v/i, '').split('.')
			.map(n => parseInt(n, 10) || 0);
		const pa = parse(a), pb = parse(b);
		const len = Math.max(pa.length, pb.length);
		for (let i = 0; i < len; i++) {
			const d = (pa[i] || 0) - (pb[i] || 0);
			if (d) return d < 0 ? -1 : 1;
		}
		return 0;
	},

	_plugins() {
		return (window.Capacitor && window.Capacitor.Plugins) || null;
	},

	/* check the feed once per session; called from Game.boot (after UI is
	   ready) and only inside the APK */
	async check() {
		if (!this._plugins()) return;                       // web build — no-op
		const App = this._plugins().App;
		if (!App || !App.getInfo) return;
		let info;
		try { info = await App.getInfo(); } catch (e) { return; }
		if (!info || !info.version) return;

		let feed;
		try {
			const ctrl = ('AbortController' in window) ? new AbortController() : null;
			const t = ctrl ? setTimeout(() => ctrl.abort(), 6000) : null;
			const res = await fetch(this.FEED_URL, { cache: 'no-store', signal: ctrl ? ctrl.signal : undefined });
			if (t !== null) clearTimeout(t);
			if (!res.ok) return;
			feed = await res.json();
		} catch (e) { return; }                            // offline / no feed yet — stay quiet

		if (!feed || typeof feed !== 'object') return;

		// native update available? (web-bundle updates are handled by the
		// capacitor-updater plugin itself, entirely outside this code)
		if (feed.apkVersion && feed.apk &&
			this.cmpVersion(feed.apkVersion, info.version) > 0) {
			if (typeof UI !== 'undefined' && UI.showUpdateBanner) {
				UI.showUpdateBanner(feed.apk);
			}
		}
	},

	async openApk(url) {
		const P = this._plugins();
		if (P && P.Browser && P.Browser.open) {
			try { await P.Browser.open({ url }); return; } catch (e) { /* fall through */ }
		}
		try { window.open(url, '_blank'); } catch (e) { /* ignore */ }
	},
};

if (typeof module !== 'undefined' && module.exports) module.exports = { Updater };
