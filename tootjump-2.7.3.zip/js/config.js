'use strict';
/* ============================================================
   TOOT JUMP 2 — central tunables.

   IMPORTANT: the generation limits at the bottom of this file are
   DERIVED from the physics above, not hand-guessed. The old build
   hard-coded "gap <= 280 < 301px apex" which ignored the fact that
   a jump that *barely* clears a gap arrives with ~0 vertical speed
   and therefore has almost no time to travel sideways. That made
   late-game rows genuinely unreachable. See _deriveLimits().
   ============================================================ */

const CFG = {
	/* Design space.

	   VIEW_W is FIXED at 720 on every device: the horizontal budget is what
	   makes a row reachable, so it must never vary or the difficulty would
	   change with screen width.

	   VIEW_H adapts to the device aspect ratio (clamped) so the game fills
	   the screen instead of letterboxing. Nothing in the physics or the level
	   generator depends on VIEW_H — the fall margin is measured from the
	   camera (KILL_BELOW), not from the screen edge — so a taller phone only
	   sees a little further ahead. */
	VIEW_W: 720,
	VIEW_H: 1280,
	VIEW_H_REF: 1280,
	VIEW_H_MIN: 1100,
	VIEW_H_MAX: 1780,

	/* Called by the resize handler. Returns true if the height changed. */
	setViewHeight(h) {
		const clamped = Math.round(Math.max(this.VIEW_H_MIN, Math.min(this.VIEW_H_MAX, h)));
		if (clamped === this.VIEW_H) return false;
		this.VIEW_H = clamped;
		// "you die by falling off the bottom of the screen" has to mean the
		// same thing on every screen, so the kill line follows the view.
		// Only a sliver of grace below the visible edge — the old +60 (plus
		// the player's collision radius) let the player land on platforms
		// that were fully below the screen and bounce back up from nowhere.
		this.KILL_BELOW = Math.round(clamped / 2) + 24;
		return true;
	},

	/* ---------------------------------------------------- physics */
	GRAVITY: 1200,
	BOUNCE: -850,          // upward launch velocity of a normal bounce
	MAX_FALL: 1500,
	KEY_SPEED: 700,        // top horizontal speed from keyboard
	KEY_ACCEL: 3600,
	DRAG_SENS: 1.4,
	WRAP: 60,              // horizontal screen wrap slack
	PLAYER_R: 34,

	/* ---------------------------------------------------- generation */
	MARGIN_X: 78,          // platforms stay this far from screen edges
	DIFF_DIST: 15000,      // px of climb (~300 m) to reach full difficulty
	KILL_BELOW: 700,       // below the camera centre — derived from VIEW_H
	SPAWN_AHEAD: 900,      // spawn this far above the camera top

	/* Landing must remain possible even at max difficulty. Filled in by
	   _deriveLimits() below — do not hand-edit. */
	GAP_MIN: 150,
	GAP_MAX_EARLY: 205,
	GAP_MAX_LATE: 205,     // derived
	MAX_DX_EARLY: 300,     // derived — horizontal delta between rows
	MAX_DX_LATE: 300,      // derived

	/* ---------------------------------------------------- fairness */
	SPIKE_START_M: 120,    // no spikes before this altitude
	ENEMY_START_M: 45,     // no enemies before this altitude
	SPIKE_SPAN: 0.66,      // spikes cover at most this fraction of the width
	SPIKE_MIN_EDGE: 34,    // landable px that must remain on EACH edge
	SPIKE_MIN_BAND: 30,    // minimum usable landing band per edge, else no spike
	HURT_KNOCK_VY: 480,    // downward knockback on hit (not death)
	HURT_INVULN: 0.8,      // seconds of blinking invulnerability (was 1.6 —
	                       // the long "lifeline" made grumps feel toothless)
	/* HIT HEAT — hits landing close together escalate: each hit inside the
	   window adds a stack of extra downward knock (players learn chains of
	   sloppy plays snowball, without any single hit being lethal). */
	HURT_HEAT_WINDOW: 6,   // seconds between hits that count as a chain
	HURT_HEAT_KNOCK: 180,  // extra downward vy per heat stack
	HURT_HEAT_MAX: 3,      // stack cap
	MAX_HAZARD_ROWS: 3,    // never more consecutive hazard rows than this

	/* ---------------------------------------------------- economy */
	REVIVE_COST: 100,
	ZONE_COINS: 20,
	ZONE_SCORE: 50,
	REVIVE_WINDOW: 6.0,    // seconds to decide (was a punishing 3s)

	/* ---------------------------------------------------- invisible DDA
	   Quietly widens/narrows the level to keep players in flow. This is the
	   single biggest retention lever, and by design it is never announced:
	   nobody knows, everyone stays. Deaths within DDA_BAND m of each other
	   count as "stuck at the same wall"; after DDA_DEATHS of them the
	   generator eases by up to DD_EASE_MAX (shorter gaps, safer hazards).
	   A run DDA_RECOVER_M m past the wall clears the state. */
	DDA_BAND: 60,          // m
	DDA_DEATHS: 2,
	DD_EASE_MAX: 0.30,     // 0..1 — how much gap/dx shrink at full ease
	DDA_RECOVER_M: 40,
	/* Hard fairness floor: even at full ease the game is never easier than
	   the ORIGINAL early-game numbers, so DDA cannot be felt as trivial. */
	DD_GAP_MIN_FLOOR: 130,

	/* ---------------------------------------------------- daily challenge
	   One seeded run per calendar day: everyone on Earth gets the exact
	   same level, so scores are comparable. Rewards pay once a day. */
	DAILY_BONUS: 150,      // coins for beating your own daily best
	DAILY_STREAK_BONUS: 100,

	/* ---------------------------------------------------- cups */
	CUP_STEP: 100,         // a trophy shelf level every 100 m best
	CUP_REWARD: 50,        // coins paid the moment a cup is earned
	CUP_COLORS: { bronze: '#b0793f', silver: '#b9c2cf', gold: '#ffd166', plat: '#c4a6ec' },

	/* ---------------------------------------------------- mystery gift */
	GIFT_START_M: 500,
	GIFT_EVERY_M: 400,
	GIFT_REWARDS: [
		{ kind: 'coins', n: 60 },
		{ kind: 'coins', n: 120 },
		{ kind: 'coins', n: 200 },
		{ kind: 'beans', n: 3 },
		{ kind: 'bubble' },
		{ kind: 'magnet' },
	],

	/* CRATE VAULT — banked crates are opened by the PLAYER from the menu.
	   Rewards must be persistent, so vault crates always pay coins.
	   Arrays are weighted by repetition (an entry appearing 3x is 3x as
	   likely). Golden crates pay strictly better. */
	VAULT_REWARDS: {
		normal: [60, 60, 60, 120, 120, 200, 300],
		golden: [150, 150, 250, 250, 400, 600],
	},

	/* ---------------------------------------------------- notifications */
	NOTIF_DEFAULT_HOUR: 19,   // 7pm local — after school/office, pre-dinner
	NOTIF_ID_STREAK: 1101,
	NOTIF_ID_DAILY: 1102,

	/* ---------------------------------------------------- character leveling */
	CHAR_LEVEL_COSTS: [400, 1000],  // coins to go lv1→2→3
	CHAR_LEVEL_TAGS: ['', ' +', ' ++'],

	/* ---------------------------------------------------- combo */
	COMBO_TIME: 5.0,
	COMBO_PER_TIER: 3,

	CLOSE_CALL_BAND: 16,   // px past a platform edge that still counts as a near miss
	CLOSE_CALL_SCORE: 10,
	CLOSE_CALL_COOLDOWN: 1.2,

	/* ---------------------------------------------------- perf */
	MAX_PARTICLES: 320,    // hard cap so slow phones never melt
	MAX_FLOATS: 24,
	MAX_TOASTS: 3,
	SPRITE_CACHE_MAX: 64,

	/* ---------------------------------------------------- adaptive quality
	   When the frame rate dips the game quietly sheds visual weight instead
	   of dropping frames: fewer particles, no vignette, no skyline. It
	   restores itself when the FPS recovers. */
	AQ_CHECK_EVERY: 2.0,   // seconds between FPS checks
	AQ_DROP_FPS: 47,       // below this for a check → shed a tier
	AQ_RESTORE_FPS: 56,    // above this for 2 checks → gain a tier back
	AQ_TIERS: 3,           // 0 = full juice, 2 = lightest

	/* Zone names have to fit the banner (720px design width, 42px type), so
	   they are kept short — the old "SPACE (NO AIR = NO TOOTS?!)" was
	   ellipsised to "SPACE (NO AIR = NO TO…" on every device.

	   `skin` picks the platform sprite material per zone (see
	   Platform._skinColors) so the world visibly changes as you climb. */
	ZONES: [
		{ m: 0,    name: 'SEA LEVEL STINK',     top: '#57c7e3', mid: '#8fd9d9', bot: '#def0c4', stars: 0,  sun: 'day'  },
		{ m: 400,  name: 'CLOUD NINE',          top: '#6fb7e8', mid: '#a8d8f0', bot: '#e8f4d8', stars: 0,  sun: 'day'  },
		{ m: 900,  name: 'GOLDEN HOUR GLOW-UP', top: '#ff9a5c', mid: '#ffc98a', bot: '#ffe8c2', stars: 0,  sun: 'set'  },
		{ m: 1500, name: 'NIGHT SHIFT',         top: '#27335f', mid: '#3a4a7d', bot: '#5a6b9c', stars: .8, sun: 'none' },
		{ m: 2200, name: 'SPACE — NO AIR?!',    top: '#131a3d', mid: '#232a5c', bot: '#3a3f7a', stars: 1,  sun: 'none' },
	],

	/* platform material per zone: [body, lip, deco] */
	PLATFORM_SKINS: [
		{ body: '#59cd90', lip: '#7fe0ac', deco: 'grass'  },   // sea level
		{ body: '#7fd4e8', lip: '#b3ecf7', deco: 'cloud'  },   // cloud nine
		{ body: '#f0b060', lip: '#ffd9a0', deco: 'honey'  },   // golden hour
		{ body: '#6f7ba8', lip: '#9aa7d4', deco: 'ice'    },   // night shift
		{ body: '#8a7fa8', lip: '#b5a8d9', deco: 'stars'  },   // space
	],

	TIERS: ['GAS', 'SPICY', 'SHEEESH', 'GIGACHAD', 'TOOT GOD'],
	TIER_COLORS: ['#59cd90', '#ffd166', '#ff9a5c', '#ff6f61', '#c4a6ec'],

	DEATH_TITLES: ['RIP BOZO', 'OOF.', 'GAME OVER', 'F IN THE CHAT', 'MISSION FAILED'],
	DEATH_LINES: [
		'the toot was FATAL 💀',
		'gravity remains undefeated',
		'you almost had it (no you didn\u2019t)',
		'F in the chat 🫡',
		'that spike had a family',
		'certified pancake moment',
		'not even close my guy',
		'the grumps send their regards',
		'beans were a mistake',
		'you fell OFF (literally)',
		'skill issue? never heard of it. oh wait.',
		'physics stays winning',
		'new achievement: becoming a pancake!',
	],

	/* Power-ups.

	   `icon` is drawn as VECTOR ART (see drawPowerupIcon in entities.js), not
	   as an emoji. The old build painted 🫧 / 🫘 / 🧲 with fillText, and those
	   codepoints are Emoji 11-14 — they render as empty tofu boxes on the
	   Android 7-9 devices this app still supports (minSdk 24), which made the
	   three most important pickups unreadable on exactly the cheap phones
	   most likely to play it. */
	POWERUPS: {
		BUBBLE: { w: .33, color: '#8ec4f2', icon: 'bubble', name: 'BUBBLE' },
		MAGNET: { w: .26, color: '#ff6f61', icon: 'magnet', name: 'MAGNET' },
		BEANS:  { w: .24, color: '#c07a3a', icon: 'beans',  name: 'BEANS'  },
		ROCKET: { w: .10, color: '#ffd166', icon: 'rocket', name: 'ROCKET' },
		/* the joke item: huge coin multiplier, but you toot from the other side */
		GOLDEN: { w: .04, color: '#d4a017', icon: 'golden', name: 'GOLDEN POOP' },
		GIFT:   { w: 0,    color: '#ff6f61', icon: 'gift',   name: 'MYSTERY GIFT' },
	},

	GOLDEN_TIME: 4.0,      // seconds of 5x coins + reversed steering
	GOLDEN_COIN_MULT: 5,

	/* grump trash talk — shown in tiny speech bubbles */
	TAUNTS: [
		'upar ja raha? hum bhi 😏',
		'ruk ja bhai ruk ja',
		'kitna udega?!',
		'seedha gir jaa na',
		'gir gaya to? 🤭',
		'chal hat',
		'zinda ho tum abhi bhi?',
		'aadat daal lo',
		'oye hoye',
		'legpiece aa rahi hai',
	],

	/* first-session quest chain — one goal at a time, guaranteed coins.
	   `type` matches Missions.notify events so no extra plumbing is needed. */
	TUTORIAL: [
		{ id: 't-bounce', label: 'Bounce 10 times', type: 'bounce', n: 10, reward: 30, hint: 'DRAG to steer. You auto-fart upward 💨' },
		{ id: 't-coin',   label: 'Grab 5 coins',   type: 'coin',   n: 5,  reward: 30, hint: 'Shiny coins = new characters & hats 🪙' },
		{ id: 't-stomp',  label: 'Stomp 1 grump',  type: 'stomp',  n: 1,  reward: 40, hint: 'Land on a grump from ABOVE to flatten it' },
		{ id: 't-spring', label: 'Ride a spring',  type: 'spring', n: 1,  reward: 40, hint: 'Yellow pads launch you MEGA high' },
		{ id: 't-combo',  label: 'Reach a 3x combo', type: 'tier', n: 0,  reward: 50, hint: 'Chain bounces without touching spikes' },
		{ id: 't-100',    label: 'Climb 100 m',    type: 'reach',  n: 100, reward: 60, hint: '100 m = your first trophy 🏆' },
	],

	PALETTE: {
		navy: '#232a45',
		cream: '#fff9ee',
		coral: '#ff6f61',
		yellow: '#ffd166',
		green: '#59cd90',
		sky: '#57c7e3',
	},
};

/* ============================================================
   Derive the generation limits from the physics so the level can never
   produce an unreachable row.

   The key insight the old build got wrong twice:
   landing only ever happens while DESCENDING (platforms are one-way).
   A player launched with speed B rises past a platform `gap` above,
   continues to the apex, and lands on that platform on the way back
   down. So the time available to steer is

       t = t_apex + t_descend(apex - gap)

   not the much shorter time to merely reach that height. That is why
   the "gap must be under the apex" rule is the real constraint, and
   why the horizontal budget can be generous — but it still has to be
   bounded, because a hurt knockback or a crumbling platform can cost
   the player the rest of that flight.
   ============================================================ */
(function _deriveLimits(C) {
	const G = C.GRAVITY;
	const B = Math.abs(C.BOUNCE);
	const apex = (B * B) / (2 * G);
	const apexT = B / G;

	C.BOUNCE_APEX = Math.round(apex);

	/* horizontal distance the player can cover between launching and
	   landing on a platform `gap` px higher. Returns 0 if the platform is
	   simply out of reach vertically. */
	C.reachForGap = function (gap) {
		if (!(gap < apex)) return 0;
		const tDescend = Math.sqrt(2 * Math.max(0, apex - gap) / G);
		return C.KEY_SPEED * (apexT + tDescend);
	};

	/* Vertical: never ask for more than 82% of the apex. Late game should
	   feel brutal — but arrival speed at 82% is still ~340px/s downward,
	   so a well-timed landing stays possible (and the soft-lock guard
	   keeps a permanent ladder through every consumable row). */
	C.GAP_MAX_LATE = Math.floor(apex * 0.82);
	C.GAP_MAX_EARLY = Math.min(205, C.GAP_MAX_LATE);
	C.GAP_MIN = Math.min(150, C.GAP_MAX_EARLY - 20);

	/* Horizontal: a fraction of what is actually reachable at the
	   hardest gap, so there is always slack for mistakes. */
	const worstReach = C.reachForGap(C.GAP_MAX_LATE);
	C.MAX_DX_EARLY = Math.round(Math.min(270, worstReach * 0.55));
	C.MAX_DX_LATE = Math.round(Math.min(460, worstReach * 0.78));

	/* the widest horizontal span the generator could ever need */
	C.MAX_SPAN = C.VIEW_W - 2 * C.MARGIN_X;
})(CFG);

if (typeof module !== 'undefined' && module.exports) module.exports = { CFG };
