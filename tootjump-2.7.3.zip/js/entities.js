'use strict';
/* ============================================================
   Entities — Player, Platform, Enemy, Coin, PowerUp.

   Fixes vs the previous build:
   - PLATFORM CACHE KEY included the spike flag but the spike hitbox
     used the *unrounded* width while the sprite used the rounded
     one, so the drawn spikes and the deadly span disagreed by up to
     4px. Both now use the same rounded width.
   - landCheck used `prevBottom > top + 6`, which let a fast faller
     (up to 1500px/s ≈ 75px per frame at 20fps) tunnel straight
     through a platform. It now does a proper swept test.
   - the sprite cache was keyed per 8px width bucket and capped by
     deleting the FIRST inserted key, which on a long run evicted the
     most common platform sprite over and over. Now it is an LRU.
   - VANISH platforms wrote `p.fade` only inside update(), so a
     platform drawn on its very first frame read `undefined`.
   - Enemy.draw used e.dir for pupil offset but bats set dir every
     frame from a cosine, causing a 1-frame eye jitter; smoothed.
   - Coin.update advanced `t` but the magnet moved coins in world.js
     with no velocity damping, so magnetised coins could orbit
     forever. Coins now converge.
   ============================================================ */

const NAVY = '#232a45';

/* Deterministic-per-run randomness for entities whose phase affects
   PHYSICS (moving-platform offset, ghost blink phase, enemy patrol).
   These used to draw from Math.random(), which made the fixed-seed
   autopilot slightly non-deterministic — the 90s survival test could
   flake. Drawing from World.rng() (seeded) keeps runs reproducible.
   Purely cosmetic phases (coins, pickups) can stay on Math.random. */
function _simRng() {
	if (typeof World !== 'undefined' && World && typeof World.rng === 'function') {
		const r = World.rng();
		if (Number.isFinite(r)) return r;
	}
	return Math.random();
}

/* ============================================================ PLATFORM */
const Platform = {
	NORMAL: 0, MOVING: 1, BREAKABLE: 2, SPRING: 3, VANISH: 4,
	HEIGHT: 24,
	_cache: new Map(),

	create(type, x, y, width, opts) {
		opts = opts || {};
		return {
			type, x, y,
			width: Math.max(48, width),
			moveRange: opts.moveRange || 160,
			moveSpeed: opts.moveSpeed || 1.6,
			spike: !!opts.spike,
			originX: x,
			t: _simRng() * Math.PI * 2,			broken: false,
			dead: false,
			solid: true,              // VANISH blinking
			vanishT: _simRng() * 2,
			fade: 1,
			springAnim: 0,
			squash: 0,                // landing squash timer
			age: 0,
			prevX: x,
		};
	},

	top(p) { return p.y - this.HEIGHT / 2; },

	/* rounded width — sprite AND hitbox must agree on this */
	spanWidth(p) { return Math.round(p.width / 8) * 8; },

	update(p, dt) {
		p.age += dt;
		p.t += dt;
		p.prevX = p.x;
		if (p.type === this.MOVING && !p.broken) {
			p.x = p.originX + Math.sin(p.t * p.moveSpeed) * p.moveRange;
		}
		if (p.type === this.VANISH && !p.broken) {
			p.vanishT += dt;
			// 1.35s solid (flicker warning at the end), 0.8s ghost
			const cyc = p.vanishT % 2.15;
			p.solid = cyc < 1.35;
			p.fade = p.solid
				? (cyc > 1.05 ? 0.55 + 0.45 * Math.abs(Math.sin(cyc * 22)) : 1)
				: Math.max(0.18, 1 - (cyc - 1.35) * 1.6);
		}
		if (p.springAnim > 0) p.springAnim = Math.max(0, p.springAnim - dt * 5);
		if (p.squash > 0) p.squash = Math.max(0, p.squash - dt * 4);
	},

	/* Swept one-way landing test.
	   prevBottom / newBottom are the player's bottom edge before and after
	   this step. A landing happens when the bottom edge CROSSES the top
	   surface during the step — this makes tunnelling impossible no matter
	   how fast the player falls. */
	landCheck(p, prevBottom, newBottom, px, pr) {
		if (p.broken || p.dead) return false;
		if (p.type === this.VANISH && !p.solid) return false;
		const top = this.top(p);
		// must have been at or above the surface, and now be at or below it
		if (prevBottom > top + 1) return false;
		if (newBottom < top) return false;
		// horizontal overlap with a small forgiving grace
		return Math.abs(px - p.x) < this.spanWidth(p) / 2 + pr * 0.25;
	},

	/* deadly span of a spiked platform — matches the painted spikes */
	spikeHalfSpan(p) {
		const w = this.spanWidth(p);
		const span = Math.min(w * CFG.SPIKE_SPAN, Math.max(0, w - CFG.SPIKE_MIN_EDGE * 2));
		return span / 2;
	},

	crumble(p) {
		if (p.broken) return;
		p.broken = true;
		p.dead = true;
	},

	/* LRU sprite cache — most-used sprites survive */
	_sprite(key, w, draw) {
		const hit = this._cache.get(key);
		if (hit) {
			// refresh recency
			this._cache.delete(key);
			this._cache.set(key, hit);
			return hit;
		}
		const pad = 50;
		const c = document.createElement('canvas');
		c.width = w + pad * 2;
		c.height = this.HEIGHT + 74 + pad * 2;
		const g = c.getContext('2d');
		g.translate(pad, pad + 60);
		draw(g, w, this.HEIGHT);
		c._pad = pad;
		this._cache.set(key, c);
		while (this._cache.size > CFG.SPRITE_CACHE_MAX) {
			const oldest = this._cache.keys().next().value;
			this._cache.delete(oldest);
		}
		return c;
	},

	clearCache() { this._cache.clear(); },

	/* zone material — platforms change their look as you climb.
	   `zi` is baked into the sprite key so each zone gets its own cache. */
	_skin(zi) {
		const skin = (CFG.PLATFORM_SKINS && CFG.PLATFORM_SKINS[zi]) || CFG.PLATFORM_SKINS[0];
		const base = { body: skin.body, lip: skin.lip, deco: skin.deco };
		// type overrides keep the gameplay coding readable
		if (base.deco === 'ice') { /* keep cold tones for every type */ }
		switch (this._skinType) {
			case this.MOVING:    base.body = '#5aa9e6'; base.lip = '#8ec4f2'; break;
			case this.BREAKABLE: base.body = '#e8a268'; base.lip = '#f2c08c'; break;
			case this.SPRING:    base.body = '#ffd166'; base.lip = '#ffe29a'; break;
			case this.VANISH:    base.body = '#e8ecf5'; base.lip = '#ffffff'; break;
		}
		return base;
	},

	draw(ctx, p, zi) {
		if (p.broken) return;
		const wb = this.spanWidth(p);
		this._skinType = p.type;
		const skin = this._skin(zi | 0);
		const key = `${p.type}_${wb}_${p.spike ? 1 : 0}_${zi | 0}`;
		const spr = this._sprite(key, wb, (g, w, h) => this._paint(g, p, w, h, skin));
		ctx.save();
		if (p.type === this.VANISH) {
			ctx.globalAlpha = Math.max(0, Math.min(1, p.fade));
		}
		// landing squash: 8% flatten on the frame the player touches down,
		// springing back over ~0.25s (springAnim is reused as the timer)
		if (p.squash > 0.01) {
			const q = p.squash;
			ctx.translate(p.x, p.y);
			ctx.scale(1 + q * 0.08, 1 - q * 0.18);
			ctx.drawImage(spr, -spr._pad, -spr._pad - 60);
		} else if (p.type === this.BREAKABLE && p.age < 0.25) {
			// spawn pop — sprite origin (pad, pad+60) maps to the platform centre
			const s = 1 + Math.sin(p.age / 0.25 * Math.PI) * 0.12;
			ctx.translate(p.x, p.y);
			ctx.scale(s, s);
			ctx.drawImage(spr, -spr._pad, -spr._pad - 60);
		} else {
			ctx.drawImage(spr, p.x - spr._pad, p.y - spr._pad - 60);
		}
		// spring coil is drawn live — a cached sprite can't animate the squish
		if (p.type === this.SPRING) this._drawSpringCoil(ctx, p);
		ctx.restore();
	},

	_drawSpringCoil(ctx, p) {
		const h = this.HEIGHT;
		const squish = 1 + 0.85 * p.springAnim;
		const baseY = p.y - h / 2;
		const coilH = 15 / squish;
		ctx.strokeStyle = '#8a93a8';
		ctx.lineWidth = 4;
		ctx.lineCap = 'round';
		for (let i = 0; i < 3; i++) {
			const yy = baseY - 5 - i * coilH / 3;
			ctx.beginPath();
			ctx.moveTo(p.x - 14, yy);
			ctx.lineTo(p.x + 14, yy - coilH / 3);
			ctx.stroke();
		}
		ctx.fillStyle = '#ff6f61';
		ctx.strokeStyle = NAVY;
		ctx.lineWidth = 3;
		ctx.beginPath();
		ctx.roundRect(p.x - 22, baseY - 6 - coilH - 8, 44, 9, 6);
		ctx.fill();
		ctx.stroke();
	},

	_paint(g, p, w, h, skin) {
		const col = skin.body, lip = skin.lip;

		// baked soft drop shadow — zero per-frame cost, adds depth
		g.fillStyle = 'rgba(35,42,69,0.22)';
		g.beginPath();
		g.roundRect(-w / 2 + 3, -h / 2 + 7, w, h, 9);
		g.fill();

		g.fillStyle = col;
		g.strokeStyle = NAVY;
		g.lineWidth = 4.5;
		g.beginPath();
		g.roundRect(-w / 2, -h / 2, w, h, 9);
		g.fill();
		g.stroke();

		g.fillStyle = lip;
		g.beginPath();
		g.roundRect(-w / 2 + 4, -h / 2 + 3.5, w - 8, 7, 5);
		g.fill();

		// zone decoration — baked, so still zero per-frame cost
		this._paintDeco(g, w, h, skin.deco);

		if (p.type === this.MOVING) {
			g.strokeStyle = 'rgba(255,255,255,0.85)';
			g.lineWidth = 2.5;
			for (const sgn of [-1, 1]) {
				const cx = sgn * w * 0.28;
				g.beginPath();
				g.moveTo(cx - 6 * sgn, 3);
				g.lineTo(cx, -3);
				g.lineTo(cx + 6 * sgn, 3);
				g.stroke();
			}
		}
		if (p.type === this.BREAKABLE) {
			g.strokeStyle = NAVY;
			g.lineWidth = 2.5;
			g.beginPath();
			g.moveTo(-w * 0.18, -h / 2 + 3); g.lineTo(-w * 0.05, h / 2 - 3);
			g.moveTo(w * 0.28, -h / 2 + 3);  g.lineTo(w * 0.38, 2);
			g.moveTo(-w * 0.38, 2);          g.lineTo(-w * 0.30, h / 2 - 4);
			g.stroke();
		}
		if (p.type === this.VANISH) {
			g.fillStyle = 'rgba(35,42,69,0.5)';
			g.font = '800 13px "Baloo 2", sans-serif';
			g.textAlign = 'center';
			g.fillText('~ ~ ~', 0, 6);
		}
		if (p.spike) {			// spikes cover the MIDDLE only — outer edges stay landable, and the
			// span matches Platform.spikeHalfSpan() exactly
			const span = Math.min(w * CFG.SPIKE_SPAN, Math.max(0, w - CFG.SPIKE_MIN_EDGE * 2));
			const n = Math.max(2, Math.floor(span / 26));
			for (let i = 0; i < n; i++) {
				const sx = -span / 2 + (i + 0.5) * (span / n);
				g.fillStyle = '#dfe5f0';
				g.strokeStyle = NAVY;
				g.lineWidth = 3;
				g.beginPath();
				g.moveTo(sx - 11, -h / 2 - 2);
				g.lineTo(sx, -h / 2 - 26);
				g.lineTo(sx + 11, -h / 2 - 2);
				g.closePath();
				g.fill();
				g.stroke();
				g.fillStyle = '#e05548';
				g.beginPath();
				g.moveTo(sx - 5, -h / 2 - 13);
				g.lineTo(sx, -h / 2 - 26);
				g.lineTo(sx + 5, -h / 2 - 13);
				g.closePath();
				g.fill();
			}
		}
	},

	/* baked zone decoration: tufts, rivets, cracks, snow speckle …
	   Deterministic in the width so the same sprite always looks the same. */
	_paintDeco(g, w, h, deco) {
		if (!deco || deco === 'none') return;
		const n = Math.max(2, Math.floor(w / 46));
		const step = w / n;
		if (deco === 'grass') {
			g.strokeStyle = '#3f9e68';
			g.lineWidth = 2.5;
			g.lineCap = 'round';
			for (let i = 0; i < n; i++) {
				const x = -w / 2 + step * (i + 0.5) + (i % 2 ? 4 : -4);
				g.beginPath();
				g.moveTo(x, -h / 2 + 1);
				g.quadraticCurveTo(x + 2, -h / 2 - 6, x + (i % 2 ? 5 : -5), -h / 2 - 9);
				g.stroke();
			}
		} else if (deco === 'cloud') {
			g.fillStyle = 'rgba(255,255,255,0.85)';
			for (let i = 0; i < n; i++) {
				g.beginPath();
				g.arc(-w / 2 + step * (i + 0.5), h / 2 - 2, 5, 0, Math.PI * 2);
				g.fill();
			}
		} else if (deco === 'honey') {
			g.fillStyle = 'rgba(255,243,194,0.9)';
			for (let i = 0; i < n; i++) {
				const x = -w / 2 + step * (i + 0.5);
				g.beginPath();
				g.arc(x, h / 2 + 2, 3.4, 0, Math.PI);   // drip
				g.fill();
			}
		} else if (deco === 'ice') {
			g.strokeStyle = 'rgba(255,255,255,0.75)';
			g.lineWidth = 2;
			for (let i = 0; i < n; i++) {
				const x = -w / 2 + step * (i + 0.5);
				g.beginPath();
				g.moveTo(x - 7, h / 2 - 6);
				g.lineTo(x + 7, h / 2 - 10);
				g.moveTo(x - 7, h / 2 - 10);
				g.lineTo(x + 7, h / 2 - 6);
				g.stroke();
			}
		} else if (deco === 'stars') {
			g.fillStyle = 'rgba(255,255,255,0.8)';
			for (let i = 0; i < n; i++) {
				const x = -w / 2 + step * (i + 0.5);
				const y = i % 2 ? 5 : -5;
				g.fillRect(x - 1, y - 3, 2, 6);
				g.fillRect(x - 3, y - 1, 6, 2);
			}
		}
	},
};

/* ============================================================== ENEMY */
const Enemy = {
	create(kind, x, y, opts) {
		opts = opts || {};
		return {
			kind,                                  // 'grump' | 'bat'
			x, y,
			originX: x, originY: y,
			range: opts.range || 170,
			speed: opts.speed || 120,
			dir: _simRng() > 0.5 ? 1 : -1,
			look: 0,                               // smoothed pupil offset
			t: _simRng() * Math.PI * 2,
			r: kind === 'bat' ? 28 : 26,
			dead: false,
			deadT: 0,
			// trash talk
			tauntT: 4 + Math.random() * 9,
		tauntShow: 0,
		taunt: '',
	};
	},

	update(e, dt) {
		e.t += dt;
		if (e.dead) { e.deadT += dt; return; }

		if (e.kind === 'grump') {
			e.x += e.dir * e.speed * dt;
			e.y = e.originY + Math.sin(e.t * 3.2) * 14;
			if (e.x > e.originX + e.range) { e.x = e.originX + e.range; e.dir = -1; }
			else if (e.x < e.originX - e.range) { e.x = e.originX - e.range; e.dir = 1; }
		} else {
			// bat — lazy figure-8
			e.x = e.originX + Math.sin(e.t * 1.1) * e.range;
			e.y = e.originY + Math.sin(e.t * 2.6) * 70;
			e.dir = Math.cos(e.t * 1.1) >= 0 ? 1 : -1;
		}

		// keep enemies inside the playfield so they never patrol off-screen
		const lo = 60, hi = CFG.VIEW_W - 60;
		if (e.x < lo) { e.x = lo; if (e.kind === 'grump') e.dir = 1; }
		else if (e.x > hi) { e.x = hi; if (e.kind === 'grump') e.dir = -1; }

		// smooth the pupil so it doesn't flip on a single frame
		e.look += (e.dir - e.look) * Math.min(1, dt * 8);

		// trash talk — every 8-16s a grump says something rude for ~2.5s
		if (e.tauntShow > 0) {
			e.tauntShow -= dt;
		} else {
			e.tauntT -= dt;
			if (e.tauntT <= 0) {
				e.tauntT = 8 + Math.random() * 8;
				e.tauntShow = 2.5;
				e.taunt = CFG.TAUNTS[(Math.random() * CFG.TAUNTS.length) | 0];
			}
		}
	},

	draw(ctx, e) {
		if (e.dead) return;
		const body = e.kind === 'bat' ? '#7a6bb5' : '#a882dd';
		const belly = e.kind === 'bat' ? '#a396d2' : '#c4a6ec';
		const flap = Math.sin(e.t * 14) * 12;
		ctx.save();
		ctx.translate(e.x, e.y);

		ctx.fillStyle = '#fff3e0';
		ctx.strokeStyle = NAVY;
		ctx.lineWidth = 3;
		for (const sgn of [-1, 1]) {
			ctx.beginPath();
			ctx.moveTo(sgn * 16, -6);
			ctx.lineTo(sgn * 42, -16 - flap);
			ctx.lineTo(sgn * 18, 8);
			ctx.closePath();
			ctx.fill();
			ctx.stroke();
		}

		ctx.fillStyle = body;
		ctx.lineWidth = 4.5;
		ctx.beginPath();
		ctx.arc(0, 0, e.r, 0, Math.PI * 2);
		ctx.fill();
		ctx.stroke();
		ctx.fillStyle = belly;
		ctx.beginPath();
		ctx.arc(0, 7, e.r * 0.5, 0, Math.PI * 2);
		ctx.fill();

		if (e.kind === 'bat') {
			ctx.fillStyle = body;
			for (const sgn of [-1, 1]) {
				ctx.beginPath();
				ctx.moveTo(sgn * 8, -e.r + 2);
				ctx.lineTo(sgn * 15, -e.r - 14);
				ctx.lineTo(sgn * 19, -e.r + 6);
				ctx.closePath();
				ctx.fill();
				ctx.stroke();
			}
			ctx.fillStyle = '#ffffff';
			ctx.beginPath();
			ctx.moveTo(-6, 16); ctx.lineTo(-3, 23); ctx.lineTo(0, 16);
			ctx.moveTo(6, 16); ctx.lineTo(3, 23); ctx.lineTo(0, 16);
			ctx.fill();
		}

		for (const side of [-1, 1]) {
			const ex = side * 9.5, ey = -6;
			ctx.fillStyle = '#ffffff';
			ctx.beginPath();
			ctx.arc(ex, ey, 6.8, 0, Math.PI * 2);
			ctx.fill();
			ctx.lineWidth = 3;
			ctx.stroke();
			ctx.fillStyle = NAVY;
			ctx.beginPath();
			ctx.arc(ex + e.look * 2.2, ey + 1.2, 3.3, 0, Math.PI * 2);
			ctx.fill();
			ctx.lineWidth = 3.5;
			ctx.beginPath();
			ctx.moveTo(side * 15.5, -17);
			ctx.lineTo(side * 3.5, -11.5);
			ctx.stroke();
		}

		ctx.lineWidth = 3.5;
		ctx.beginPath();
		ctx.arc(0, 19, 7, Math.PI + 0.45, Math.PI * 2 - 0.45);
		ctx.stroke();

		// speech bubble with the taunt
		if (e.tauntShow > 0 && e.taunt) {
			const a = Math.min(1, e.tauntShow / 0.3); // fade at the tail
			ctx.globalAlpha = a;
			ctx.font = '800 15px "Baloo 2", "Comic Sans MS", sans-serif';
			const tw = ctx.measureText(e.taunt).width;
			const bw = tw + 20, bh = 26;
			const bx = -bw / 2, by = -e.r - bh - 16;
			ctx.fillStyle = '#fff9ee';
			ctx.strokeStyle = NAVY;
			ctx.lineWidth = 3;
			ctx.beginPath();
			ctx.roundRect(bx, by, bw, bh, 9);
			ctx.fill();
			ctx.stroke();
			// tail pointing at the grump
			ctx.beginPath();
			ctx.moveTo(-5, by + bh - 1);
			ctx.lineTo(0, by + bh + 8);
			ctx.lineTo(6, by + bh - 1);
			ctx.closePath();
			ctx.fill();
			ctx.fillStyle = NAVY;
			ctx.textAlign = 'center';
			ctx.textBaseline = 'middle';
			ctx.fillText(e.taunt, 0, by + bh / 2 + 1);
			ctx.globalAlpha = 1;
			ctx.textBaseline = 'alphabetic';
		}

		ctx.restore();
	},
};

/* ================================================================ COIN */
const Coin = {
	R: 17,
	create(x, y) {
		return { x, y, homeX: x, homeY: y, t: Math.random() * Math.PI * 2, taken: false };
	},
	update(c, dt) { c.t += dt; },
	draw(ctx, c) {
		/* The spin squash used to reach ~0, which drew the coin as a 1px
		   vertical sliver — it read as a glitch, not as a coin. Floor it at
		   34% so the coin always stays legible while still spinning. */
		const squash = 0.34 + 0.66 * Math.abs(Math.cos(c.t * 3));
		// soft glow so coins read as "pick me up" at a glance
		ctx.save();
		ctx.globalAlpha = 0.22 + 0.1 * Math.sin(c.t * 4);
		ctx.fillStyle = '#ffe9a8';
		ctx.beginPath();
		ctx.arc(c.x, c.y + Math.sin(c.t * 2.5) * 5, this.R + 10, 0, Math.PI * 2);
		ctx.fill();
		ctx.restore();
		ctx.save();
		ctx.translate(c.x, c.y + Math.sin(c.t * 2.5) * 5);
		ctx.scale(squash, 1);
		drawCoinIcon(ctx, this.R);
		ctx.restore();
	},
};

/* ============================================================= POWERUP */

/* Vector power-up icons, drawn centred at the origin inside a radius of ~20.
   These replace the emoji the old build used (🫧 / 🧲 / 🫘 / 🚀): three of
   those four are Emoji 11-14 codepoints that render as tofu boxes on the
   Android 7-9 devices this app supports. */
function drawPowerupIcon(ctx, kind) {
	ctx.save();
	ctx.lineJoin = 'round';
	ctx.lineCap = 'round';
	ctx.strokeStyle = NAVY;

	if (kind === 'BUBBLE') {
		ctx.fillStyle = 'rgba(255,255,255,0.92)';
		ctx.lineWidth = 3;
		ctx.beginPath();
		ctx.arc(-2, -1, 12, 0, Math.PI * 2);
		ctx.fill();
		ctx.stroke();
		ctx.beginPath();
		ctx.arc(9, 8, 6, 0, Math.PI * 2);
		ctx.fill();
		ctx.stroke();
		ctx.fillStyle = '#8ec4f2';
		ctx.beginPath();
		ctx.arc(-6, -5, 4, 0, Math.PI * 2);
		ctx.fill();
	} else if (kind === 'MAGNET') {
		// horseshoe magnet: red arc with two grey poles
		ctx.lineWidth = 8;
		ctx.strokeStyle = '#e05548';
		ctx.beginPath();
		ctx.arc(0, 2, 11, Math.PI, 0);
		ctx.stroke();
		ctx.strokeStyle = NAVY;
		ctx.lineWidth = 2.5;
		ctx.beginPath();
		ctx.arc(0, 2, 15, Math.PI, 0);
		ctx.arc(0, 2, 7, 0, Math.PI, true);
		ctx.stroke();
		ctx.fillStyle = '#dfe5f0';
		for (const sgn of [-1, 1]) {
			ctx.beginPath();
			ctx.rect(sgn * 11 - 4, 2, 8, 8);
			ctx.fill();
			ctx.stroke();
		}
	} else if (kind === 'BEANS') {
		// three kidney beans
		ctx.lineWidth = 2.5;
		const bean = (bx, by, rot) => {
			ctx.save();
			ctx.translate(bx, by);
			ctx.rotate(rot);
			ctx.fillStyle = '#8a5a2b';
			ctx.beginPath();
			ctx.ellipse(0, 0, 8, 5.5, 0, 0, Math.PI * 2);
			ctx.fill();
			ctx.stroke();
			ctx.fillStyle = '#c9975c';
			ctx.beginPath();
			ctx.ellipse(-2, -1, 3, 1.8, -0.4, 0, Math.PI * 2);
			ctx.fill();
			ctx.restore();
		};
		bean(-7, -6, -0.5);
		bean(7, -2, 0.4);
		bean(-1, 8, 0.15);
	} else if (kind === 'GIFT') {
		// mystery gift — a ribboned box with a question mark
		ctx.lineWidth = 2.5;
		ctx.fillStyle = '#ff6f61';
		ctx.beginPath();
		ctx.roundRect(-12, -6, 24, 17, 3);
		ctx.fill();
		ctx.stroke();
		ctx.fillStyle = '#ffd166';               // lid band
		ctx.fillRect(-12, -3, 24, 5);
		ctx.strokeRect(-12, -3, 24, 5);
		ctx.strokeStyle = '#ffd166';             // the bow
		ctx.lineWidth = 3;
		ctx.beginPath();
		ctx.arc(-5, -10, 4.5, 0, Math.PI * 2);
		ctx.arc(5, -10, 4.5, 0, Math.PI * 2);
		ctx.stroke();
		ctx.strokeStyle = NAVY;                  // "?" on the box
		ctx.lineWidth = 2.5;
		ctx.font = '800 13px "Baloo 2", sans-serif';
		ctx.fillStyle = NAVY;
		ctx.textAlign = 'center';
		ctx.textBaseline = 'middle';
		ctx.fillText('?', 0, 6.5);
		ctx.textBaseline = 'alphabetic';
	} else if (kind === 'GOLDEN') {
		// the legendary golden poop — soft-serve swirl with sparkle
		ctx.lineWidth = 2.5;
		ctx.fillStyle = '#d4a017';
		ctx.beginPath();
		ctx.moveTo(0, -14);
		ctx.quadraticCurveTo(12, -10, 6, -4);
		ctx.quadraticCurveTo(14, 0, 5, 4);
		ctx.quadraticCurveTo(12, 9, 0, 12);
		ctx.quadraticCurveTo(-12, 9, -5, 4);
		ctx.quadraticCurveTo(-14, 0, -6, -4);
		ctx.quadraticCurveTo(-12, -10, 0, -14);
		ctx.closePath();
		ctx.fill();
		ctx.stroke();
		ctx.fillStyle = '#fff3c2';
		ctx.beginPath();
		ctx.arc(-3, -6, 3.4, 0, Math.PI * 2);
		ctx.fill();
		// sparkle
		ctx.strokeStyle = '#fff3c2';
		ctx.lineWidth = 2;
		ctx.beginPath();
		ctx.moveTo(10, -12); ctx.lineTo(15, -12);
		ctx.moveTo(12.5, -14.5); ctx.lineTo(12.5, -9.5);
		ctx.stroke();
	} else {
		// rocket
		ctx.lineWidth = 2.5;
		ctx.fillStyle = '#fff9ee';
		ctx.beginPath();
		ctx.moveTo(0, -16);
		ctx.quadraticCurveTo(8, -6, 8, 6);
		ctx.lineTo(-8, 6);
		ctx.quadraticCurveTo(-8, -6, 0, -16);
		ctx.closePath();
		ctx.fill();
		ctx.stroke();
		ctx.fillStyle = '#e05548';
		for (const sgn of [-1, 1]) {
			ctx.beginPath();
			ctx.moveTo(sgn * 8, -1);
			ctx.lineTo(sgn * 15, 9);
			ctx.lineTo(sgn * 8, 8);
			ctx.closePath();
			ctx.fill();
			ctx.stroke();
		}
		ctx.fillStyle = '#5aa9e6';
		ctx.beginPath();
		ctx.arc(0, -5, 3.6, 0, Math.PI * 2);
		ctx.fill();
		ctx.stroke();
		ctx.fillStyle = '#ffd166';
		ctx.beginPath();
		ctx.moveTo(-5, 7);
		ctx.lineTo(0, 17);
		ctx.lineTo(5, 7);
		ctx.closePath();
		ctx.fill();
		ctx.stroke();
	}
	ctx.restore();
}

/* A coin, drawn centred at the origin with the given radius. Shared by the
   pickup and the floating "+N" labels. */
function drawCoinIcon(ctx, r) {
	ctx.fillStyle = '#ffd166';
	ctx.strokeStyle = NAVY;
	ctx.lineWidth = Math.max(2, r * 0.24);
	ctx.beginPath();
	ctx.arc(0, 0, r, 0, Math.PI * 2);
	ctx.fill();
	ctx.stroke();
	// inner rim
	ctx.strokeStyle = '#d69b28';
	ctx.lineWidth = Math.max(1.4, r * 0.13);
	ctx.beginPath();
	ctx.arc(0, 0, r * 0.6, 0, Math.PI * 2);
	ctx.stroke();
	// highlight
	ctx.fillStyle = 'rgba(255,255,255,0.8)';
	ctx.beginPath();
	ctx.arc(-r * 0.34, -r * 0.38, r * 0.2, 0, Math.PI * 2);
	ctx.fill();
}

const PowerUp = {
	R: 31,
	create(kind, x, y) {
		// golden crates pay double — decided at spawn so the draw can shine
		const golden = kind === 'GIFT' && Math.random() < 0.12;
		return { kind, x, y, t: Math.random() * Math.PI * 2, taken: false, golden };
	},
	update(p, dt) { p.t += dt; },
	draw(ctx, p) {
		const info = CFG.POWERUPS[p.kind];
		if (!info) return;
		ctx.save();
		ctx.translate(p.x, p.y + Math.sin(p.t * 2.2) * 8);
		if (p.kind === 'GIFT') {
			/* the mystery crate must NEVER look like a regular powerup
			   bubble — it's the run's jackpot, so it gets a box with a
			   ribbon, a warm pulsing halo and (1-in-8) a golden shimmer */
			const halo = 0.22 + 0.1 * Math.sin(p.t * 4);
			ctx.globalAlpha = halo;
			ctx.fillStyle = p.golden ? '#ffd166' : '#ff6f61';
			ctx.beginPath();
			ctx.arc(0, 0, 52, 0, Math.PI * 2);
			ctx.fill();
			ctx.globalAlpha = 1;
			ctx.lineWidth = 4.5;
			ctx.strokeStyle = NAVY;
			ctx.fillStyle = p.golden ? '#ffe08a' : '#ff6f61';
			ctx.beginPath();
			ctx.roundRect(-26, -22, 52, 44, 8);
			ctx.fill();
			ctx.stroke();
			ctx.fillStyle = p.golden ? '#fff9ee' : '#ffd166';
			ctx.fillRect(-6, -22, 12, 44);
			ctx.fillRect(-26, -4, 52, 10);
			ctx.strokeRect(-6, -22, 12, 44);
			ctx.strokeRect(-26, -4, 52, 10);
			// bow
			ctx.fillStyle = p.golden ? '#fff9ee' : '#ffd166';
			ctx.beginPath();
			ctx.arc(-9, -26, 8, 0, Math.PI * 2);
			ctx.arc(9, -26, 8, 0, Math.PI * 2);
			ctx.fill();
			ctx.stroke();
			// sparkle marks the golden crate
			if (p.golden) {
				ctx.fillStyle = '#fff9ee';
				for (let i = 0; i < 3; i++) {
					const a = p.t * 2 + i * 2.1;
					ctx.fillRect(Math.cos(a) * 34 - 2, Math.sin(a) * 30 - 2, 5, 5);
				}
			}
			ctx.restore();
			return;
		}
		ctx.globalAlpha = 0.3 + 0.15 * Math.sin(p.t * 5);
		ctx.fillStyle = info.color;
		ctx.beginPath();
		ctx.arc(0, 0, 44, 0, Math.PI * 2);
		ctx.fill();
		ctx.globalAlpha = 1;
		ctx.fillStyle = '#fff9ee';
		ctx.strokeStyle = NAVY;
		ctx.lineWidth = 4.5;
		ctx.beginPath();
		ctx.arc(0, 0, this.R, 0, Math.PI * 2);
		ctx.fill();
		ctx.stroke();
		ctx.fillStyle = info.color;
		ctx.beginPath();
		ctx.arc(0, 0, 24, 0, Math.PI * 2);
		ctx.fill();
		drawPowerupIcon(ctx, p.kind);
		ctx.restore();
	},
};

/* ============================================================== PLAYER */
class Player {
	constructor() {
		this.x = 0; this.y = 0;
		this.vx = 0; this.vy = 0;
		this.prevY = 0;
		this.r = CFG.PLAYER_R;
		this.squashX = 1; this.squashY = 1;
		this.facing = 1;
		this.t = 0;
		this.blinkSeed = Math.random() * 10;
		// buffs
		this.bubble = false;
		this.beans = 0;
		this.magnetT = 0;
		this.rocketT = 0;
		this.invulnT = 0;
		this.hurtFlash = 0;
		this.goldenT = 0;   // golden poop: 5x coins + reversed steering
		this.char = CharacterArt.byId('gary');
		this.hat = null;    // equipped HATS def (set by World.reset)
	}

	applyChar(ch) {
		this.char = ch || CharacterArt.byId('gary');
	}

	reset() {
		this.x = CFG.VIEW_W / 2;
		this.y = -140;
		this.vx = 0;
		this.vy = 0;
		this.prevY = this.y;
		this.squashX = 1; this.squashY = 1;
		this.facing = 1;
		this.beans = 0;
		this.magnetT = 0;
		this.rocketT = 0;
		this.invulnT = 0;
		this.hurtFlash = 0;
		this.goldenT = 0;
		this.bubble = this.char.perkCode === 'startBubble';
		if (this.char.perkCode === 'startBeans') this.beans = 1;
	}

	update(dt) {
		this.t += dt;
		this.prevY = this.y;

		if (this.rocketT > 0) {
			this.rocketT -= dt;
			this.vy = -2600;
			if (this.rocketT <= 0) {
				this.rocketT = 0;
				SFX.stopRocket();
				// hand back control with a normal bounce instead of a dead stop
				this.vy = CFG.BOUNCE * 0.5;
			}
		} else {
			this.vy = Math.min(this.vy + CFG.GRAVITY * dt, CFG.MAX_FALL);
		}

		if (this.magnetT > 0) this.magnetT = Math.max(0, this.magnetT - dt);
		if (this.invulnT > 0) this.invulnT = Math.max(0, this.invulnT - dt);
		if (this.hurtFlash > 0) this.hurtFlash = Math.max(0, this.hurtFlash - dt);
		if (this.goldenT > 0) this.goldenT = Math.max(0, this.goldenT - dt);

		// horizontal control — keyboard takes priority, then drag.
		// golden poop flips both: 5x coins is never free
		const rev = this.goldenT > 0 ? -1 : 1;
		const axis = Input.axis() * rev;
		if (Math.abs(axis) > 0.01) {
			this.vx = this._moveToward(this.vx, axis * CFG.KEY_SPEED, CFG.KEY_ACCEL * dt);
			Input.consumeDrag();   // don't let drag queue up behind key input
		} else {
			const drag = Input.consumeDrag() * rev;
			if (Math.abs(drag) > 0.5) {
				// clamp a single frame's drag so a jerky/laggy touch stream
				// can't teleport the player across the screen
				const maxStep = CFG.VIEW_W * 0.5;
				this.x += Math.max(-maxStep, Math.min(maxStep, drag * CFG.DRAG_SENS));
				this.vx *= 0.82;
			} else {
				this.vx = this._moveToward(this.vx, 0, 3000 * dt);
			}
		}
		if (Math.abs(this.vx) > 30) this.facing = Math.sign(this.vx);

		this.y += this.vy * dt;
		this.x += this.vx * dt;

		// screen wrap
		if (this.x > CFG.VIEW_W + CFG.WRAP) this.x = -CFG.WRAP;
		else if (this.x < -CFG.WRAP) this.x = CFG.VIEW_W + CFG.WRAP;

		// squash decay toward 1
		this.squashX += (1 - this.squashX) * Math.min(1, dt * 9);
		this.squashY += (1 - this.squashY) * Math.min(1, dt * 9);
	}

	_moveToward(v, target, maxDelta) {
		if (Math.abs(target - v) <= maxDelta) return target;
		return v + Math.sign(target - v) * maxDelta;
	}

	bounce(vel, squash) {
		this.vy = vel;
		this.squashX = squash ? squash[0] : 0.72;
		this.squashY = squash ? squash[1] : 1.28;
	}

	/* Getting hit does not end the run — knockback, lost combo, and a
	   blinking invulnerability window.
	   Returns 0 = nothing (invuln/rocket), 1 = hurt, 2 = bubble absorbed. */
	hurt(extraKnock = 0) {
		if (this.invulnT > 0 || this.rocketT > 0) return 0;
		if (this.bubble) {
			this.bubble = false;
			this.invulnT = 1.2;
			this.bounce(-900, [1.25, 0.8]);
			SFX.play('powerup', 0.06, 0.7);
			return 2;
		}
		// extraKnock = hit-heat stacks from World (chained hits hit lower)
		this.vy = Math.max(this.vy, CFG.HURT_KNOCK_VY + extraKnock);
		this.vx *= 0.3;
		// the 'tough' perk stretches the recovery window
		this.invulnT = CFG.HURT_INVULN + (this.char.perkCode === 'tough' ? 0.6 : 0);
		this.hurtFlash = this.invulnT;
		this.squashX = 1.3;
		this.squashY = 0.72;
		SFX.play('hurt', 0.08, 1.0);
		SFX.haptic(90);
		return 1;
	}

	draw(ctx) {
		ctx.save();
		ctx.translate(this.x, this.y);
		if (this.invulnT > 0 && Math.floor(this.invulnT * 12) % 2 === 0) ctx.globalAlpha = 0.45;
		ctx.scale(this.squashX, this.squashY);

		if (this.rocketT > 0) {
			ctx.fillStyle = '#e8e3d5';
			ctx.strokeStyle = NAVY;
			ctx.lineWidth = 4;
			ctx.beginPath();
			ctx.roundRect(-22, 14, 44, 34, 10);
			ctx.fill();
			ctx.stroke();
			const fl = 18 + Math.sin(this.t * 40) * 8;
			ctx.fillStyle = '#ffd166';
			ctx.beginPath();
			ctx.moveTo(-14, 48);
			ctx.lineTo(0, 48 + fl);
			ctx.lineTo(14, 48);
			ctx.closePath();
			ctx.fill();
		}

		drawCharacter(ctx, this.char, {
			t: this.t, vy: this.vy, vx: this.vx,
			hurt: this.hurtFlash > 0,
			rocket: this.rocketT > 0,
			blinkSeed: this.blinkSeed,
		});

		if (this.hurtFlash > 0) {
			ctx.fillStyle = '#ffd166';
			ctx.strokeStyle = NAVY;
			ctx.lineWidth = 2;
			for (let i = 0; i < 3; i++) {
				const a = this.t * 6 + (i * Math.PI * 2) / 3;
				const sx = Math.cos(a) * 46, sy = -44 + Math.sin(a) * 9;
				ctx.beginPath();
				for (let k = 0; k < 5; k++) {
					const ang = -Math.PI / 2 + (k * Math.PI * 2) / 5;
					const rr = k % 2 === 0 ? 7 : 3;
					ctx.lineTo(sx + Math.cos(ang) * rr, sy + Math.sin(ang) * rr);
				}
				ctx.closePath();
				ctx.fill();
				ctx.stroke();
			}
		}

		if (this.bubble) {
			ctx.strokeStyle = 'rgba(142,196,242,0.95)';
			ctx.lineWidth = 4;
			ctx.fillStyle = 'rgba(174,216,248,0.22)';
			ctx.beginPath();
			ctx.arc(0, -2, 58 + Math.sin(this.t * 3) * 3, 0, Math.PI * 2);
			ctx.fill();
			ctx.stroke();
			ctx.fillStyle = 'rgba(255,255,255,0.65)';
			ctx.beginPath();
			ctx.arc(-20, -24, 7, 0, Math.PI * 2);
			ctx.fill();
		}
		ctx.restore();

		// hat rides OUTSIDE the squash so it never looks squashed with the body
		if (this.hat) {
			ctx.save();
			ctx.translate(this.x, this.y);
			if (this.invulnT > 0 && Math.floor(this.invulnT * 12) % 2 === 0) ctx.globalAlpha = 0.45;
			drawHat(ctx, this.hat, 0, -36, 22);
			ctx.restore();
		}
	}
}

if (typeof module !== 'undefined' && module.exports) {
	module.exports = {
		Platform, Enemy, Coin, PowerUp, Player,
		drawPowerupIcon, drawCoinIcon,
	};
}
