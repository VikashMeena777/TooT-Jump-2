'use strict';
/* ============================================================
   World — generation, difficulty, collisions, camera, zones, combo.

   Design rules (now ENFORCED, not just documented):
   - Every row is reachable from the row below it. Both the vertical
     gap and the horizontal offset are bounded by what the physics
     actually allows (see CFG._deriveLimits). The previous build only
     checked the gap against the jump apex and let the horizontal
     offset be up to 468px — more than double the reachable distance
     at a 280px gap — which produced genuinely impossible rows.
   - Spikes/enemies never spawn early; spikes only cover the middle of
     a platform and always leave CFG.SPIKE_MIN_EDGE px landable on
     each side; the hitbox matches the painted span exactly.
   - Getting hit = knockback + invulnerability, NOT death. You only
     die by falling off the bottom of the screen.
   - Landing resolves against the HIGHEST valid platform, so two
     overlapping platforms can no longer drop you through the top one.
   ============================================================ */

function hexLerp(a, b, t) {
	const pa = parseInt(a.slice(1), 16), pb = parseInt(b.slice(1), 16);
	const r = Math.round(((pa >> 16) & 255) + (((pb >> 16) & 255) - ((pa >> 16) & 255)) * t);
	const g = Math.round(((pa >> 8) & 255) + (((pb >> 8) & 255) - ((pa >> 8) & 255)) * t);
	const bl = Math.round((pa & 255) + ((pb & 255) - (pa & 255)) * t);
	return `rgb(${r},${g},${bl})`;
}

const World = {
	playing: false,
	autopilot: false,
	_frame: 0,

	// state
	player: null,
	platforms: [], enemies: [], coins: [], powerups: [],
	camY: 0,
	bestY: 0,
	highestRowY: 0,
	lastRowX: CFG.VIEW_W / 2,
	rowsSinceEnemy: 0, nextEnemyRows: 4,
	rowsSincePower: 0, nextPowerRows: 16,
	rowsSinceSafe: 0,
	graceRows: 0,
	rng: null,

	// run stats
	scoreBonus: 0,
	runCoins: 0,
	runStomps: 0,
	runSprings: 0,
	runPowerups: 0,
	combo: 0,
	comboTimer: 0,
	comboMax: 0,
	comboTier: -1,
	zoneIdx: -1,
	reachedZones: null,
	nextMilestone: 100,
	crossedBest: false,

	// backdrop
	clouds: [],
	stars: [],
	planets: [],
	menuT: 0,

	init() {
		this.player = new Player();
		this.rng = this._lcg(1337);
		this.reachedZones = new Set([0]);

		for (let i = 0; i < 5; i++) {
			this.clouds.push({ x: this.rng() * 720, y: this.rng() * 2000, s: 0.7 + i * 0.16, layer: 0.12 });
		}
		for (let i = 0; i < 4; i++) {
			this.clouds.push({ x: this.rng() * 720, y: this.rng() * 2000, s: 1.05 + i * 0.18, layer: 0.3 });
		}
		for (let i = 0; i < 140; i++) {
			this.stars.push({ x: this.rng() * 720, y: this.rng() * 4000, r: 1 + this.rng() * 2.2, tw: this.rng() * 6 });
		}
		/* Planets: the old build placed them at y = 2200*50 + ... ≈ +110000
		   (POSITIVE, i.e. 110000px BELOW the start) and then drew them at
		   `pl.y - camY * 0.4`. In space camY ≈ -110000, so the draw y came out
		   around +154000 — roughly 120 screens below the viewport. The planets
		   were mathematically guaranteed never to be visible.
		   They now live in a wrapped parallax band like the stars. */
		for (let i = 0; i < 6; i++) {
			this.planets.push({
				x: 80 + this.rng() * 560,
				y: this.rng() * 6000,
				r: 46 + this.rng() * 60,
				hue: this.rng() * 360,
				ring: this.rng() > 0.4,
			});
		}
	},

	_lcg(seed) {
		let s = seed | 0;
		const r = () => { s = (Math.imul(s, 1664525) + 1013904223) & 0x7fffffff; return s / 0x7fffffff; };
		r();
		return r;
	},

	/* day-key for the daily challenge — same format as Missions._today */
	_today() {
		const d = new Date();
		return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
	},

	/* Seed derived from the date so EVERY player gets the identical daily
	   level. Uses a string hash (djb2) of 'tj2-daily-YYYY-MM-DD'. */
	_dailySeed() {
		const key = 'tj2-daily-' + this._today();
		let h = 5381;
		for (let i = 0; i < key.length; i++) h = ((h << 5) + h + key.charCodeAt(i)) & 0x7fffffff;
		return h | 1;
	},

	/* ------------------------------------------------- invisible DDA
	   Quietest feature in the game: deaths within CFG.DDA_BAND m of each
	   other count as "stuck at the same wall"; after DDA_DEATHS of them the
	   generator eases gaps up to DD_EASE_MAX. A run DDA_RECOVER_M m past
	   the wall clears it. Never surfaced in the UI — that's the point. */
	_ddaRecordDeath() {
		const d = Storage.data;
		const m = this.meters();
		if (Math.abs(m - d.ddasY) <= CFG.DDA_BAND) d.ddas++;
		else { d.ddas = 1; d.ddasY = m; }
		if (d.ddas >= CFG.DDA_DEATHS) d.ddEase = Math.min(1, d.ddEase + 0.34);
		else d.ddEase = Math.max(0, d.ddEase - 0.15);
		Storage.saveSoon();
	},

	_ddaCheckRecover() {
		const d = Storage.data;
		if (d.ddEase <= 0) return;
		if (this.meters() > d.ddasY + CFG.DDA_RECOVER_M) {
			d.ddEase = Math.max(0, d.ddEase - 0.5);
			d.ddas = 0;
			Storage.saveSoon();
		}
	},

	/* character leveling — perk magnitude multiplier (1, 1.15, 1.3) */
	_charLevelMult() {
		const lv = Storage.data.charLevels[this.player.char.id] || 1;
		return 1 + (Math.min(3, lv) - 1) * 0.15;
	},

	/* golden poop coin multiplier also benefits from richRat-style leveling
	   via the same mult — applied where perks already apply */

	reset(charId) {
		this.platforms.length = 0;
		this.enemies.length = 0;
		this.coins.length = 0;
		this.powerups.length = 0;
		FX.clear();
		Platform.clearCache();

		/* Seed: the daily challenge uses the date-derived seed so every
		   player climbs the identical mountain; normal runs stay random. */
		this.dailyMode = !!this.dailyMode;
		this.rng = this._lcg(this.dailyMode
			? this._dailySeed()
			: (this.autopilot ? 1337 : ((Date.now() ^ 0x5f3759df) | 1)));

		this.player.applyChar(CharacterArt.byId(charId));
		this.player.reset();
		const hatId = Storage.data.hats.equipped;
		this.player.hat = (hatId && hatId !== 'none') ? HATS.byId(hatId) : null;

		this.camY = 0;
		this.bestY = 0;
		this.highestRowY = 100;
		this.lastRowX = CFG.VIEW_W / 2;
		this.rowsSinceEnemy = 0;
		this.nextEnemyRows = 3 + Math.floor(this.rng() * 3);
		this.rowsSincePower = 0;
		this.nextPowerRows = 12 + Math.floor(this.rng() * 8);
		this.rowsSinceSafe = 0;
		this.graceRows = 2;
		this.scoreBonus = 0;
		this.runCoins = 0;
		this.runStomps = 0;
		this.runSprings = 0;
		this.runPowerups = 0;
		this.runCloseCalls = 0;
		this.runHits = 0;
		this.runBeansUsed = 0;
		this.runGolden = false;
		this._lastHitClock = -99;      // hit-heat chain tracker
		this._hitHeat = 0;
		/* run rewards journal — everything the run PAID the player, shown on
		   the game-over screen so high-altitude earnings are never invisible */
		this.runLog = [];
		this._lastCloseCall = -9;
		this._clock = 0;
		this.combo = 0;
		this.comboTimer = 0;
		this.comboMax = 0;
		this.comboTier = -1;
		this.zoneIdx = 0;
		this.reachedZones = new Set([0]);
		this.nextMilestone = 100;
		this.rollDailyCups();          // cups refresh at midnight — re-earn daily
		this.nextGiftM = Storage.data.gift.nextM;
		this._giftSpawned = false;
		this.crossedBest = false;
		this._frame = 0;
		this._aiTarget = null;
		this.playing = true;

		if (typeof Quests !== 'undefined') Quests.resetRun();

		// wide starting platform directly under the player
		this.platforms.push(Platform.create(Platform.NORMAL, CFG.VIEW_W / 2, 40, 320));
		this.lastRowX = CFG.VIEW_W / 2;

		for (let i = 0; i < 14; i++) {
			this._spawnRow(this.highestRowY);
			this.highestRowY -= this._nextGap();
		}

		if (Storage.data.runs < 3) {
			FX.text(CFG.VIEW_W / 2, -420, 'DRAG TO STEER!', { color: '#fff9ee', size: 40, life: 2.2, vy: -26 });
		}
	},

	/* gentle early, steep late */
	difficulty() {
		const f = Math.max(0, Math.min(1, -this.bestY / CFG.DIFF_DIST));
		return f * f * (3 - 2 * f); // smoothstep
	},

	meters() { return Math.max(0, Math.floor(-this.bestY / 50)); },
	score() { return this.meters() + this.scoreBonus; },

	_nextGap() {
		const d = this.difficulty();
		const lo = CFG.GAP_MIN;
		let hi = CFG.GAP_MAX_EARLY + (CFG.GAP_MAX_LATE - CFG.GAP_MAX_EARLY) * d;
		/* invisible DDA: at full ease the hardest gaps shrink by up to 30%,
		   but never below the DD_GAP_MIN_FLOOR — the game never becomes
	   trivial, it just stops punching at exactly your weight. */
		const ease = (Storage.data.ddEase || 0) * CFG.DD_EASE_MAX;
		if (ease > 0) hi = Math.max(CFG.DD_GAP_MIN_FLOOR, hi - (hi - CFG.DD_GAP_MIN_FLOOR) * ease);
		return lo + this.rng() * Math.max(10, hi - lo);
	},

	/* Pick the x for the next row so it is genuinely reachable from the
	   previous row, honouring the derived horizontal budget. */
	_nextRowX(w, d) {
		let budget = CFG.MAX_DX_EARLY + (CFG.MAX_DX_LATE - CFG.MAX_DX_EARLY) * d;
		// DDA also gently narrows the sideways demand when it is helping
		const ease = (Storage.data.ddEase || 0) * CFG.DD_EASE_MAX;
		budget *= 1 - ease * 0.25;
		const minX = CFG.MARGIN_X + w / 2;
		const maxX = CFG.VIEW_W - CFG.MARGIN_X - w / 2;
		if (maxX <= minX) return CFG.VIEW_W / 2;
		const lo = Math.max(minX, this.lastRowX - budget);
		const hi = Math.min(maxX, this.lastRowX + budget);
		const x = lo + this.rng() * Math.max(1, hi - lo);
		this.lastRowX = x;
		return x;
	},

	_spawnRow(rowY) {
		const d = this.difficulty();
		const m = this.meters();

		// a couple of friendly rows at the start
		if (this.graceRows > 0) {
			this.graceRows--;
			const w = 190;
			const x = this._nextRowX(w, 0);
			this.platforms.push(Platform.create(Platform.NORMAL, x, rowY, w));
			this._maybeCoins(rowY, x, true);
			return;
		}

		// fairness: never more than MAX_HAZARD_ROWS hazard rows in a row
		const forceSafe = this.rowsSinceSafe >= CFG.MAX_HAZARD_ROWS;

		const w = 138 - 58 * d; // 138px early … 80px late
		const x = this._nextRowX(w, d);

		let type = Platform.NORMAL, opts = {};
		let spike = false;

		if (!forceSafe) {
			const r = this.rng();
			const springC = 0.05 + 0.025 * d;
			const movingC = springC + (d > 0.08 ? 0.08 + 0.16 * d : 0);
			const vanishC = movingC + (d > 0.3 ? 0.05 + 0.10 * d : 0);
			const breakC = vanishC + 0.16 + 0.16 * d;

			if (r < springC) {
				type = Platform.SPRING;
			} else if (r < movingC) {
				type = Platform.MOVING;
				/* Travel is clamped twice:
				   1) so the platform never crosses a screen edge, and
				   2) so it never wanders further from lastRowX than the
				      horizontal budget — otherwise a moving platform could
				      drift into an unreachable position while you fall. */
				const edgeRoom = Math.min(x - w / 2 - 8, CFG.VIEW_W - w / 2 - x - 8);
				const budget = CFG.MAX_DX_EARLY + (CFG.MAX_DX_LATE - CFG.MAX_DX_EARLY) * d;
				const room = Math.min(edgeRoom, budget * 0.55);
					opts = {
						moveRange: Math.max(16, Math.min(90 + this.rng() * 110, room)),
						moveSpeed: 1.4 + this.rng() * 1.1,
					};
			} else if (r < vanishC) {
				type = Platform.VANISH;
			} else if (r < breakC) {
				type = Platform.BREAKABLE;
			}

			// spikes: plain platforms only, after SPIKE_START_M, and only if
			// the platform is wide enough to keep landable edges
			const spikeOk = w > CFG.SPIKE_MIN_EDGE * 2 + 30;
			if (type === Platform.NORMAL && spikeOk && m > CFG.SPIKE_START_M &&
				this.rng() < 0.09 + 0.20 * d) {
				spike = true;
			}
		}

		if (type === Platform.NORMAL && !spike) this.rowsSinceSafe = 0;
		else this.rowsSinceSafe++;

		const main = Platform.create(type, x, rowY, w, Object.assign({ spike }, opts));
		this.platforms.push(main);

		/* SOFT-LOCK GUARD.
		   Breakable and ghost platforms are consumable: a breakable crumbles
		   after one bounce, a ghost blinks out for 0.8s at a time. Rows are
		   150-228px apart, so removing one row leaves a 300-456px hole — and
		   the jump apex is only 301px. In the previous build EVERY breakable
		   or ghost row could therefore strand the player under an unjumpable
		   gap with no way back up (measured: 100% of them).

		   The fix is structural rather than a tuning tweak: a consumable row
		   always gets a permanent companion platform on the same line, so no
		   row can ever disappear entirely. The risky platform stays as bait
		   (it is usually better positioned), the safe one guarantees the
		   ladder is never broken. */
		if (type === Platform.BREAKABLE || type === Platform.VANISH) {
			const cw = Math.max(84, w * 0.86);
			const half = cw / 2;
			const minX = CFG.MARGIN_X + half;
			const maxX = CFG.VIEW_W - CFG.MARGIN_X - half;
			if (maxX > minX) {
				// place it clear of the risky platform, on whichever side has room
				const clearance = w / 2 + half + 26;
				const leftX = x - clearance;
				const rightX = x + clearance;
				let cx;
				if (leftX >= minX && rightX <= maxX) {
					cx = this.rng() < 0.5 ? leftX : rightX;
				} else if (leftX >= minX) {
					cx = leftX;
				} else if (rightX <= maxX) {
					cx = rightX;
				} else {
					cx = Math.max(minX, Math.min(maxX, x));
				}
				this.platforms.push(Platform.create(Platform.NORMAL, cx, rowY, cw));
				// the guaranteed path runs through the safe platform
				this.lastRowX = cx;
				this.rowsSinceSafe = 0;
			}
		}

		this._maybeCoins(rowY, x, type !== Platform.BREAKABLE && !spike);

		// enemies
		this.rowsSinceEnemy++;
		if (m > CFG.ENEMY_START_M && this.rowsSinceEnemy >= this.nextEnemyRows) {
			this.rowsSinceEnemy = 0;
			this.nextEnemyRows = Math.max(2, Math.round((4 - 1.6 * d) + this.rng() * 2.5));
			const kind = (m > 600 && this.rng() < 0.55) ? 'bat' : 'grump';
			const range = 110 + this.rng() * 110;
			// keep the patrol inside the playfield
			const ex = Math.max(60 + range, Math.min(CFG.VIEW_W - 60 - range,
				150 + this.rng() * (CFG.VIEW_W - 300)));
			this.enemies.push(Enemy.create(kind, ex, rowY + 50 + this.rng() * 60, {
				speed: 100 + 110 * d,
				range,
			}));
		}

		// powerups
		this.rowsSincePower++;
		if (this.rowsSincePower >= this.nextPowerRows) {
			this.rowsSincePower = 0;
			this.nextPowerRows = 16 + Math.floor(this.rng() * 10);
			this.powerups.push(PowerUp.create(
				this._pickPowerup(),
				90 + this.rng() * (CFG.VIEW_W - 180),
				rowY - 40
			));
		}

		/* MYSTERY GIFT — one floating gift box on the ladder at each
		   GIFT_EVERY_M milestone. Variable reward, casino psychology used
		   gently. Spawned exactly once per milestone. */
		const rowM = Math.max(0, Math.floor(-rowY / 50));
		if (!this._giftSpawned && rowM >= this.nextGiftM) {
			this._giftSpawned = true;
			this.powerups.push(PowerUp.create('GIFT',
				120 + this.rng() * (CFG.VIEW_W - 240), rowY - 70));
			// anticipation: the crate is the run's jackpot, announce it
			FX.text(CFG.VIEW_W / 2, this.camY - CFG.VIEW_H / 2 + 130,
				'🎁 GIFT AHEAD!', { color: '#ff6f61', size: 40, life: 2.2, vy: -20 });
		}
	},

	_maybeCoins(rowY, x, allowed) {
		if (!allowed || this.rng() >= 0.3) return;
		const n = 3 + Math.floor(this.rng() * 4);
		for (let i = 0; i < n; i++) {
			this.coins.push(Coin.create(
				Math.max(50, Math.min(CFG.VIEW_W - 50, x + (i - (n - 1) / 2) * 46)),
				rowY - 55 - Math.sin(((i + 1) / (n + 1)) * Math.PI) * 55
			));
		}
	},

	_pickPowerup() {
		const P = CFG.POWERUPS;
		const keys = ['BUBBLE', 'MAGNET', 'BEANS', 'ROCKET'];
		let total = 0;
		for (const k of keys) total += P[k].w;
		let r = this.rng() * total;
		for (const k of keys) {
			if (r < P[k].w) return k;
			r -= P[k].w;
		}
		return 'BUBBLE';
	},

	/* --------------------------------------------------------- update */
	update(dt) {
		if (!this.playing) return;
		this._frame++;
		this._clock += dt;

		const p = this.player;
		if (this.autopilot) this._autoSteer(dt);
		p.update(dt);

		for (let i = 0; i < this.platforms.length; i++) Platform.update(this.platforms[i], dt);
		for (let i = 0; i < this.enemies.length; i++) Enemy.update(this.enemies[i], dt);
		for (let i = 0; i < this.coins.length; i++) Coin.update(this.coins[i], dt);
		for (let i = 0; i < this.powerups.length; i++) PowerUp.update(this.powerups[i], dt);

		this._collidePlatforms();
		this._collideEnemies();
		this._collidePickups(dt);

		if (this._frame % 2 === 0) this._emitTrail();

		// camera — only ever moves up
		const target = Math.min(this.camY, p.y);
		this.camY += (target - this.camY) * (1 - Math.pow(0.001, dt));

		// spawn / recycle
		const camTop = this.camY - CFG.VIEW_H / 2;
		let guard = 0;
		while (this.highestRowY > camTop - CFG.SPAWN_AHEAD && guard++ < 64) {
			this._spawnRow(this.highestRowY);
			this.highestRowY -= this._nextGap();
		}

		const killY = this.camY + CFG.VIEW_H / 2 + 320;
		// a mystery crate that scrolled away UNCOLLECTED must not be wasted:
		// reschedule the next one close by instead of stranding the whole
		// ladder for another GIFT_EVERY_M (this is the "the gift never
		// spawns again" bug players report as loot boxes not working)
		for (const pu of this.powerups) {
			if (pu.kind === 'GIFT' && !pu.taken && pu.y >= killY) {
				this._giftSpawned = false;
				this.nextGiftM = this.meters() + 150;
				Storage.data.gift.nextM = this.nextGiftM;
			}
		}
		this._prune(this.platforms, killY, 'dead');
		this._prune(this.enemies, killY, 'dead');
		this._prune(this.coins, killY, 'taken');
		this._prune(this.powerups, killY, 'taken');

		// score
		if (p.y < this.bestY) this.bestY = p.y;

		// combo decay
		if (this.combo > 0) {
			this.comboTimer -= dt;
			if (this.comboTimer <= 0) this._resetCombo();
		}

		this._checkMilestone();
		this._checkBestLine();
		this._checkZone();
		this._ddaCheckRecover();

		// death — only by falling off the bottom
		if (p.y > this.camY + CFG.KILL_BELOW) {
			this.playing = false;
			Game.gameOver();
		}
	},

	/* in-place filter — avoids allocating a new array every frame, which
	   used to churn the GC at ~60 arrays/second */
	_prune(arr, killY, flag) {
		let w = 0;
		for (let i = 0; i < arr.length; i++) {
			const o = arr[i];
			if (o[flag] || o.y >= killY) continue;
			arr[w++] = o;
		}
		arr.length = w;
	},

	_collidePlatforms() {
		const p = this.player;
		if (p.vy <= 0 || p.rocketT > 0) return;
		const prevBottom = p.prevY + p.r;
		const newBottom = p.y + p.r;

		/* Resolve against the HIGHEST candidate surface. The old code took the
		   first array match, so when a moving platform overlapped a static one
		   the player could snap to the lower surface and clip through the
		   upper one. Remember y grows downward: the highest surface is the
		   one with the SMALLEST top. */
		let best = null, bestTop = Infinity;
		for (let i = 0; i < this.platforms.length; i++) {
			const pl = this.platforms[i];
			if (!Platform.landCheck(pl, prevBottom, newBottom, p.x, p.r)) continue;
			const top = Platform.top(pl);
			if (top < bestTop) { bestTop = top; best = pl; }
		}
		if (!best) {
			this._checkCloseCalls(prevBottom, newBottom);
			return;
		}
		const pl = best;

		// spikes guard the MIDDLE only — land on the edges
		if (pl.spike && Math.abs(p.x - pl.x) < Platform.spikeHalfSpan(pl) + p.r * 0.3) {
			this._hitHazard();
			return;
		}

		p.y = Platform.top(pl) - p.r;
		// the autopilot must re-plan after every landing, otherwise it keeps
		// targeting the platform it is standing on and hovers in place
		this._aiTarget = null;
		// landing feedback: squash the platform, puff dust, count the bounce
		pl.squash = 1;
		FX.burst(p.x, Platform.top(pl) + 2, { n: 4, color: 'rgba(255,255,255,0.75)', speed: 60, up: 26, r: 4, life: 0.3, grav: 300 });
		if (typeof Quests !== 'undefined') Quests.notify('bounce', 1);

			if (pl.type === Platform.SPRING) {
				pl.springAnim = 1;
				const perk = p.char.perkCode === 'springy' ? 1.08 : 1;
				p.bounce(CFG.BOUNCE * 1.55 * perk * this._charLevelMult(), [0.6, 1.45]);
			SFX.play('spring', 0.1, 0.9);
			this.runSprings++;
			Missions.notify('spring', 1);
			if (typeof Quests !== 'undefined') Quests.notify('spring', 1);
			this._addScore(5 + this.comboTierSafe() * 5);
			this._addCombo();
			FX.burst(p.x, p.y + p.r, { n: 14, color: ['#ffd166', '#ffe29a'], speed: 260, up: 120, r: 7, life: 0.5 });
			return;
		}

		if (p.beans > 0) {
			// MEGA TOOT — every bounce while holding beans farts, force-played
			// so a lingering combo/spring meme can never swallow the toot
			p.beans--;
			this.runBeansUsed++;
			p.bounce(CFG.BOUNCE * 1.6, [0.6, 1.45]);
			SFX.play('jump', 0.15, 0.95, true);
			FX.text(p.x, p.y - 50, 'MEGA TOOT!', { color: '#c07a3a', size: 30 });
		} else {
			p.bounce(CFG.BOUNCE, [0.72, 1.28]);
		}

		if (pl.type === Platform.BREAKABLE) {
			Platform.crumble(pl);
			SFX.play('break', 0.15);
			FX.burst(pl.x, pl.y, { n: 12, color: ['#e8a268', '#b97a42'], speed: 200, up: 60, r: 8, life: 0.6, grav: 900 });
		}

		FX.burst(p.x, p.y + p.r, { n: 7, color: ['rgba(255,255,255,0.85)', '#b7d95a'], speed: 130, up: 35, r: 6, life: 0.4 });
	},

	/* Near-miss: while descending, did the player just barely skim past a
	   platform's edge (a few px past the landing band, or a few px below a
	   top they almost caught)? A quick "CLOSE ONE!" breath turns failure
	   into excitement. Cooldown so a long fall past a stack fires once. */
	_checkCloseCalls(prevBottom, newBottom) {
		const p = this.player;
		if (this._clock - this._lastCloseCall < CFG.CLOSE_CALL_COOLDOWN) return;
		for (let i = 0; i < this.platforms.length; i++) {
			const pl = this.platforms[i];
			if (pl.dead || pl.broken) continue;
			const top = Platform.top(pl);
			// crossed the platform's level this frame while falling
			if (prevBottom > top + 1 || newBottom < top - 6) continue;
			const dx = Math.abs(p.x - pl.x);
			const landX = Platform.spanWidth(pl) / 2 + p.r * 0.25;
			const missedBy = dx - landX;
			// horizontal near-miss: past the edge by a hair
			if (missedBy > 0 && missedBy < CFG.CLOSE_CALL_BAND) {
				this._closeCall(p.x, p.y);
				return;
			}
			// vertical near-miss: fell just past a platform we were above
			if (dx < landX && newBottom > top + 2 && newBottom < top + CFG.CLOSE_CALL_BAND) {
				this._closeCall(p.x, p.y);
				return;
			}
		}
	},

	_closeCall(x, y) {
		this._lastCloseCall = this._clock;
		this.runCloseCalls++;
			Storage.data.stats.closeCalls++;
			Storage.saveSoon();
			this._addScore(CFG.CLOSE_CALL_SCORE);
			FX.startSlowmo(0.18, 1.08);
			// near-miss chain: every 3rd dare pays a small coin bonus —
			// rewards the playstyle that already feels the best
			if (this.runCloseCalls % 3 === 0) {
				this._giveCoins(10, x, y - 80);
				FX.text(x, y - 120, `DARE x${this.runCloseCalls}! +10`, { color: '#ffd166', size: 26, life: 1.1, coin: true });
				this._logReward('😰', `near-miss dare x${this.runCloseCalls} +10`);
			} else {
				FX.text(x, y - 40, 'CLOSE ONE!', { color: '#ffd166', size: 30, life: 0.8 });
			}
			SFX.play('button', 0.12, 1.6);
		},

	_collideEnemies() {
		const p = this.player;
		for (let i = 0; i < this.enemies.length; i++) {
			const e = this.enemies[i];
			if (e.dead) continue;
			const dx = p.x - e.x, dy = p.y - e.y;
			const rr = p.r + e.r;
			if (dx * dx + dy * dy > rr * rr) continue;

			if (p.rocketT > 0) {
				this._killEnemy(e, true);
				continue;
			}
			if (p.vy > 80 && p.y < e.y - 10) {
				const perk = p.char.perkCode === 'stompy' ? 1.12 : 1;
				p.bounce(CFG.BOUNCE * 0.9 * perk * this._charLevelMult(), [0.65, 1.4]);
				SFX.play('boing', 0.1);
				this._killEnemy(e, false);
				this.runStomps++;
				Missions.notify('stomp', 1);
				if (typeof Quests !== 'undefined') Quests.notify('stomp', 1);
				this._addScore(25 + this.comboTierSafe() * 15);
				this._addCombo();
				FX.startKillcam();
				FX.kick(0.35);
				SFX.haptic(35);
				this._giveCoins(1 + Math.max(0, this.comboTier), e.x, e.y - 30);
			} else {
				this._hitHazard();
			}
			return;
		}
	},

	_killEnemy(e, rocket) {
		e.dead = true;
		FX.burst(e.x, e.y, {
			n: rocket ? 22 : 14,
			color: ['#a882dd', '#c4a6ec', '#fff3e0'],
			speed: 320, up: 140, r: 8, life: 0.6,
		});
	},

	_collidePickups(dt) {
		const p = this.player;
		const magnetR = p.rocketT > 0 ? 420 : (p.magnetT > 0 ? 280 : 0);
		const grabR = p.r + Coin.R;

		for (let i = 0; i < this.coins.length; i++) {
			const c = this.coins[i];
			if (c.taken) continue;
			const dx = p.x - c.x, dy = p.y - c.y;
			const dist = Math.sqrt(dx * dx + dy * dy);
			if (magnetR > 0 && dist < magnetR && dist > 1) {
				// converge instead of orbiting: pull scales up as it gets close
				const pull = Math.min(dist, (1 - dist / magnetR) * 1400 * dt + dist * 4 * dt);
				c.x += (dx / dist) * pull;
				c.y += (dy / dist) * pull;
			}
			if (dist < grabR) {
				c.taken = true;
				this._giveCoins(1, c.x, c.y);
				SFX.play('coin', 0.06, 0.45);
				FX.burst(c.x, c.y, { n: 5, color: ['#ffd166', '#ffe9a8'], speed: 130, up: 60, r: 5, life: 0.35 });
			}
		}

		const puR = p.r + PowerUp.R;
		for (let i = 0; i < this.powerups.length; i++) {
			const pu = this.powerups[i];
			if (pu.taken) continue;
			const dx = p.x - pu.x, dy = p.y - pu.y;
			if (dx * dx + dy * dy > puR * puR) continue;
			pu.taken = true;
			this._applyPowerup(pu.kind, pu);
		}
	},

	_applyPowerup(kind, pu) {
		const p = this.player;
		const info = CFG.POWERUPS[kind];
		if (!info) return;
		// the magnet gets its own clip: "money follows my brother" — the
		// lyric IS what's happening on screen
		SFX.play(kind === 'MAGNET' ? 'magnet' : 'powerup', kind === 'MAGNET' ? 0.05 : 0.08);
		this._addCombo();
		this._addScore(15);
		this.runPowerups++;
		Storage.data.stats.powerups++;
		Storage.saveSoon();
		FX.text(p.x, p.y - 60, info.name + '!', { color: info.color, size: 36 });
		FX.burst(p.x, p.y, { n: 16, color: [info.color, '#fff9ee'], speed: 300, up: 100, r: 7, life: 0.55 });

		if (kind === 'GIFT') {
			this._bankCrate(pu);
			return;
		}

		if (kind === 'BUBBLE') {
			p.bubble = true;
		} else if (kind === 'MAGNET') {
			// refresh rather than replace, so overlapping pickups feel additive
			const bonus = p.char.perkCode === 'longMagnet' ? 4 : 0;
			p.magnetT = Math.max(p.magnetT, 6.5 + bonus);
		} else if (kind === 'BEANS') {
			p.beans = Math.min(9, p.beans + 3);
			FX.text(p.x, p.y - 100, '3x MEGA TOOTS LOADED', { color: '#c07a3a', size: 24 });
		} else if (kind === 'ROCKET') {
			p.rocketT = Math.max(p.rocketT, 1.5);
			SFX.startRocket();
			FX.kick(0.5);
		} else if (kind === 'GOLDEN') {
			// the joke item: riches at the price of dignity
			p.goldenT = CFG.GOLDEN_TIME;
			this.runGolden = true;
			Storage.data.stats.golden++;
			FX.flash(0.3);
			FX.text(p.x, p.y - 105, '5X COINS...', { color: '#d4a017', size: 30 });
			FX.text(p.x, p.y - 65, 'CONTROLS REVERSED?! 💀', { color: '#ff6f61', size: 30 });
			SFX.play('combo', 0.05, 0.8);
		}
	},

	_hitHazard() {
		const p = this.player;
		// HIT HEAT — hits inside HURT_HEAT_WINDOW of each other escalate the
		// downward knock, so chains of sloppy plays snowball into danger
		// instead of granting free 1.6s lifelines
		if (this._clock - (this._lastHitClock || -99) <= CFG.HURT_HEAT_WINDOW) {
			this._hitHeat = Math.min(CFG.HURT_HEAT_MAX, (this._hitHeat || 0) + 1);
		} else {
			this._hitHeat = 0;
		}
		this._lastHitClock = this._clock;
		const extraKnock = (this._hitHeat || 0) * CFG.HURT_HEAT_KNOCK;

		const res = p.hurt(extraKnock);
		if (res === 0) return;
		if (res === 2) {
			FX.kick(0.5);
			FX.burst(p.x, p.y, { n: 20, color: ['#8ec4f2', '#ffffff'], speed: 340, r: 8, life: 0.5 });
			FX.text(p.x, p.y - 60, 'SAVED!', { color: '#8ec4f2', size: 34 });
			return;
		}
		FX.kick(0.9);
		FX.freeze(0.1);
		FX.text(p.x, p.y - 70, 'OUCH!', { color: '#ff6f61', size: 38 });
		if (this._hitHeat >= 2) {
			FX.text(p.x, p.y - 120, `RAGE x${this._hitHeat + 1}!`, { color: '#ff6f61', size: 30, life: 1.1 });
		}
		FX.burst(p.x, p.y, { n: 16, color: ['#ff6f61', '#ffd166'], speed: 300, r: 7, life: 0.5 });
		this.runHits++;
		Storage.data.stats.hits++;
		// 'comboKeep' perk: the hit hurts, but the streak survives
		if (p.char.perkCode !== 'comboKeep') this._resetCombo();
		// 'tough' perk levels add extra invulnerability seconds
		if (p.char.perkCode === 'tough') p.invulnT += 0.3 * ((this._charLevelMult() - 1) / 0.15);
	},

	_emitTrail() {
		const p = this.player;
		if (p.rocketT > 0) {
			FX.burst(p.x, p.y + 40, { n: 3, color: ['#ffd166', '#ff9a5c', '#ffffff'], speed: 90, up: -160, r: 9, life: 0.4, grav: -100 });
		} else if (p.beans > 0) {
			const hue = (this._frame * 24) % 360;
			FX.burst(p.x, p.y + 30, { n: 1, color: `hsl(${hue},80%,65%)`, speed: 40, up: -60, r: 8, life: 0.5, grav: -60 });
		} else if (p.vy < -400) {
			// trail in the character's own colour — every squad member toots differently
			FX.burst(p.x, p.y + 34, { n: 1, color: p.char.trail, speed: 30, up: -30, r: 7, life: 0.45, grav: -40 });
		}
	},

	/* ---------------------------------------------------------- combo */
	comboTierSafe() { return Math.max(0, this.comboTier); },

	_addCombo() {
		this.combo++;
		if (this.combo > this.comboMax) this.comboMax = this.combo;
		this.comboTimer = CFG.COMBO_TIME + (this.player.char.perkCode === 'longCombo' ? 1.5 : 0);

		const tier = Math.min(CFG.TIERS.length - 1, Math.floor(this.combo / CFG.COMBO_PER_TIER));
		if (tier > this.comboTier) {
			this.comboTier = tier;
			const p = this.player;
			FX.text(p.x, p.y - 90, CFG.TIERS[tier] + '!', { color: CFG.TIER_COLORS[tier], size: 44 });
			SFX.play('combo', 0.05 + tier * 0.07, 1);
			if (tier > Storage.data.bestTier) { Storage.data.bestTier = tier; Storage.saveSoon(); }
			Missions.notify('tier', tier);
			if (typeof Quests !== 'undefined') Quests.notify('tier', tier);
		}
		if (this.combo > Storage.data.stats.maxCombo) {
			Storage.data.stats.maxCombo = this.combo;
			Storage.saveSoon();
		}
	},

	_resetCombo() {
		if (this.combo === 0) return;
		this.combo = 0;
		this.comboTimer = 0;
		this.comboTier = -1;
	},

	/* a collected crate is BANKED, not opened: the player opens and claims
	   it themselves in the CRATE VAULT from the menu (or via a challenge
	   reward). Touch mid-run only adds it to the vault — that is the whole
	   point: crates never pop open on their own. */
	_bankCrate(pu) {
		const golden = !!(pu && pu.golden);
		const vault = Storage.data.crates;
		if (golden) vault.golden = Math.min(99, (vault.golden || 0) + 1);
		else vault.normal = Math.min(99, (vault.normal || 0) + 1);
		const p = this.player;
		FX.confetti(p.x, p.y);
		FX.flash(golden ? 0.4 : 0.22);
		SFX.play('powerup', 0.1, golden ? 1.35 : 1.15);
		FX.text(p.x, p.y - 80, golden ? '🌟 GOLDEN CRATE!' : '🎁 CRATE BANKED!',
			{ color: golden ? '#ffd166' : '#ff6f61', size: 34, life: 1.3 });
		UI.toast(golden ? '🌟 golden crate banked — open it in the VAULT!' : '🎁 crate banked — open it in the VAULT!');
		this._logReward('🎁', golden ? 'golden crate banked' : 'crate banked');
		// schedule the next one; persist so it survives app restarts
		this.nextGiftM = this.meters() + CFG.GIFT_EVERY_M;
		Storage.data.gift.nextM = this.nextGiftM;
		Storage.saveSoon();
	},

	/* claim one banked crate from the vault. Pure logic (no DOM) so the
	   test suite can verify the economy: rolls the reward table, pays the
	   coins, decrements the vault, and returns what was won. */
	vaultOpen(golden) {
		const vault = Storage.data.crates;
		const key = golden ? 'golden' : 'normal';
		if (!vault[key]) return null;
		vault[key]--;
		const table = CFG.VAULT_REWARDS[key];
		const pick = table[(Math.random() * table.length) | 0];
		Storage.data.coins += pick;
		Storage.data.stats.coins += pick;
		Storage.save();
		return { coins: pick };
	},

	/* --------------------------------------------------------- rewards */
	_addScore(n) { this.scoreBonus += n; },

	/* journal one earned thing for the game-over rewards recap */
	_logReward(icon, label) {
		if (!this.runLog) this.runLog = [];
		this.runLog.push({ icon, label });
	},

	_giveCoins(n, x, y) {
		const pc = this.player.char.perkCode;
		let mult = pc === 'richRat' ? 1.15 : (pc === 'coinBoost' ? 1.25 : 1);
		if (pc === 'richRat' || pc === 'coinBoost') mult *= this._charLevelMult();
		if (this.player.goldenT > 0) mult *= CFG.GOLDEN_COIN_MULT;
		const amt = Math.max(1, Math.round(n * mult));
		this.runCoins += amt;
		Storage.data.coins += amt;
		Storage.data.stats.coins += amt;
		Missions.notify('coin', amt);
		if (typeof Quests !== 'undefined') Quests.notify('coin', amt);
		Storage.saveSoon();
		if (x !== undefined) {
			FX.text(x, y, '+' + amt, { color: '#ffd166', size: 26, life: 0.8, coin: true });
		}
	},

	_checkMilestone() {
		const m = this.meters();
		if (m < this.nextMilestone) return;
		FX.text(CFG.VIEW_W / 2, this.camY - 380, this.nextMilestone + 'm!', { color: '#fff9ee', size: 46 });
		FX.burst(CFG.VIEW_W / 2, this.camY - 420, { n: 16, color: ['#ffd166', '#59cd90', '#ff6f61'], speed: 320, up: 120, r: 7, life: 0.8 });
		this._giveCoins(5);
		// skip forward if a rocket carried us past several milestones at once
		while (this.nextMilestone <= m) this.nextMilestone += 100;
		Missions.notify('reach', m);
		if (typeof Quests !== 'undefined') Quests.notify('reach', m);

		/* CUP LADDER — every CUP_STEP of BEST altitude earns a shelf trophy.
		   Checked on milestone crossing (cheap) + game over (authoritative). */
		this._checkCups();
	},

	/* CUP LADDER — DAILY. Cups refresh every calendar day so the player can
	   re-earn them (+ CUP_REWARD coins each) just by climbing again: a daily
	   coin engine that rewards playing, not a one-time payout. cupsBest is
	   today's highest climb, so a second run only earns cups for NEW tiers. */
	rollDailyCups() {
		const d = Storage.data;
		const today = this._today();
		if (d.cupsDate === today) return false;
		d.cupsDate = today;
		d.cups = [];
		d.cupsBest = 0;
		Storage.saveSoon();
		return true;
	},

	_checkCups() {
		const d = Storage.data;
		this.rollDailyCups();
		/* the CURRENT run's altitude counts — the trophy pops the moment you
		   pass the tier mid-run (quitting via the pause menu records it in
		   Game.toMenu). cupsBest keeps today's max so later runs today only
		   earn tiers they haven't re-reached yet. */
		const live = this.playing ? this.meters() : 0;
		if (live > d.cupsBest) d.cupsBest = live;
		const earned = Math.floor(Math.max(d.cupsBest, live) / CFG.CUP_STEP);
		if (earned <= d.cups.length) return;
		for (let i = d.cups.length + 1; i <= earned; i++) {
			const tierM = i * CFG.CUP_STEP;
			d.cups.push(tierM);
			// every cup pays its reward the moment it's earned
			this._giveCoins(CFG.CUP_REWARD);
			this._logReward('🏆', `${tierM} m cup`);
			UI.toast(`🏆 ${tierM}m CUP!  +${CFG.CUP_REWARD}`);
			if (this.playing) {
				FX.text(this.player.x, this.player.y - 100, '🏆 +' + CFG.CUP_REWARD,
					{ color: '#ffd166', size: 30, life: 1.2, coin: true });
			}
		}
		Storage.saveSoon();
	},

	_checkBestLine() {
		const best = Storage.data.best;
		if (best < 20) return;
		const lineY = -best * 50;
		if (!this.crossedBest && this.player.y < lineY) {
			this.crossedBest = true;
			UI.toast('PAST YOUR BEST — keep going! 🚀');
			// a proper moment: big text, confetti, a strong white blink and a
			// slow-mo beat so passing the line reads as an EVENT, not a line
			FX.text(CFG.VIEW_W / 2, this.player.y - 130, 'NEW BEST!', { color: '#ffd166', size: 58, life: 1.8 });
			FX.confetti(this.player.x, this.player.y);
			FX.flash(0.9);
			FX.freeze(0.28);
			FX.kick(0.4);
			SFX.play('powerup', 0.1, 0.9);
			this._addScore(25);
		}
	},

	_checkZone() {
		const m = this.meters();
		let idx = 0;
		for (let i = 0; i < CFG.ZONES.length; i++) {
			if (m >= CFG.ZONES[i].m) idx = i;
		}
		if (idx === this.zoneIdx) return;
		this.zoneIdx = idx;
		const z = CFG.ZONES[idx];
		UI.zoneBanner(z.name, idx);
		if (!this.reachedZones.has(idx)) {
			this.reachedZones.add(idx);
			this._addScore(CFG.ZONE_SCORE);
			this._giveCoins(CFG.ZONE_COINS);
			SFX.play('powerup', 0.2, 0.8);
		}
	},

	/* ---------------------------------------------------------- revive */
	revive() {
		const p = this.player;
		p.vy = CFG.BOUNCE;
		p.vx = 0;
		p.x = CFG.VIEW_W / 2;
		p.y = this.camY - 200;
		p.prevY = p.y;
		p.invulnT = 2.0;
		p.hurtFlash = 0;
		p.bubble = true;
		p.rocketT = 0;
		SFX.stopRocket();

		for (let i = 0; i < this.enemies.length; i++) {
			const e = this.enemies[i];
			if (Math.abs(e.y - p.y) < 700) e.dead = true;
		}

		// guarantee a safe landing spot below the respawn point
		const hasPlat = this.platforms.some(pl =>
			!pl.spike && !pl.broken && pl.type !== Platform.VANISH &&
			pl.y > p.y + 60 && pl.y < p.y + 420
		);
		if (!hasPlat) {
			this.platforms.push(Platform.create(Platform.NORMAL, CFG.VIEW_W / 2, p.y + 250, 300));
			this.lastRowX = CFG.VIEW_W / 2;
		}
		this.playing = true;
	},

	/* ----------------------------------------------------------- autopilot
	   Used by the ?smoke=1 self-test and the headless balance tools.

	   History of this function is a good record of the bugs it exposed:
	   - v1 scored candidates with `dy + dx * 1.4`, where dy was NEGATIVE for
	     platforms below the player, so it always preferred the platform it
	     had just left, hovered in place and "climbed" ~85 px/s.
	   - v2 planned properly but skipped spiked platforms entirely. Since a
	     spiked platform keeps landable edges, and the level can legitimately
	     route the only ladder through one, v2 would stall forever on rows a
	     human clears easily — making the level look broken when it wasn't.

	   It now plans like a person: work out when the current arc descends past
	   each candidate (landing is one-way), pick a concrete aim point on that
	   platform (the middle for a plain one, the safe edge for a spiked one),
	   check the sideways move fits in the time available, predict whether a
	   ghost platform will still be solid on arrival, and commit. */
	AI_SPEED: 700,

	/* will this platform accept a landing at time `t` from now? */
	_aiSolidAt(pl, t) {
		if (!pl || pl.dead || pl.broken) return false;
		if (pl.type !== Platform.VANISH) return true;
		// mirror Platform.update(): 1.35s solid, 0.8s ghost, 2.15s cycle
		const cyc = (pl.vanishT + t) % 2.15;
		return cyc < 1.25;   // small margin before the blink-out
	},

	/* seconds until the player's current arc descends to `y`, or -1 */
	_aiTimeToDescendTo(y) {
		const p = this.player;
		const G = CFG.GRAVITY;
		const tUp = p.vy < 0 ? -p.vy / G : 0;
		const apexY = p.y - (p.vy < 0 ? (p.vy * p.vy) / (2 * G) : 0);
		if (y < apexY) return -1;              // above the apex: unreachable
		return tUp + Math.sqrt(2 * (y - apexY) / G);
	},

	/* Where on this platform should we aim?
	   Plain: the centre. Spiked: the middle of the safe band between the
	   spike span and the outer landing edge, on whichever side is closer. */
	_aiAimX(pl) {
		const p = this.player;
		const outer = Platform.spanWidth(pl) / 2 + p.r * 0.25;
		if (!pl.spike) {
			// aim at the centre, but allow the full width as slack
			return { x: pl.x, slack: Math.max(8, outer - 14) };
		}
		const inner = Platform.spikeHalfSpan(pl) + p.r * 0.3;
		if (outer - inner < 10) return null;   // no safe landing strip
		const off = (inner + outer) / 2;
		const side = p.x < pl.x ? -1 : 1;
		return { x: pl.x + side * off, slack: (outer - inner) / 2 - 3 };
	},

	_autoSteer(dt) {
		const p = this.player;
		const speed = this.AI_SPEED;

		// drop a target we have fallen past, that vanished, or that is now
		// out of reach on this arc
		let tgt = this._aiTarget;
		if (tgt) {
			const t = this._aiTimeToDescendTo(Platform.top(tgt.pl));
			if (t < 0 || tgt.pl.y > p.y + 60 || !this._aiSolidAt(tgt.pl, t)) tgt = null;
		}

		// re-plan while rising: a better platform often spawns mid-flight
		if (tgt && p.vy < -60 && (this._frame & 7) === 0) tgt = null;

		if (!tgt) {
			let best = null, bestScore = -Infinity;
			for (let i = 0; i < this.platforms.length; i++) {
				const pl = this.platforms[i];
				if (pl.dead || pl.broken) continue;
				const top = Platform.top(pl);
				if (top > p.y + 900) continue;

				const t = this._aiTimeToDescendTo(top);
				if (t < 0 || !this._aiSolidAt(pl, t)) continue;

				const aim = this._aiAimX(pl);
				if (!aim) continue;

				// a moving platform's travel eats into the usable slack
				const slack = aim.slack - (pl.type === Platform.MOVING ? pl.moveRange : 0);
				const need = Math.max(0, Math.abs(aim.x - p.x) - Math.max(6, slack));
				const spare = speed * t * 0.92 - need;

				/* Score in PIXELS OF HEIGHT so the terms are comparable.
				   Every preference must be worth less than one row gap
				   (~150-228px), otherwise the planner will deliberately drop
				   to a lower platform to avoid a mild inconvenience — which
				   is exactly what a 300px spike penalty did: it made the AI
				   bounce on the start platform forever rather than take the
				   perfectly landable edge of a spiked row 157px higher. */
				let score = -top;
				if (pl.type === Platform.SPRING) score += 90;
				if (pl.type === Platform.BREAKABLE) score -= 45;
				if (pl.type === Platform.VANISH) score -= 35;
				if (pl.spike) score -= 70;
				if (spare < 0) score -= 4000 - spare;   // unreachable: last resort

				// avoid approaches guarded by an enemy we cannot stomp
				for (let k = 0; k < this.enemies.length; k++) {
					const e = this.enemies[k];
					if (e.dead) continue;
					if (Math.abs(e.x - aim.x) < 90 && e.y > top - 150 && e.y < top + 40) {
						score -= 120;
						break;
					}
				}

				if (score > bestScore) { bestScore = score; best = { pl, x: aim.x }; }
			}
			tgt = best;
			this._aiTarget = tgt;
		}

		// opportunistic stomp on the way down, but never off-course
		if (p.vy > 60) {
			for (let i = 0; i < this.enemies.length; i++) {
				const e = this.enemies[i];
				if (e.dead) continue;
				const dy = e.y - p.y;
				if (dy > 40 && dy < 260 && Math.abs(e.x - p.x) < 150 &&
					(!tgt || Math.abs(e.x - tgt.x) < 170)) {
					p.x += Math.max(-speed * dt, Math.min(speed * dt, e.x - p.x));
					return;
				}
			}
		}

		if (!tgt) return;
		// spiked platforms need the aim point recomputed as we approach, so
		// the chosen edge stays the near one
		if (tgt.pl.spike) {
			const aim = this._aiAimX(tgt.pl);
			if (aim) tgt.x = aim.x;
		} else {
			tgt.x = tgt.pl.x;
		}
		const dx = tgt.x - p.x;
		p.x += Math.max(-speed * dt, Math.min(speed * dt, dx));
		if (Math.abs(dx) > 40) p.facing = Math.sign(dx);
	},

	/* ------------------------------------------------------------ draw */
	draw(ctx, time) {
		const W = CFG.VIEW_W, H = CFG.VIEW_H;
		const inGame = this.playing || (typeof Game !== 'undefined' && Game.state === 'over');
		const camY = inGame ? this.camY : -this.menuT * 30;

		// ---- sky ----
		const m = inGame ? this.meters() : 0;
		const zs = CFG.ZONES;
		let zi = 0;
		for (let k = 0; k < zs.length; k++) if (m >= zs[k].m) zi = k;
		const cur = zs[zi];
		const nxt = zs[Math.min(zi + 1, zs.length - 1)];
		const transW = 160;
		const tt = nxt !== cur ? Math.max(0, Math.min(1, (m - (nxt.m - transW)) / transW)) : 0;

		const grad = ctx.createLinearGradient(0, 0, 0, H);
		grad.addColorStop(0, hexLerp(cur.top, nxt.top, tt));
		grad.addColorStop(0.62, hexLerp(cur.mid, nxt.mid, tt));
		grad.addColorStop(1, hexLerp(cur.bot, nxt.bot, tt));
		ctx.fillStyle = grad;
		ctx.fillRect(0, 0, W, H);

		const starAlpha = cur.stars + (nxt.stars - cur.stars) * tt;

		// ---- sun ----
		if (cur.sun === 'day' || cur.sun === 'set') {
			const sy = cur.sun === 'set' ? 380 : 190;
			ctx.globalAlpha = 0.35;
			ctx.fillStyle = '#fff4b8';
			ctx.beginPath(); ctx.arc(580, sy, 105, 0, Math.PI * 2); ctx.fill();
			ctx.globalAlpha = 0.8;
			ctx.fillStyle = '#fff1a8';
			ctx.beginPath(); ctx.arc(580, sy, 78, 0, Math.PI * 2); ctx.fill();
			ctx.globalAlpha = 1;
			ctx.fillStyle = '#fff7cf';
			ctx.beginPath(); ctx.arc(580, sy, 62, 0, Math.PI * 2); ctx.fill();
		}

		// ---- stars (wrapped parallax) ----
		if (starAlpha > 0.02) {
			ctx.fillStyle = '#ffffff';
			for (let i = 0; i < this.stars.length; i++) {
				const s = this.stars[i];
				const y = ((s.y - camY * 0.15) % 4000 + 4000) % 4000 - 200;
				if (y < -10 || y > H + 10) continue;
				ctx.globalAlpha = starAlpha * (0.5 + 0.5 * Math.sin(time * 2 + s.tw));
				ctx.beginPath();
				ctx.arc(s.x, y, s.r, 0, Math.PI * 2);
				ctx.fill();
			}
			ctx.globalAlpha = 1;
		}

		/* ---- planets (wrapped parallax band, visible from ~1900m) ----
		   Capped at 0.5 alpha: at full opacity they were brighter than the
		   platforms and competed with the gameplay layer for attention. */
		const planetAlpha = Math.max(0, Math.min(0.5, (m - 1900) / 600));
		if (planetAlpha > 0.01) {
			const SPAN = 6000;
			ctx.globalAlpha = planetAlpha;
			for (let i = 0; i < this.planets.length; i++) {
				const pl = this.planets[i];
				const y = ((pl.y - camY * 0.35) % SPAN + SPAN) % SPAN - 400;
				if (y < -pl.r * 2 || y > H + pl.r * 2) continue;
				ctx.fillStyle = `hsl(${pl.hue},45%,60%)`;
				ctx.beginPath(); ctx.arc(pl.x, y, pl.r, 0, Math.PI * 2); ctx.fill();
				ctx.fillStyle = `hsl(${pl.hue},45%,75%)`;
				ctx.beginPath(); ctx.arc(pl.x - pl.r * 0.3, y - pl.r * 0.3, pl.r * 0.35, 0, Math.PI * 2); ctx.fill();
				if (pl.ring) {
					ctx.strokeStyle = `hsla(${pl.hue},45%,70%,0.7)`;
					ctx.lineWidth = 7;
					ctx.beginPath();
					ctx.ellipse(pl.x, y, pl.r * 1.6, pl.r * 0.4, -0.3, 0, Math.PI * 2);
					ctx.stroke();
				}
			}
			ctx.globalAlpha = 1;
		}

		// ---- living sky: one moving thing per zone, cheap ----
		if (Game.state === 'play' || typeof Game === 'undefined') {
			this._livingSky(ctx, zi, camY, time, starAlpha);
		}

		// ---- clouds (fade out in space so they don't float past planets) ----
		const cloudFade = Math.max(0, Math.min(1, 1 - (m - 1400) / 500));
		if (cloudFade > 0.01) {
			const SPAN = 1600;
			for (let i = 0; i < this.clouds.length; i++) {
				const c = this.clouds[i];
				const y = ((c.y - camY * c.layer + time * 12 * (c.layer + 0.2)) % SPAN + SPAN) % SPAN - 200;
				if (y < -120 || y > H + 120) continue;
				this._cloud(ctx, c.x, y, c.s * 0.9, (0.9 - c.layer * 1.5) * cloudFade);
			}
		}

		// ---- skyline silhouettes (low altitude only, two parallax layers) ----
		const silFade = Math.max(0, Math.min(1, 1 - (m - 350) / 250));
		if (silFade > 0.01 && inGame) {
			this._skyline(ctx, camY, 0.22, H * 0.86, 170, 1.0, 0.16 * silFade, 0);
			this._skyline(ctx, camY, 0.4, H * 0.94, 120, 0.72, 0.26 * silFade, 500);
		}

		// ---- world entities ----
		if (!inGame) return;

		// COMBO OVERDRIVE — the world quietly tints toward the tier colour
		// while a big combo is live. Screen-space overlay, one fillRect.
		if (this.comboTier >= 2 && FX.zoom > 0.99) {
			const ov = Math.min(0.16, (this.comboTier - 1) * 0.045);
			ctx.fillStyle = CFG.TIER_COLORS[this.comboTier];
			ctx.globalAlpha = ov * (0.75 + 0.25 * Math.sin(time * 6));
			ctx.fillRect(0, 0, W, H);
			ctx.globalAlpha = 1;
		}

		ctx.save();
		ctx.translate(FX.shakeX, -camY + H / 2 + FX.shakeY);
		if (FX.zoom > 1.001) {
			ctx.translate(this.player.x, this.player.y);
			ctx.scale(FX.zoom, FX.zoom);
			ctx.translate(-this.player.x, -this.player.y);
		}

		this._drawBestLine(ctx);
		for (let i = 0; i < this.platforms.length; i++) Platform.draw(ctx, this.platforms[i], this._zoneIdxDraw());
		for (let i = 0; i < this.coins.length; i++) Coin.draw(ctx, this.coins[i]);
		for (let i = 0; i < this.powerups.length; i++) PowerUp.draw(ctx, this.powerups[i]);
		for (let i = 0; i < this.enemies.length; i++) Enemy.draw(ctx, this.enemies[i]);
		this._drawPlayerShadow(ctx);
		this._drawSpeedLines(ctx);
		this.player.draw(ctx);
		FX.draw(ctx);
		ctx.restore();

		// ---- white flash (new best / golden poop) ----
		if (FX.flashT > 0.01) {
			ctx.fillStyle = `rgba(255,255,255,${Math.min(0.5, FX.flashT)})`;
			ctx.fillRect(0, 0, W, H);
		}

		// ---- vignette (cached gradient, rebuilt only on resize) ----
		if (!this._vig || this._vigW !== W || this._vigH !== H) {
			const vg = ctx.createRadialGradient(
				W / 2, H / 2, Math.min(W, H) * 0.44,
				W / 2, H / 2, Math.max(W, H) * 0.74);
			vg.addColorStop(0, 'rgba(10,12,30,0)');
			vg.addColorStop(1, 'rgba(10,12,30,0.24)');
			this._vig = vg;
			this._vigW = W;
			this._vigH = H;
		}
		ctx.fillStyle = this._vig;
		ctx.fillRect(0, 0, W, H);
	},

	/* current zone index for platform skins (cached per frame) */
	_zoneIdxDraw() {
		if (this._ziCacheFrame === this._frame) return this._ziCache;
		const m = this.meters();
		let zi = 0;
		for (let k = 0; k < CFG.ZONES.length; k++) if (m >= CFG.ZONES[k].m) zi = k;
		this._ziCache = zi;
		this._ziCacheFrame = this._frame;
		return zi;
	},

	/* soft ellipse shadow on the platform (or air) right below the player —
	   grounds the character so it stops looking like a floating sticker */
	_drawPlayerShadow(ctx) {
		const p = this.player;
		if (p.rocketT > 0) return;
		let bestY = -Infinity, found = false;
		for (let i = 0; i < this.platforms.length; i++) {
			const pl = this.platforms[i];
			if (pl.broken || pl.dead) continue;
			if (Math.abs(p.x - pl.x) > Platform.spanWidth(pl) / 2 + p.r * 0.5) continue;
			const top = Platform.top(pl);
			if (top >= p.y + p.r && (top - p.y) < 560 && top > bestY) { bestY = top; found = true; }
		}
		// fade with distance; also a faint blob when over air (motion cue)
		const alpha = found ? Math.max(0.08, 0.3 - (bestY - p.y - p.r) / 2000) : 0.06;
		const y = found ? bestY : p.y + p.r + 210;
		const r = found ? Math.max(14, 30 - (bestY - p.y) / 40) : 22;
		ctx.save();
		ctx.globalAlpha = alpha;
		ctx.fillStyle = '#232a45';
		ctx.beginPath();
		ctx.ellipse(p.x, y - 2, r, r * 0.24, 0, 0, Math.PI * 2);
		ctx.fill();
		ctx.restore();
	},

	_drawBestLine(ctx) {		const best = Storage.data.best;
		if (best < 20) return;
		const y = -best * 50;
		const top = this.camY - CFG.VIEW_H / 2;
		if (y < top - 60 || y > top + CFG.VIEW_H + 60) return;
		ctx.save();
		ctx.strokeStyle = 'rgba(255,249,238,0.9)';
		ctx.lineWidth = 5;
		ctx.setLineDash([18, 14]);
		ctx.beginPath();
		ctx.moveTo(-40, y);
		ctx.lineTo(CFG.VIEW_W + 40, y);
		ctx.stroke();
		ctx.setLineDash([]);
		ctx.fillStyle = '#ffd166';
		ctx.strokeStyle = '#232a45';
		ctx.lineWidth = 3.5;
		ctx.beginPath();
		ctx.roundRect(560, y - 46, 132, 34, 10);
		ctx.fill();
		ctx.stroke();
		ctx.fillStyle = '#232a45';
		ctx.font = '800 20px "Baloo 2", "Comic Sans MS", sans-serif';
		ctx.textAlign = 'center';
		ctx.textBaseline = 'middle';
		ctx.fillText('BEST ' + best + 'm', 626, y - 29);
		ctx.restore();
	},

	/* One ambient touch per zone so the sky never feels static:
	   birds at day, shooting stars at night, aurora in space. All
	   screen-space, deterministic from `time`, zero allocations. */
	_livingSky(ctx, zi, camY, time, starAlpha) {
		const W = CFG.VIEW_W, H = CFG.VIEW_H;
		if (zi <= 1) {
			// two birds lazily crossing, wrapping
			for (let b = 0; b < 2; b++) {
				const bx = ((time * (14 + b * 7) + b * 380) % (W + 160)) - 80;
				const by = 120 + b * 90 + Math.sin(time * 1.3 + b * 2) * 24;
				const wing = Math.sin(time * 7 + b) * 7;
				ctx.strokeStyle = 'rgba(35,42,69,0.5)';
				ctx.lineWidth = 3;
				ctx.lineCap = 'round';
				ctx.beginPath();
				ctx.moveTo(bx - 10, by - wing);
				ctx.quadraticCurveTo(bx, by + 4, bx + 10, by - wing);
				ctx.stroke();
			}
		} else if (zi === 2) {
			// golden hour: a drifting heat shimmer band
			ctx.globalAlpha = 0.07;
			ctx.fillStyle = '#fff3c2';
			const yy = (time * 22) % (H + 300) - 150;
			ctx.beginPath();
			ctx.ellipse(W / 2, yy, W * 0.7, 60, 0, 0, Math.PI * 2);
			ctx.fill();
			ctx.globalAlpha = 1;
		} else {
			// night / space: a shooting star every ~7s + slow aurora bands
			const cyc = time % 7;
			if (cyc < 0.9) {
				const k = cyc / 0.9;
				const sx = W * 0.15 + (cyc * 620);
				const sy = 90 + cyc * 170;
				ctx.globalAlpha = (1 - k) * 0.9;
				ctx.strokeStyle = '#ffffff';
				ctx.lineWidth = 2.5;
				ctx.beginPath();
				ctx.moveTo(sx, sy);
				ctx.lineTo(sx - 46, sy - 26);
				ctx.stroke();
				ctx.globalAlpha = 1;
			}
			if (starAlpha > 0.3 && zi >= 4 && !(Game && Game._aqTier >= 2)) {
				for (let band = 0; band < 2; band++) {
					const ay = H * (0.2 + band * 0.16) + Math.sin(time * 0.4 + band * 2) * 30;
					ctx.globalAlpha = 0.05 + 0.02 * Math.sin(time * 0.8 + band);
					ctx.fillStyle = band ? '#59cd90' : '#c4a6ec';
					ctx.beginPath();
					ctx.ellipse(W / 2, ay, W * 0.62, 46, 0.12, 0, Math.PI * 2);
					ctx.fill();
				}
				ctx.globalAlpha = 1;
			}
		}
	},

	/* Soft Indian skyline: rolling ground + water-tank chhatris + a few
	   tall buildings. Deterministic per index, two layers, screen-space. */
	_skyline(ctx, camY, parallax, baseY, spacing, scale, alpha, seed) {		ctx.fillStyle = `rgba(20,60,45,${alpha})`;
		const span = spacing * 14;
		const off = ((camY * parallax) % span + span) % span;
		// ground band
		ctx.fillRect(0, baseY + 40 * scale, CFG.VIEW_W, CFG.VIEW_H - baseY + 200);
		for (let i = -1; i < 15; i++) {
			const wx = i * spacing - off;
			// hill hump (abs(): JS % keeps the sign, i starts at -1)
			const hump = 46 + Math.abs((i * 7919 + seed) % 61);
			ctx.beginPath();
			ctx.arc(wx + spacing / 2, baseY + 52 * scale, hump * scale, Math.PI, 0);
			ctx.fill();
			// a building every 3rd slot
			if ((i + seed) % 3 === 0) {
				const bw = 54 * scale, bh = (70 + Math.abs((i * 104729 + seed) % 55)) * scale;
				ctx.fillRect(wx + spacing * 0.18, baseY + 46 * scale - bh, bw, bh);
				// water tank on top (the classic Indian rooftop)
				ctx.fillRect(wx + spacing * 0.18 + bw * 0.3, baseY + 46 * scale - bh - 12 * scale, 14 * scale, 12 * scale);
			}
		}
	},

	/* speed lines when falling fast — pure screen-space motion cue */
	_drawSpeedLines(ctx) {
		const p = this.player;
		if (p.vy < 900 || p.rocketT > 0) return;
		const k = Math.min(1, (p.vy - 900) / 600);
		ctx.save();
		ctx.globalAlpha = 0.25 * k;
		ctx.strokeStyle = '#ffffff';
		ctx.lineWidth = 3;
		ctx.lineCap = 'round';
		for (let i = 0; i < 5; i++) {
			const x = ((p.x * 0.7 + i * 173 + this._frame * 31) % (CFG.VIEW_W + 80)) - 40;
			const y = p.y - 140 - i * 46;
			ctx.beginPath();
			ctx.moveTo(x, y);
			ctx.lineTo(x, y + 44 + i * 10);
			ctx.stroke();
		}
		ctx.restore();
	},

	_cloud(ctx, x, y, s, alpha) {
		ctx.fillStyle = `rgba(255,255,255,${Math.max(0.05, Math.min(1, alpha))})`;
		ctx.beginPath();
		ctx.arc(x, y, 36 * s, 0, Math.PI * 2);
		ctx.arc(x + 33 * s, y + 10 * s, 26 * s, 0, Math.PI * 2);
		ctx.arc(x - 33 * s, y + 7 * s, 24 * s, 0, Math.PI * 2);
		ctx.arc(x + 4 * s, y + 14 * s, 30 * s, 0, Math.PI * 2);
		ctx.fill();
	},

	menuUpdate(dt) { this.menuT += dt; },
};

if (typeof module !== 'undefined' && module.exports) module.exports = { World, hexLerp };
